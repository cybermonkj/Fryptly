<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-12-04 17:19:38 --> Config Class Initialized
INFO - 2019-12-04 17:19:38 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:19:38 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:19:38 --> Utf8 Class Initialized
INFO - 2019-12-04 17:19:38 --> URI Class Initialized
DEBUG - 2019-12-04 17:19:38 --> No URI present. Default controller set.
INFO - 2019-12-04 17:19:38 --> Router Class Initialized
INFO - 2019-12-04 17:19:38 --> Output Class Initialized
INFO - 2019-12-04 17:19:38 --> Security Class Initialized
DEBUG - 2019-12-04 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:19:38 --> CSRF cookie sent
INFO - 2019-12-04 17:19:38 --> Input Class Initialized
INFO - 2019-12-04 17:19:38 --> Language Class Initialized
INFO - 2019-12-04 17:19:38 --> Language Class Initialized
INFO - 2019-12-04 17:19:38 --> Config Class Initialized
INFO - 2019-12-04 17:19:38 --> Loader Class Initialized
INFO - 2019-12-04 17:19:38 --> Helper loaded: url_helper
INFO - 2019-12-04 17:19:38 --> Helper loaded: common_helper
INFO - 2019-12-04 17:19:38 --> Helper loaded: language_helper
INFO - 2019-12-04 17:19:38 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:19:38 --> Helper loaded: email_helper
INFO - 2019-12-04 17:19:38 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:19:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:19:38 --> Parser Class Initialized
INFO - 2019-12-04 17:19:38 --> User Agent Class Initialized
INFO - 2019-12-04 17:19:38 --> Model Class Initialized
INFO - 2019-12-04 17:19:38 --> Database Driver Class Initialized
INFO - 2019-12-04 17:19:38 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:38 --> Template Class Initialized
INFO - 2019-12-04 17:19:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:19:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:19:38 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:19:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:19:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:19:38 --> Encryption Class Initialized
DEBUG - 2019-12-04 17:19:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 17:19:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-04 17:19:38 --> Controller Class Initialized
DEBUG - 2019-12-04 17:19:38 --> pergo MX_Controller Initialized
DEBUG - 2019-12-04 17:19:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 17:19:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-04 17:19:39 --> Model Class Initialized
INFO - 2019-12-04 17:19:39 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 17:19:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-04 17:19:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-04 17:19:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-04 17:19:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-04 17:19:39 --> Final output sent to browser
DEBUG - 2019-12-04 17:19:39 --> Total execution time: 1.4535
INFO - 2019-12-04 17:19:43 --> Config Class Initialized
INFO - 2019-12-04 17:19:43 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:19:43 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:19:43 --> Utf8 Class Initialized
INFO - 2019-12-04 17:19:43 --> URI Class Initialized
INFO - 2019-12-04 17:19:43 --> Router Class Initialized
INFO - 2019-12-04 17:19:43 --> Output Class Initialized
INFO - 2019-12-04 17:19:43 --> Security Class Initialized
DEBUG - 2019-12-04 17:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:19:43 --> CSRF cookie sent
INFO - 2019-12-04 17:19:43 --> Input Class Initialized
INFO - 2019-12-04 17:19:43 --> Language Class Initialized
INFO - 2019-12-04 17:19:43 --> Language Class Initialized
INFO - 2019-12-04 17:19:43 --> Config Class Initialized
INFO - 2019-12-04 17:19:43 --> Loader Class Initialized
INFO - 2019-12-04 17:19:43 --> Helper loaded: url_helper
INFO - 2019-12-04 17:19:43 --> Helper loaded: common_helper
INFO - 2019-12-04 17:19:43 --> Helper loaded: language_helper
INFO - 2019-12-04 17:19:43 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:19:43 --> Helper loaded: email_helper
INFO - 2019-12-04 17:19:43 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:19:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:19:43 --> Parser Class Initialized
INFO - 2019-12-04 17:19:43 --> User Agent Class Initialized
INFO - 2019-12-04 17:19:43 --> Model Class Initialized
INFO - 2019-12-04 17:19:43 --> Database Driver Class Initialized
INFO - 2019-12-04 17:19:43 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:43 --> Template Class Initialized
INFO - 2019-12-04 17:19:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:19:43 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:19:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:19:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:19:43 --> Encryption Class Initialized
INFO - 2019-12-04 17:19:43 --> Controller Class Initialized
DEBUG - 2019-12-04 17:19:43 --> package MX_Controller Initialized
DEBUG - 2019-12-04 17:19:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-04 17:19:43 --> Model Class Initialized
INFO - 2019-12-04 17:19:43 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:19:44 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:19:44 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:19:44 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:19:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:19:44 --> Final output sent to browser
DEBUG - 2019-12-04 17:19:44 --> Total execution time: 1.1652
INFO - 2019-12-04 17:19:47 --> Config Class Initialized
INFO - 2019-12-04 17:19:47 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:19:47 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:19:47 --> Utf8 Class Initialized
INFO - 2019-12-04 17:19:47 --> URI Class Initialized
INFO - 2019-12-04 17:19:47 --> Router Class Initialized
INFO - 2019-12-04 17:19:47 --> Output Class Initialized
INFO - 2019-12-04 17:19:47 --> Security Class Initialized
DEBUG - 2019-12-04 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:19:47 --> CSRF cookie sent
INFO - 2019-12-04 17:19:47 --> CSRF token verified
INFO - 2019-12-04 17:19:47 --> Input Class Initialized
INFO - 2019-12-04 17:19:47 --> Language Class Initialized
INFO - 2019-12-04 17:19:47 --> Language Class Initialized
INFO - 2019-12-04 17:19:47 --> Config Class Initialized
INFO - 2019-12-04 17:19:47 --> Loader Class Initialized
INFO - 2019-12-04 17:19:47 --> Helper loaded: url_helper
INFO - 2019-12-04 17:19:47 --> Helper loaded: common_helper
INFO - 2019-12-04 17:19:47 --> Helper loaded: language_helper
INFO - 2019-12-04 17:19:47 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:19:47 --> Helper loaded: email_helper
INFO - 2019-12-04 17:19:47 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:19:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:19:47 --> Parser Class Initialized
INFO - 2019-12-04 17:19:47 --> User Agent Class Initialized
INFO - 2019-12-04 17:19:47 --> Model Class Initialized
INFO - 2019-12-04 17:19:47 --> Database Driver Class Initialized
INFO - 2019-12-04 17:19:47 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:47 --> Template Class Initialized
INFO - 2019-12-04 17:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:19:47 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:19:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:19:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:19:48 --> Encryption Class Initialized
INFO - 2019-12-04 17:19:48 --> Controller Class Initialized
DEBUG - 2019-12-04 17:19:48 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:19:48 --> Model Class Initialized
INFO - 2019-12-04 17:19:48 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:19:48 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:19:48 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:19:48 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:19:48 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:19:48 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:19:48 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:19:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:19:48 --> Final output sent to browser
DEBUG - 2019-12-04 17:19:48 --> Total execution time: 0.8169
INFO - 2019-12-04 17:19:56 --> Config Class Initialized
INFO - 2019-12-04 17:19:56 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:19:56 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:19:56 --> Utf8 Class Initialized
INFO - 2019-12-04 17:19:56 --> URI Class Initialized
INFO - 2019-12-04 17:19:56 --> Router Class Initialized
INFO - 2019-12-04 17:19:56 --> Output Class Initialized
INFO - 2019-12-04 17:19:56 --> Security Class Initialized
DEBUG - 2019-12-04 17:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:19:56 --> CSRF cookie sent
INFO - 2019-12-04 17:19:56 --> CSRF token verified
INFO - 2019-12-04 17:19:56 --> Input Class Initialized
INFO - 2019-12-04 17:19:56 --> Language Class Initialized
INFO - 2019-12-04 17:19:56 --> Language Class Initialized
INFO - 2019-12-04 17:19:56 --> Config Class Initialized
INFO - 2019-12-04 17:19:56 --> Loader Class Initialized
INFO - 2019-12-04 17:19:56 --> Helper loaded: url_helper
INFO - 2019-12-04 17:19:56 --> Helper loaded: common_helper
INFO - 2019-12-04 17:19:56 --> Helper loaded: language_helper
INFO - 2019-12-04 17:19:56 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:19:56 --> Helper loaded: email_helper
INFO - 2019-12-04 17:19:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:19:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:19:56 --> Parser Class Initialized
INFO - 2019-12-04 17:19:56 --> User Agent Class Initialized
INFO - 2019-12-04 17:19:56 --> Model Class Initialized
INFO - 2019-12-04 17:19:56 --> Database Driver Class Initialized
INFO - 2019-12-04 17:19:56 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:56 --> Template Class Initialized
INFO - 2019-12-04 17:19:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:19:56 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:19:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:19:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:19:56 --> Encryption Class Initialized
INFO - 2019-12-04 17:19:56 --> Controller Class Initialized
DEBUG - 2019-12-04 17:19:56 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:19:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:19:56 --> Model Class Initialized
DEBUG - 2019-12-04 17:19:56 --> payop MX_Controller Initialized
INFO - 2019-12-04 17:46:44 --> Config Class Initialized
INFO - 2019-12-04 17:46:44 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:46:44 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:46:44 --> Utf8 Class Initialized
INFO - 2019-12-04 17:46:44 --> URI Class Initialized
INFO - 2019-12-04 17:46:45 --> Router Class Initialized
INFO - 2019-12-04 17:46:45 --> Output Class Initialized
INFO - 2019-12-04 17:46:45 --> Security Class Initialized
DEBUG - 2019-12-04 17:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:46:45 --> CSRF cookie sent
INFO - 2019-12-04 17:46:45 --> CSRF token verified
INFO - 2019-12-04 17:46:45 --> Input Class Initialized
INFO - 2019-12-04 17:46:45 --> Language Class Initialized
INFO - 2019-12-04 17:46:45 --> Language Class Initialized
INFO - 2019-12-04 17:46:45 --> Config Class Initialized
INFO - 2019-12-04 17:46:45 --> Loader Class Initialized
INFO - 2019-12-04 17:46:45 --> Helper loaded: url_helper
INFO - 2019-12-04 17:46:45 --> Helper loaded: common_helper
INFO - 2019-12-04 17:46:45 --> Helper loaded: language_helper
INFO - 2019-12-04 17:46:45 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:46:45 --> Helper loaded: email_helper
INFO - 2019-12-04 17:46:45 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:46:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:46:45 --> Parser Class Initialized
INFO - 2019-12-04 17:46:45 --> User Agent Class Initialized
INFO - 2019-12-04 17:46:45 --> Model Class Initialized
INFO - 2019-12-04 17:46:45 --> Database Driver Class Initialized
INFO - 2019-12-04 17:46:45 --> Model Class Initialized
DEBUG - 2019-12-04 17:46:45 --> Template Class Initialized
INFO - 2019-12-04 17:46:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:46:45 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:46:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:46:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:46:46 --> Encryption Class Initialized
INFO - 2019-12-04 17:46:46 --> Controller Class Initialized
DEBUG - 2019-12-04 17:46:46 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:46:46 --> Model Class Initialized
INFO - 2019-12-04 17:46:46 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:46:46 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:46:46 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:46:46 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:46:46 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:46:46 --> Model Class Initialized
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:46:46 --> Model Class Initialized
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:46:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:46:46 --> Final output sent to browser
DEBUG - 2019-12-04 17:46:46 --> Total execution time: 1.7357
INFO - 2019-12-04 17:46:57 --> Config Class Initialized
INFO - 2019-12-04 17:46:58 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:46:58 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:46:58 --> Utf8 Class Initialized
INFO - 2019-12-04 17:46:58 --> URI Class Initialized
INFO - 2019-12-04 17:46:58 --> Router Class Initialized
INFO - 2019-12-04 17:46:58 --> Output Class Initialized
INFO - 2019-12-04 17:46:58 --> Security Class Initialized
DEBUG - 2019-12-04 17:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:46:58 --> CSRF cookie sent
INFO - 2019-12-04 17:46:58 --> CSRF token verified
INFO - 2019-12-04 17:46:58 --> Input Class Initialized
INFO - 2019-12-04 17:46:58 --> Language Class Initialized
INFO - 2019-12-04 17:46:58 --> Language Class Initialized
INFO - 2019-12-04 17:46:58 --> Config Class Initialized
INFO - 2019-12-04 17:46:58 --> Loader Class Initialized
INFO - 2019-12-04 17:46:58 --> Helper loaded: url_helper
INFO - 2019-12-04 17:46:58 --> Helper loaded: common_helper
INFO - 2019-12-04 17:46:58 --> Helper loaded: language_helper
INFO - 2019-12-04 17:46:58 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:46:58 --> Helper loaded: email_helper
INFO - 2019-12-04 17:46:58 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:46:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:46:58 --> Parser Class Initialized
INFO - 2019-12-04 17:46:58 --> User Agent Class Initialized
INFO - 2019-12-04 17:46:58 --> Model Class Initialized
INFO - 2019-12-04 17:46:58 --> Database Driver Class Initialized
INFO - 2019-12-04 17:46:58 --> Model Class Initialized
DEBUG - 2019-12-04 17:46:58 --> Template Class Initialized
INFO - 2019-12-04 17:46:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:46:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:46:58 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:46:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:46:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:46:58 --> Encryption Class Initialized
INFO - 2019-12-04 17:46:58 --> Controller Class Initialized
DEBUG - 2019-12-04 17:46:58 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:46:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:46:58 --> Model Class Initialized
DEBUG - 2019-12-04 17:46:58 --> payop MX_Controller Initialized
ERROR - 2019-12-04 17:47:00 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 103
INFO - 2019-12-04 17:47:26 --> Config Class Initialized
INFO - 2019-12-04 17:47:26 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:47:26 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:47:26 --> Utf8 Class Initialized
INFO - 2019-12-04 17:47:26 --> URI Class Initialized
INFO - 2019-12-04 17:47:26 --> Router Class Initialized
INFO - 2019-12-04 17:47:26 --> Output Class Initialized
INFO - 2019-12-04 17:47:26 --> Security Class Initialized
DEBUG - 2019-12-04 17:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:47:26 --> CSRF cookie sent
INFO - 2019-12-04 17:47:26 --> CSRF token verified
INFO - 2019-12-04 17:47:26 --> Input Class Initialized
INFO - 2019-12-04 17:47:26 --> Language Class Initialized
INFO - 2019-12-04 17:47:26 --> Language Class Initialized
INFO - 2019-12-04 17:47:26 --> Config Class Initialized
INFO - 2019-12-04 17:47:26 --> Loader Class Initialized
INFO - 2019-12-04 17:47:26 --> Helper loaded: url_helper
INFO - 2019-12-04 17:47:26 --> Helper loaded: common_helper
INFO - 2019-12-04 17:47:26 --> Helper loaded: language_helper
INFO - 2019-12-04 17:47:26 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:47:26 --> Helper loaded: email_helper
INFO - 2019-12-04 17:47:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:47:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:47:26 --> Parser Class Initialized
INFO - 2019-12-04 17:47:26 --> User Agent Class Initialized
INFO - 2019-12-04 17:47:26 --> Model Class Initialized
INFO - 2019-12-04 17:47:26 --> Database Driver Class Initialized
INFO - 2019-12-04 17:47:26 --> Model Class Initialized
DEBUG - 2019-12-04 17:47:26 --> Template Class Initialized
INFO - 2019-12-04 17:47:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:47:26 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:47:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:47:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:47:26 --> Encryption Class Initialized
INFO - 2019-12-04 17:47:26 --> Controller Class Initialized
DEBUG - 2019-12-04 17:47:26 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:47:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:47:26 --> Model Class Initialized
INFO - 2019-12-04 17:47:26 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:47:27 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:47:27 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:47:27 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:47:27 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:47:27 --> Model Class Initialized
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:47:27 --> Model Class Initialized
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:47:27 --> Final output sent to browser
DEBUG - 2019-12-04 17:47:27 --> Total execution time: 0.8322
INFO - 2019-12-04 17:47:39 --> Config Class Initialized
INFO - 2019-12-04 17:47:39 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:47:39 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:47:39 --> Utf8 Class Initialized
INFO - 2019-12-04 17:47:39 --> URI Class Initialized
INFO - 2019-12-04 17:47:39 --> Router Class Initialized
INFO - 2019-12-04 17:47:39 --> Output Class Initialized
INFO - 2019-12-04 17:47:39 --> Security Class Initialized
DEBUG - 2019-12-04 17:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:47:39 --> CSRF cookie sent
INFO - 2019-12-04 17:47:39 --> CSRF token verified
INFO - 2019-12-04 17:47:39 --> Input Class Initialized
INFO - 2019-12-04 17:47:39 --> Language Class Initialized
INFO - 2019-12-04 17:47:39 --> Language Class Initialized
INFO - 2019-12-04 17:47:39 --> Config Class Initialized
INFO - 2019-12-04 17:47:39 --> Loader Class Initialized
INFO - 2019-12-04 17:47:39 --> Helper loaded: url_helper
INFO - 2019-12-04 17:47:39 --> Helper loaded: common_helper
INFO - 2019-12-04 17:47:39 --> Helper loaded: language_helper
INFO - 2019-12-04 17:47:39 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:47:39 --> Helper loaded: email_helper
INFO - 2019-12-04 17:47:39 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:47:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:47:39 --> Parser Class Initialized
INFO - 2019-12-04 17:47:39 --> User Agent Class Initialized
INFO - 2019-12-04 17:47:39 --> Model Class Initialized
INFO - 2019-12-04 17:47:39 --> Database Driver Class Initialized
INFO - 2019-12-04 17:47:39 --> Model Class Initialized
DEBUG - 2019-12-04 17:47:39 --> Template Class Initialized
INFO - 2019-12-04 17:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:47:39 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:47:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:47:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:47:39 --> Encryption Class Initialized
INFO - 2019-12-04 17:47:39 --> Controller Class Initialized
DEBUG - 2019-12-04 17:47:39 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:47:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:47:39 --> Model Class Initialized
DEBUG - 2019-12-04 17:47:39 --> payop MX_Controller Initialized
INFO - 2019-12-04 17:49:45 --> Config Class Initialized
INFO - 2019-12-04 17:49:45 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:49:45 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:49:46 --> Utf8 Class Initialized
INFO - 2019-12-04 17:49:46 --> URI Class Initialized
INFO - 2019-12-04 17:49:46 --> Router Class Initialized
INFO - 2019-12-04 17:49:46 --> Output Class Initialized
INFO - 2019-12-04 17:49:46 --> Security Class Initialized
DEBUG - 2019-12-04 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:49:46 --> CSRF cookie sent
INFO - 2019-12-04 17:49:46 --> CSRF token verified
INFO - 2019-12-04 17:49:46 --> Input Class Initialized
INFO - 2019-12-04 17:49:46 --> Language Class Initialized
INFO - 2019-12-04 17:49:46 --> Language Class Initialized
INFO - 2019-12-04 17:49:46 --> Config Class Initialized
INFO - 2019-12-04 17:49:46 --> Loader Class Initialized
INFO - 2019-12-04 17:49:46 --> Helper loaded: url_helper
INFO - 2019-12-04 17:49:46 --> Helper loaded: common_helper
INFO - 2019-12-04 17:49:46 --> Helper loaded: language_helper
INFO - 2019-12-04 17:49:46 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:49:46 --> Helper loaded: email_helper
INFO - 2019-12-04 17:49:46 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:49:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:49:46 --> Parser Class Initialized
INFO - 2019-12-04 17:49:46 --> User Agent Class Initialized
INFO - 2019-12-04 17:49:46 --> Model Class Initialized
INFO - 2019-12-04 17:49:46 --> Database Driver Class Initialized
INFO - 2019-12-04 17:49:46 --> Model Class Initialized
DEBUG - 2019-12-04 17:49:46 --> Template Class Initialized
INFO - 2019-12-04 17:49:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:49:46 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:49:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:49:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:49:46 --> Encryption Class Initialized
INFO - 2019-12-04 17:49:46 --> Controller Class Initialized
DEBUG - 2019-12-04 17:49:46 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:49:46 --> Model Class Initialized
INFO - 2019-12-04 17:49:46 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:49:46 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:49:46 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:49:46 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:49:46 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:49:46 --> Model Class Initialized
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:49:46 --> Model Class Initialized
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:49:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:49:46 --> Final output sent to browser
DEBUG - 2019-12-04 17:49:46 --> Total execution time: 0.7115
INFO - 2019-12-04 17:50:01 --> Config Class Initialized
INFO - 2019-12-04 17:50:01 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:50:01 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:50:01 --> Utf8 Class Initialized
INFO - 2019-12-04 17:50:01 --> URI Class Initialized
INFO - 2019-12-04 17:50:01 --> Router Class Initialized
INFO - 2019-12-04 17:50:01 --> Output Class Initialized
INFO - 2019-12-04 17:50:01 --> Security Class Initialized
DEBUG - 2019-12-04 17:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:50:01 --> CSRF cookie sent
INFO - 2019-12-04 17:50:01 --> CSRF token verified
INFO - 2019-12-04 17:50:01 --> Input Class Initialized
INFO - 2019-12-04 17:50:01 --> Language Class Initialized
INFO - 2019-12-04 17:50:01 --> Language Class Initialized
INFO - 2019-12-04 17:50:01 --> Config Class Initialized
INFO - 2019-12-04 17:50:01 --> Loader Class Initialized
INFO - 2019-12-04 17:50:01 --> Helper loaded: url_helper
INFO - 2019-12-04 17:50:01 --> Helper loaded: common_helper
INFO - 2019-12-04 17:50:01 --> Helper loaded: language_helper
INFO - 2019-12-04 17:50:01 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:50:01 --> Helper loaded: email_helper
INFO - 2019-12-04 17:50:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:50:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:50:01 --> Parser Class Initialized
INFO - 2019-12-04 17:50:01 --> User Agent Class Initialized
INFO - 2019-12-04 17:50:01 --> Model Class Initialized
INFO - 2019-12-04 17:50:01 --> Database Driver Class Initialized
INFO - 2019-12-04 17:50:01 --> Model Class Initialized
DEBUG - 2019-12-04 17:50:01 --> Template Class Initialized
INFO - 2019-12-04 17:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:50:01 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:50:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:50:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:50:01 --> Encryption Class Initialized
INFO - 2019-12-04 17:50:01 --> Controller Class Initialized
DEBUG - 2019-12-04 17:50:01 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:50:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:50:01 --> Model Class Initialized
ERROR - 2019-12-04 17:50:01 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 113
INFO - 2019-12-04 17:50:13 --> Config Class Initialized
INFO - 2019-12-04 17:50:13 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:50:13 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:50:13 --> Utf8 Class Initialized
INFO - 2019-12-04 17:50:13 --> URI Class Initialized
INFO - 2019-12-04 17:50:13 --> Router Class Initialized
INFO - 2019-12-04 17:50:13 --> Output Class Initialized
INFO - 2019-12-04 17:50:13 --> Security Class Initialized
DEBUG - 2019-12-04 17:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:50:13 --> CSRF cookie sent
INFO - 2019-12-04 17:50:13 --> CSRF token verified
INFO - 2019-12-04 17:50:13 --> Input Class Initialized
INFO - 2019-12-04 17:50:13 --> Language Class Initialized
INFO - 2019-12-04 17:50:13 --> Language Class Initialized
INFO - 2019-12-04 17:50:13 --> Config Class Initialized
INFO - 2019-12-04 17:50:13 --> Loader Class Initialized
INFO - 2019-12-04 17:50:13 --> Helper loaded: url_helper
INFO - 2019-12-04 17:50:13 --> Helper loaded: common_helper
INFO - 2019-12-04 17:50:13 --> Helper loaded: language_helper
INFO - 2019-12-04 17:50:13 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:50:13 --> Helper loaded: email_helper
INFO - 2019-12-04 17:50:13 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:50:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:50:13 --> Parser Class Initialized
INFO - 2019-12-04 17:50:13 --> User Agent Class Initialized
INFO - 2019-12-04 17:50:13 --> Model Class Initialized
INFO - 2019-12-04 17:50:13 --> Database Driver Class Initialized
INFO - 2019-12-04 17:50:13 --> Model Class Initialized
DEBUG - 2019-12-04 17:50:13 --> Template Class Initialized
INFO - 2019-12-04 17:50:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:50:13 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:50:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:50:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:50:14 --> Encryption Class Initialized
INFO - 2019-12-04 17:50:14 --> Controller Class Initialized
DEBUG - 2019-12-04 17:50:14 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:50:14 --> Model Class Initialized
INFO - 2019-12-04 17:50:14 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:50:14 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:50:14 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:50:14 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:50:14 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:50:14 --> Model Class Initialized
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:50:14 --> Model Class Initialized
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:50:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:50:14 --> Final output sent to browser
DEBUG - 2019-12-04 17:50:14 --> Total execution time: 0.6889
INFO - 2019-12-04 17:50:25 --> Config Class Initialized
INFO - 2019-12-04 17:50:25 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:50:25 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:50:25 --> Utf8 Class Initialized
INFO - 2019-12-04 17:50:25 --> URI Class Initialized
INFO - 2019-12-04 17:50:25 --> Router Class Initialized
INFO - 2019-12-04 17:50:25 --> Output Class Initialized
INFO - 2019-12-04 17:50:25 --> Security Class Initialized
DEBUG - 2019-12-04 17:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:50:25 --> CSRF cookie sent
INFO - 2019-12-04 17:50:25 --> CSRF token verified
INFO - 2019-12-04 17:50:25 --> Input Class Initialized
INFO - 2019-12-04 17:50:25 --> Language Class Initialized
INFO - 2019-12-04 17:50:25 --> Language Class Initialized
INFO - 2019-12-04 17:50:25 --> Config Class Initialized
INFO - 2019-12-04 17:50:25 --> Loader Class Initialized
INFO - 2019-12-04 17:50:25 --> Helper loaded: url_helper
INFO - 2019-12-04 17:50:25 --> Helper loaded: common_helper
INFO - 2019-12-04 17:50:25 --> Helper loaded: language_helper
INFO - 2019-12-04 17:50:25 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:50:25 --> Helper loaded: email_helper
INFO - 2019-12-04 17:50:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:50:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:50:25 --> Parser Class Initialized
INFO - 2019-12-04 17:50:25 --> User Agent Class Initialized
INFO - 2019-12-04 17:50:25 --> Model Class Initialized
INFO - 2019-12-04 17:50:25 --> Database Driver Class Initialized
INFO - 2019-12-04 17:50:25 --> Model Class Initialized
DEBUG - 2019-12-04 17:50:25 --> Template Class Initialized
INFO - 2019-12-04 17:50:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:50:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:50:25 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:50:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:50:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:50:25 --> Encryption Class Initialized
INFO - 2019-12-04 17:50:25 --> Controller Class Initialized
DEBUG - 2019-12-04 17:50:25 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:50:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:50:25 --> Model Class Initialized
DEBUG - 2019-12-04 17:50:25 --> payop MX_Controller Initialized
ERROR - 2019-12-04 17:50:28 --> Severity: Notice --> Trying to get property of non-object D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 111
ERROR - 2019-12-04 17:50:28 --> Severity: Notice --> Undefined variable: signature D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 135
INFO - 2019-12-04 17:51:10 --> Config Class Initialized
INFO - 2019-12-04 17:51:10 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:51:10 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:51:10 --> Utf8 Class Initialized
INFO - 2019-12-04 17:51:10 --> URI Class Initialized
INFO - 2019-12-04 17:51:10 --> Router Class Initialized
INFO - 2019-12-04 17:51:10 --> Output Class Initialized
INFO - 2019-12-04 17:51:10 --> Security Class Initialized
DEBUG - 2019-12-04 17:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:51:10 --> CSRF cookie sent
INFO - 2019-12-04 17:51:10 --> CSRF token verified
INFO - 2019-12-04 17:51:10 --> Input Class Initialized
INFO - 2019-12-04 17:51:10 --> Language Class Initialized
INFO - 2019-12-04 17:51:10 --> Language Class Initialized
INFO - 2019-12-04 17:51:10 --> Config Class Initialized
INFO - 2019-12-04 17:51:10 --> Loader Class Initialized
INFO - 2019-12-04 17:51:10 --> Helper loaded: url_helper
INFO - 2019-12-04 17:51:10 --> Helper loaded: common_helper
INFO - 2019-12-04 17:51:10 --> Helper loaded: language_helper
INFO - 2019-12-04 17:51:10 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:51:10 --> Helper loaded: email_helper
INFO - 2019-12-04 17:51:10 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:51:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:51:10 --> Parser Class Initialized
INFO - 2019-12-04 17:51:10 --> User Agent Class Initialized
INFO - 2019-12-04 17:51:10 --> Model Class Initialized
INFO - 2019-12-04 17:51:10 --> Database Driver Class Initialized
INFO - 2019-12-04 17:51:10 --> Model Class Initialized
DEBUG - 2019-12-04 17:51:10 --> Template Class Initialized
INFO - 2019-12-04 17:51:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:51:10 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:51:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:51:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:51:10 --> Encryption Class Initialized
INFO - 2019-12-04 17:51:10 --> Controller Class Initialized
DEBUG - 2019-12-04 17:51:10 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:51:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:51:10 --> Model Class Initialized
INFO - 2019-12-04 17:51:10 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:51:10 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:51:10 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:51:11 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:51:11 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:51:11 --> Model Class Initialized
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:51:11 --> Model Class Initialized
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:51:11 --> Final output sent to browser
DEBUG - 2019-12-04 17:51:11 --> Total execution time: 0.7172
INFO - 2019-12-04 17:51:21 --> Config Class Initialized
INFO - 2019-12-04 17:51:21 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:51:21 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:51:21 --> Utf8 Class Initialized
INFO - 2019-12-04 17:51:21 --> URI Class Initialized
INFO - 2019-12-04 17:51:21 --> Router Class Initialized
INFO - 2019-12-04 17:51:21 --> Output Class Initialized
INFO - 2019-12-04 17:51:21 --> Security Class Initialized
DEBUG - 2019-12-04 17:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:51:21 --> CSRF cookie sent
INFO - 2019-12-04 17:51:21 --> CSRF token verified
INFO - 2019-12-04 17:51:21 --> Input Class Initialized
INFO - 2019-12-04 17:51:21 --> Language Class Initialized
INFO - 2019-12-04 17:51:21 --> Language Class Initialized
INFO - 2019-12-04 17:51:21 --> Config Class Initialized
INFO - 2019-12-04 17:51:21 --> Loader Class Initialized
INFO - 2019-12-04 17:51:21 --> Helper loaded: url_helper
INFO - 2019-12-04 17:51:21 --> Helper loaded: common_helper
INFO - 2019-12-04 17:51:21 --> Helper loaded: language_helper
INFO - 2019-12-04 17:51:21 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:51:21 --> Helper loaded: email_helper
INFO - 2019-12-04 17:51:21 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:51:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:51:21 --> Parser Class Initialized
INFO - 2019-12-04 17:51:21 --> User Agent Class Initialized
INFO - 2019-12-04 17:51:21 --> Model Class Initialized
INFO - 2019-12-04 17:51:21 --> Database Driver Class Initialized
INFO - 2019-12-04 17:51:21 --> Model Class Initialized
DEBUG - 2019-12-04 17:51:21 --> Template Class Initialized
INFO - 2019-12-04 17:51:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:51:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:51:21 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:51:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:51:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:51:21 --> Encryption Class Initialized
INFO - 2019-12-04 17:51:21 --> Controller Class Initialized
DEBUG - 2019-12-04 17:51:21 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:51:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:51:21 --> Model Class Initialized
DEBUG - 2019-12-04 17:51:21 --> payop MX_Controller Initialized
INFO - 2019-12-04 17:52:09 --> Config Class Initialized
INFO - 2019-12-04 17:52:09 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:52:09 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:52:09 --> Utf8 Class Initialized
INFO - 2019-12-04 17:52:09 --> URI Class Initialized
INFO - 2019-12-04 17:52:09 --> Router Class Initialized
INFO - 2019-12-04 17:52:09 --> Output Class Initialized
INFO - 2019-12-04 17:52:09 --> Security Class Initialized
DEBUG - 2019-12-04 17:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:52:09 --> CSRF cookie sent
INFO - 2019-12-04 17:52:09 --> CSRF token verified
INFO - 2019-12-04 17:52:09 --> Input Class Initialized
INFO - 2019-12-04 17:52:09 --> Language Class Initialized
INFO - 2019-12-04 17:52:09 --> Language Class Initialized
INFO - 2019-12-04 17:52:09 --> Config Class Initialized
INFO - 2019-12-04 17:52:09 --> Loader Class Initialized
INFO - 2019-12-04 17:52:09 --> Helper loaded: url_helper
INFO - 2019-12-04 17:52:09 --> Helper loaded: common_helper
INFO - 2019-12-04 17:52:09 --> Helper loaded: language_helper
INFO - 2019-12-04 17:52:09 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:52:09 --> Helper loaded: email_helper
INFO - 2019-12-04 17:52:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:52:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:52:09 --> Parser Class Initialized
INFO - 2019-12-04 17:52:09 --> User Agent Class Initialized
INFO - 2019-12-04 17:52:09 --> Model Class Initialized
INFO - 2019-12-04 17:52:09 --> Database Driver Class Initialized
INFO - 2019-12-04 17:52:09 --> Model Class Initialized
DEBUG - 2019-12-04 17:52:09 --> Template Class Initialized
INFO - 2019-12-04 17:52:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:52:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:52:09 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:52:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:52:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:52:09 --> Encryption Class Initialized
INFO - 2019-12-04 17:52:09 --> Controller Class Initialized
DEBUG - 2019-12-04 17:52:09 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:52:09 --> Model Class Initialized
INFO - 2019-12-04 17:52:09 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:52:09 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:52:09 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:52:09 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:52:09 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:52:09 --> Model Class Initialized
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:52:09 --> Model Class Initialized
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:52:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:52:09 --> Final output sent to browser
DEBUG - 2019-12-04 17:52:09 --> Total execution time: 0.6878
INFO - 2019-12-04 17:52:18 --> Config Class Initialized
INFO - 2019-12-04 17:52:18 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:52:18 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:52:18 --> Utf8 Class Initialized
INFO - 2019-12-04 17:52:18 --> URI Class Initialized
INFO - 2019-12-04 17:52:18 --> Router Class Initialized
INFO - 2019-12-04 17:52:18 --> Output Class Initialized
INFO - 2019-12-04 17:52:18 --> Security Class Initialized
DEBUG - 2019-12-04 17:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:52:18 --> CSRF cookie sent
INFO - 2019-12-04 17:52:18 --> CSRF token verified
INFO - 2019-12-04 17:52:18 --> Input Class Initialized
INFO - 2019-12-04 17:52:18 --> Language Class Initialized
INFO - 2019-12-04 17:52:18 --> Language Class Initialized
INFO - 2019-12-04 17:52:18 --> Config Class Initialized
INFO - 2019-12-04 17:52:18 --> Loader Class Initialized
INFO - 2019-12-04 17:52:18 --> Helper loaded: url_helper
INFO - 2019-12-04 17:52:19 --> Helper loaded: common_helper
INFO - 2019-12-04 17:52:19 --> Helper loaded: language_helper
INFO - 2019-12-04 17:52:19 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:52:19 --> Helper loaded: email_helper
INFO - 2019-12-04 17:52:19 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:52:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:52:19 --> Parser Class Initialized
INFO - 2019-12-04 17:52:19 --> User Agent Class Initialized
INFO - 2019-12-04 17:52:19 --> Model Class Initialized
INFO - 2019-12-04 17:52:19 --> Database Driver Class Initialized
INFO - 2019-12-04 17:52:19 --> Model Class Initialized
DEBUG - 2019-12-04 17:52:19 --> Template Class Initialized
INFO - 2019-12-04 17:52:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:52:19 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:52:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:52:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:52:19 --> Encryption Class Initialized
INFO - 2019-12-04 17:52:19 --> Controller Class Initialized
DEBUG - 2019-12-04 17:52:19 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:52:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:52:19 --> Model Class Initialized
DEBUG - 2019-12-04 17:52:19 --> payop MX_Controller Initialized
INFO - 2019-12-04 17:56:27 --> Config Class Initialized
INFO - 2019-12-04 17:56:27 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:56:27 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:56:27 --> Utf8 Class Initialized
INFO - 2019-12-04 17:56:27 --> URI Class Initialized
INFO - 2019-12-04 17:56:27 --> Router Class Initialized
INFO - 2019-12-04 17:56:27 --> Output Class Initialized
INFO - 2019-12-04 17:56:27 --> Security Class Initialized
DEBUG - 2019-12-04 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:56:27 --> CSRF cookie sent
INFO - 2019-12-04 17:56:27 --> CSRF token verified
INFO - 2019-12-04 17:56:27 --> Input Class Initialized
INFO - 2019-12-04 17:56:27 --> Language Class Initialized
INFO - 2019-12-04 17:56:27 --> Language Class Initialized
INFO - 2019-12-04 17:56:27 --> Config Class Initialized
INFO - 2019-12-04 17:56:27 --> Loader Class Initialized
INFO - 2019-12-04 17:56:27 --> Helper loaded: url_helper
INFO - 2019-12-04 17:56:27 --> Helper loaded: common_helper
INFO - 2019-12-04 17:56:27 --> Helper loaded: language_helper
INFO - 2019-12-04 17:56:27 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:56:27 --> Helper loaded: email_helper
INFO - 2019-12-04 17:56:27 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:56:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:56:27 --> Parser Class Initialized
INFO - 2019-12-04 17:56:27 --> User Agent Class Initialized
INFO - 2019-12-04 17:56:27 --> Model Class Initialized
INFO - 2019-12-04 17:56:27 --> Database Driver Class Initialized
INFO - 2019-12-04 17:56:27 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:27 --> Template Class Initialized
INFO - 2019-12-04 17:56:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:56:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:56:27 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:56:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:56:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:56:27 --> Encryption Class Initialized
INFO - 2019-12-04 17:56:27 --> Controller Class Initialized
DEBUG - 2019-12-04 17:56:27 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:56:27 --> Model Class Initialized
INFO - 2019-12-04 17:56:27 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:56:27 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:56:27 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:56:27 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:56:27 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:56:27 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:56:27 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:56:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:56:27 --> Final output sent to browser
DEBUG - 2019-12-04 17:56:27 --> Total execution time: 0.8430
INFO - 2019-12-04 17:56:37 --> Config Class Initialized
INFO - 2019-12-04 17:56:37 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:56:37 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:56:37 --> Utf8 Class Initialized
INFO - 2019-12-04 17:56:37 --> URI Class Initialized
INFO - 2019-12-04 17:56:37 --> Router Class Initialized
INFO - 2019-12-04 17:56:37 --> Output Class Initialized
INFO - 2019-12-04 17:56:37 --> Security Class Initialized
DEBUG - 2019-12-04 17:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:56:37 --> CSRF cookie sent
INFO - 2019-12-04 17:56:37 --> CSRF token verified
INFO - 2019-12-04 17:56:37 --> Input Class Initialized
INFO - 2019-12-04 17:56:37 --> Language Class Initialized
INFO - 2019-12-04 17:56:37 --> Language Class Initialized
INFO - 2019-12-04 17:56:38 --> Config Class Initialized
INFO - 2019-12-04 17:56:38 --> Loader Class Initialized
INFO - 2019-12-04 17:56:38 --> Helper loaded: url_helper
INFO - 2019-12-04 17:56:38 --> Helper loaded: common_helper
INFO - 2019-12-04 17:56:38 --> Helper loaded: language_helper
INFO - 2019-12-04 17:56:38 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:56:38 --> Helper loaded: email_helper
INFO - 2019-12-04 17:56:38 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:56:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:56:38 --> Parser Class Initialized
INFO - 2019-12-04 17:56:38 --> User Agent Class Initialized
INFO - 2019-12-04 17:56:38 --> Model Class Initialized
INFO - 2019-12-04 17:56:38 --> Database Driver Class Initialized
INFO - 2019-12-04 17:56:38 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:38 --> Template Class Initialized
INFO - 2019-12-04 17:56:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:56:38 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:56:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:56:38 --> Encryption Class Initialized
INFO - 2019-12-04 17:56:38 --> Controller Class Initialized
DEBUG - 2019-12-04 17:56:38 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:56:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:56:38 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:38 --> payop MX_Controller Initialized
INFO - 2019-12-04 17:56:51 --> Config Class Initialized
INFO - 2019-12-04 17:56:51 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:56:51 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:56:51 --> Utf8 Class Initialized
INFO - 2019-12-04 17:56:51 --> URI Class Initialized
INFO - 2019-12-04 17:56:51 --> Router Class Initialized
INFO - 2019-12-04 17:56:51 --> Output Class Initialized
INFO - 2019-12-04 17:56:51 --> Security Class Initialized
DEBUG - 2019-12-04 17:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:56:51 --> CSRF cookie sent
INFO - 2019-12-04 17:56:51 --> CSRF token verified
INFO - 2019-12-04 17:56:51 --> Input Class Initialized
INFO - 2019-12-04 17:56:52 --> Language Class Initialized
INFO - 2019-12-04 17:56:52 --> Language Class Initialized
INFO - 2019-12-04 17:56:52 --> Config Class Initialized
INFO - 2019-12-04 17:56:52 --> Loader Class Initialized
INFO - 2019-12-04 17:56:52 --> Helper loaded: url_helper
INFO - 2019-12-04 17:56:52 --> Helper loaded: common_helper
INFO - 2019-12-04 17:56:52 --> Helper loaded: language_helper
INFO - 2019-12-04 17:56:52 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:56:52 --> Helper loaded: email_helper
INFO - 2019-12-04 17:56:52 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:56:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:56:52 --> Parser Class Initialized
INFO - 2019-12-04 17:56:52 --> User Agent Class Initialized
INFO - 2019-12-04 17:56:52 --> Model Class Initialized
INFO - 2019-12-04 17:56:52 --> Database Driver Class Initialized
INFO - 2019-12-04 17:56:52 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:52 --> Template Class Initialized
INFO - 2019-12-04 17:56:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:56:52 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:56:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:56:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:56:52 --> Encryption Class Initialized
INFO - 2019-12-04 17:56:52 --> Controller Class Initialized
DEBUG - 2019-12-04 17:56:52 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:56:52 --> Model Class Initialized
INFO - 2019-12-04 17:56:52 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:56:52 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:56:52 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:56:52 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:56:52 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:56:52 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:56:52 --> Model Class Initialized
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:56:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:56:52 --> Final output sent to browser
DEBUG - 2019-12-04 17:56:52 --> Total execution time: 0.6988
INFO - 2019-12-04 17:57:02 --> Config Class Initialized
INFO - 2019-12-04 17:57:02 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:57:02 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:57:02 --> Utf8 Class Initialized
INFO - 2019-12-04 17:57:02 --> URI Class Initialized
INFO - 2019-12-04 17:57:02 --> Router Class Initialized
INFO - 2019-12-04 17:57:02 --> Output Class Initialized
INFO - 2019-12-04 17:57:02 --> Security Class Initialized
DEBUG - 2019-12-04 17:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:57:02 --> CSRF cookie sent
INFO - 2019-12-04 17:57:02 --> CSRF token verified
INFO - 2019-12-04 17:57:02 --> Input Class Initialized
INFO - 2019-12-04 17:57:02 --> Language Class Initialized
INFO - 2019-12-04 17:57:02 --> Language Class Initialized
INFO - 2019-12-04 17:57:02 --> Config Class Initialized
INFO - 2019-12-04 17:57:02 --> Loader Class Initialized
INFO - 2019-12-04 17:57:02 --> Helper loaded: url_helper
INFO - 2019-12-04 17:57:02 --> Helper loaded: common_helper
INFO - 2019-12-04 17:57:02 --> Helper loaded: language_helper
INFO - 2019-12-04 17:57:02 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:57:02 --> Helper loaded: email_helper
INFO - 2019-12-04 17:57:02 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:57:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:57:02 --> Parser Class Initialized
INFO - 2019-12-04 17:57:02 --> User Agent Class Initialized
INFO - 2019-12-04 17:57:02 --> Model Class Initialized
INFO - 2019-12-04 17:57:02 --> Database Driver Class Initialized
INFO - 2019-12-04 17:57:02 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:02 --> Template Class Initialized
INFO - 2019-12-04 17:57:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:57:02 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:57:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:57:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:57:02 --> Encryption Class Initialized
INFO - 2019-12-04 17:57:02 --> Controller Class Initialized
DEBUG - 2019-12-04 17:57:02 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:57:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:57:02 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:02 --> payop MX_Controller Initialized
INFO - 2019-12-04 17:57:27 --> Config Class Initialized
INFO - 2019-12-04 17:57:27 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:57:27 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:57:27 --> Utf8 Class Initialized
INFO - 2019-12-04 17:57:27 --> URI Class Initialized
INFO - 2019-12-04 17:57:28 --> Router Class Initialized
INFO - 2019-12-04 17:57:28 --> Output Class Initialized
INFO - 2019-12-04 17:57:28 --> Security Class Initialized
DEBUG - 2019-12-04 17:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:57:28 --> CSRF cookie sent
INFO - 2019-12-04 17:57:28 --> CSRF token verified
INFO - 2019-12-04 17:57:28 --> Input Class Initialized
INFO - 2019-12-04 17:57:28 --> Language Class Initialized
INFO - 2019-12-04 17:57:28 --> Language Class Initialized
INFO - 2019-12-04 17:57:28 --> Config Class Initialized
INFO - 2019-12-04 17:57:28 --> Loader Class Initialized
INFO - 2019-12-04 17:57:28 --> Helper loaded: url_helper
INFO - 2019-12-04 17:57:28 --> Helper loaded: common_helper
INFO - 2019-12-04 17:57:28 --> Helper loaded: language_helper
INFO - 2019-12-04 17:57:28 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:57:28 --> Helper loaded: email_helper
INFO - 2019-12-04 17:57:28 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:57:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:57:28 --> Parser Class Initialized
INFO - 2019-12-04 17:57:28 --> User Agent Class Initialized
INFO - 2019-12-04 17:57:28 --> Model Class Initialized
INFO - 2019-12-04 17:57:28 --> Database Driver Class Initialized
INFO - 2019-12-04 17:57:28 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:28 --> Template Class Initialized
INFO - 2019-12-04 17:57:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:57:28 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:57:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:57:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:57:28 --> Encryption Class Initialized
INFO - 2019-12-04 17:57:28 --> Controller Class Initialized
DEBUG - 2019-12-04 17:57:28 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:57:28 --> Model Class Initialized
INFO - 2019-12-04 17:57:28 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 17:57:28 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 17:57:28 --> Could not find the language line "payop"
ERROR - 2019-12-04 17:57:28 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 17:57:28 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 17:57:28 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 17:57:28 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 17:57:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 17:57:28 --> Final output sent to browser
DEBUG - 2019-12-04 17:57:28 --> Total execution time: 0.7244
INFO - 2019-12-04 17:57:38 --> Config Class Initialized
INFO - 2019-12-04 17:57:38 --> Hooks Class Initialized
DEBUG - 2019-12-04 17:57:38 --> UTF-8 Support Enabled
INFO - 2019-12-04 17:57:38 --> Utf8 Class Initialized
INFO - 2019-12-04 17:57:38 --> URI Class Initialized
INFO - 2019-12-04 17:57:38 --> Router Class Initialized
INFO - 2019-12-04 17:57:38 --> Output Class Initialized
INFO - 2019-12-04 17:57:38 --> Security Class Initialized
DEBUG - 2019-12-04 17:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 17:57:38 --> CSRF cookie sent
INFO - 2019-12-04 17:57:38 --> CSRF token verified
INFO - 2019-12-04 17:57:38 --> Input Class Initialized
INFO - 2019-12-04 17:57:38 --> Language Class Initialized
INFO - 2019-12-04 17:57:38 --> Language Class Initialized
INFO - 2019-12-04 17:57:38 --> Config Class Initialized
INFO - 2019-12-04 17:57:38 --> Loader Class Initialized
INFO - 2019-12-04 17:57:38 --> Helper loaded: url_helper
INFO - 2019-12-04 17:57:38 --> Helper loaded: common_helper
INFO - 2019-12-04 17:57:38 --> Helper loaded: language_helper
INFO - 2019-12-04 17:57:38 --> Helper loaded: cookie_helper
INFO - 2019-12-04 17:57:38 --> Helper loaded: email_helper
INFO - 2019-12-04 17:57:38 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 17:57:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 17:57:38 --> Parser Class Initialized
INFO - 2019-12-04 17:57:38 --> User Agent Class Initialized
INFO - 2019-12-04 17:57:38 --> Model Class Initialized
INFO - 2019-12-04 17:57:38 --> Database Driver Class Initialized
INFO - 2019-12-04 17:57:38 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:38 --> Template Class Initialized
INFO - 2019-12-04 17:57:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 17:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 17:57:38 --> Pagination Class Initialized
DEBUG - 2019-12-04 17:57:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 17:57:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 17:57:38 --> Encryption Class Initialized
INFO - 2019-12-04 17:57:38 --> Controller Class Initialized
DEBUG - 2019-12-04 17:57:38 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 17:57:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 17:57:38 --> Model Class Initialized
DEBUG - 2019-12-04 17:57:38 --> payop MX_Controller Initialized
INFO - 2019-12-04 18:01:05 --> Config Class Initialized
INFO - 2019-12-04 18:01:05 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:01:05 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:01:05 --> Utf8 Class Initialized
INFO - 2019-12-04 18:01:05 --> URI Class Initialized
INFO - 2019-12-04 18:01:05 --> Router Class Initialized
INFO - 2019-12-04 18:01:05 --> Output Class Initialized
INFO - 2019-12-04 18:01:05 --> Security Class Initialized
DEBUG - 2019-12-04 18:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:01:05 --> CSRF cookie sent
INFO - 2019-12-04 18:01:05 --> CSRF token verified
INFO - 2019-12-04 18:01:05 --> Input Class Initialized
INFO - 2019-12-04 18:01:05 --> Language Class Initialized
INFO - 2019-12-04 18:01:05 --> Language Class Initialized
INFO - 2019-12-04 18:01:05 --> Config Class Initialized
INFO - 2019-12-04 18:01:05 --> Loader Class Initialized
INFO - 2019-12-04 18:01:05 --> Helper loaded: url_helper
INFO - 2019-12-04 18:01:05 --> Helper loaded: common_helper
INFO - 2019-12-04 18:01:05 --> Helper loaded: language_helper
INFO - 2019-12-04 18:01:05 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:01:05 --> Helper loaded: email_helper
INFO - 2019-12-04 18:01:05 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:01:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:01:05 --> Parser Class Initialized
INFO - 2019-12-04 18:01:05 --> User Agent Class Initialized
INFO - 2019-12-04 18:01:05 --> Model Class Initialized
INFO - 2019-12-04 18:01:05 --> Database Driver Class Initialized
INFO - 2019-12-04 18:01:05 --> Model Class Initialized
DEBUG - 2019-12-04 18:01:05 --> Template Class Initialized
INFO - 2019-12-04 18:01:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:01:05 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:01:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:01:05 --> Encryption Class Initialized
INFO - 2019-12-04 18:01:05 --> Controller Class Initialized
DEBUG - 2019-12-04 18:01:05 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:01:05 --> Model Class Initialized
INFO - 2019-12-04 18:01:05 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:01:05 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:01:05 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:01:05 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:01:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:01:05 --> Model Class Initialized
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:01:05 --> Model Class Initialized
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:01:05 --> Final output sent to browser
DEBUG - 2019-12-04 18:01:06 --> Total execution time: 0.7266
INFO - 2019-12-04 18:01:13 --> Config Class Initialized
INFO - 2019-12-04 18:01:13 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:01:13 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:01:13 --> Utf8 Class Initialized
INFO - 2019-12-04 18:01:13 --> URI Class Initialized
INFO - 2019-12-04 18:01:13 --> Router Class Initialized
INFO - 2019-12-04 18:01:13 --> Output Class Initialized
INFO - 2019-12-04 18:01:13 --> Security Class Initialized
DEBUG - 2019-12-04 18:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:01:13 --> CSRF cookie sent
INFO - 2019-12-04 18:01:13 --> CSRF token verified
INFO - 2019-12-04 18:01:13 --> Input Class Initialized
INFO - 2019-12-04 18:01:13 --> Language Class Initialized
INFO - 2019-12-04 18:01:13 --> Language Class Initialized
INFO - 2019-12-04 18:01:13 --> Config Class Initialized
INFO - 2019-12-04 18:01:13 --> Loader Class Initialized
INFO - 2019-12-04 18:01:13 --> Helper loaded: url_helper
INFO - 2019-12-04 18:01:13 --> Helper loaded: common_helper
INFO - 2019-12-04 18:01:13 --> Helper loaded: language_helper
INFO - 2019-12-04 18:01:14 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:01:14 --> Helper loaded: email_helper
INFO - 2019-12-04 18:01:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:01:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:01:14 --> Parser Class Initialized
INFO - 2019-12-04 18:01:14 --> User Agent Class Initialized
INFO - 2019-12-04 18:01:14 --> Model Class Initialized
INFO - 2019-12-04 18:01:14 --> Database Driver Class Initialized
INFO - 2019-12-04 18:01:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:01:14 --> Template Class Initialized
INFO - 2019-12-04 18:01:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:01:14 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:01:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:01:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:01:14 --> Encryption Class Initialized
INFO - 2019-12-04 18:01:14 --> Controller Class Initialized
DEBUG - 2019-12-04 18:01:14 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:01:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:01:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:01:14 --> payop MX_Controller Initialized
INFO - 2019-12-04 18:02:19 --> Config Class Initialized
INFO - 2019-12-04 18:02:19 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:02:19 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:02:19 --> Utf8 Class Initialized
INFO - 2019-12-04 18:02:19 --> URI Class Initialized
INFO - 2019-12-04 18:02:19 --> Router Class Initialized
INFO - 2019-12-04 18:02:19 --> Output Class Initialized
INFO - 2019-12-04 18:02:19 --> Security Class Initialized
DEBUG - 2019-12-04 18:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:02:19 --> CSRF cookie sent
INFO - 2019-12-04 18:02:19 --> CSRF token verified
INFO - 2019-12-04 18:02:19 --> Input Class Initialized
INFO - 2019-12-04 18:02:19 --> Language Class Initialized
INFO - 2019-12-04 18:02:19 --> Language Class Initialized
INFO - 2019-12-04 18:02:19 --> Config Class Initialized
INFO - 2019-12-04 18:02:19 --> Loader Class Initialized
INFO - 2019-12-04 18:02:19 --> Helper loaded: url_helper
INFO - 2019-12-04 18:02:19 --> Helper loaded: common_helper
INFO - 2019-12-04 18:02:19 --> Helper loaded: language_helper
INFO - 2019-12-04 18:02:19 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:02:19 --> Helper loaded: email_helper
INFO - 2019-12-04 18:02:19 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:02:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:02:19 --> Parser Class Initialized
INFO - 2019-12-04 18:02:19 --> User Agent Class Initialized
INFO - 2019-12-04 18:02:19 --> Model Class Initialized
INFO - 2019-12-04 18:02:19 --> Database Driver Class Initialized
INFO - 2019-12-04 18:02:19 --> Model Class Initialized
DEBUG - 2019-12-04 18:02:19 --> Template Class Initialized
INFO - 2019-12-04 18:02:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:02:19 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:02:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:02:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:02:19 --> Encryption Class Initialized
INFO - 2019-12-04 18:02:20 --> Controller Class Initialized
DEBUG - 2019-12-04 18:02:20 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:02:20 --> Model Class Initialized
INFO - 2019-12-04 18:02:20 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:02:20 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:02:20 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:02:20 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:02:20 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:02:20 --> Model Class Initialized
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:02:20 --> Model Class Initialized
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:02:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:02:20 --> Final output sent to browser
DEBUG - 2019-12-04 18:02:20 --> Total execution time: 0.7189
INFO - 2019-12-04 18:02:30 --> Config Class Initialized
INFO - 2019-12-04 18:02:30 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:02:30 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:02:30 --> Utf8 Class Initialized
INFO - 2019-12-04 18:02:30 --> URI Class Initialized
INFO - 2019-12-04 18:02:30 --> Router Class Initialized
INFO - 2019-12-04 18:02:30 --> Output Class Initialized
INFO - 2019-12-04 18:02:30 --> Security Class Initialized
DEBUG - 2019-12-04 18:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:02:30 --> CSRF cookie sent
INFO - 2019-12-04 18:02:30 --> CSRF token verified
INFO - 2019-12-04 18:02:30 --> Input Class Initialized
INFO - 2019-12-04 18:02:30 --> Language Class Initialized
INFO - 2019-12-04 18:02:30 --> Language Class Initialized
INFO - 2019-12-04 18:02:30 --> Config Class Initialized
INFO - 2019-12-04 18:02:30 --> Loader Class Initialized
INFO - 2019-12-04 18:02:30 --> Helper loaded: url_helper
INFO - 2019-12-04 18:02:30 --> Helper loaded: common_helper
INFO - 2019-12-04 18:02:30 --> Helper loaded: language_helper
INFO - 2019-12-04 18:02:30 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:02:30 --> Helper loaded: email_helper
INFO - 2019-12-04 18:02:30 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:02:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:02:30 --> Parser Class Initialized
INFO - 2019-12-04 18:02:30 --> User Agent Class Initialized
INFO - 2019-12-04 18:02:30 --> Model Class Initialized
INFO - 2019-12-04 18:02:30 --> Database Driver Class Initialized
INFO - 2019-12-04 18:02:30 --> Model Class Initialized
DEBUG - 2019-12-04 18:02:30 --> Template Class Initialized
INFO - 2019-12-04 18:02:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:02:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:02:30 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:02:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:02:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:02:30 --> Encryption Class Initialized
INFO - 2019-12-04 18:02:30 --> Controller Class Initialized
DEBUG - 2019-12-04 18:02:30 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:02:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:02:30 --> Model Class Initialized
DEBUG - 2019-12-04 18:02:30 --> payop MX_Controller Initialized
INFO - 2019-12-04 18:03:04 --> Config Class Initialized
INFO - 2019-12-04 18:03:04 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:03:04 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:03:04 --> Utf8 Class Initialized
INFO - 2019-12-04 18:03:04 --> URI Class Initialized
INFO - 2019-12-04 18:03:04 --> Router Class Initialized
INFO - 2019-12-04 18:03:04 --> Output Class Initialized
INFO - 2019-12-04 18:03:04 --> Security Class Initialized
DEBUG - 2019-12-04 18:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:03:04 --> CSRF cookie sent
INFO - 2019-12-04 18:03:04 --> CSRF token verified
INFO - 2019-12-04 18:03:04 --> Input Class Initialized
INFO - 2019-12-04 18:03:04 --> Language Class Initialized
INFO - 2019-12-04 18:03:04 --> Language Class Initialized
INFO - 2019-12-04 18:03:04 --> Config Class Initialized
INFO - 2019-12-04 18:03:04 --> Loader Class Initialized
INFO - 2019-12-04 18:03:04 --> Helper loaded: url_helper
INFO - 2019-12-04 18:03:04 --> Helper loaded: common_helper
INFO - 2019-12-04 18:03:04 --> Helper loaded: language_helper
INFO - 2019-12-04 18:03:04 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:03:04 --> Helper loaded: email_helper
INFO - 2019-12-04 18:03:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:03:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:03:04 --> Parser Class Initialized
INFO - 2019-12-04 18:03:04 --> User Agent Class Initialized
INFO - 2019-12-04 18:03:04 --> Model Class Initialized
INFO - 2019-12-04 18:03:04 --> Database Driver Class Initialized
INFO - 2019-12-04 18:03:04 --> Model Class Initialized
DEBUG - 2019-12-04 18:03:04 --> Template Class Initialized
INFO - 2019-12-04 18:03:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:03:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:03:04 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:03:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:03:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:03:04 --> Encryption Class Initialized
INFO - 2019-12-04 18:03:04 --> Controller Class Initialized
DEBUG - 2019-12-04 18:03:04 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:03:04 --> Model Class Initialized
INFO - 2019-12-04 18:03:04 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:03:04 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:03:04 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:03:04 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:03:04 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:03:04 --> Model Class Initialized
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:03:04 --> Model Class Initialized
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:03:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:03:04 --> Final output sent to browser
DEBUG - 2019-12-04 18:03:04 --> Total execution time: 0.7485
INFO - 2019-12-04 18:03:13 --> Config Class Initialized
INFO - 2019-12-04 18:03:13 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:03:13 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:03:13 --> Utf8 Class Initialized
INFO - 2019-12-04 18:03:13 --> URI Class Initialized
INFO - 2019-12-04 18:03:13 --> Router Class Initialized
INFO - 2019-12-04 18:03:13 --> Output Class Initialized
INFO - 2019-12-04 18:03:13 --> Security Class Initialized
DEBUG - 2019-12-04 18:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:03:13 --> CSRF cookie sent
INFO - 2019-12-04 18:03:13 --> CSRF token verified
INFO - 2019-12-04 18:03:13 --> Input Class Initialized
INFO - 2019-12-04 18:03:13 --> Language Class Initialized
INFO - 2019-12-04 18:03:13 --> Language Class Initialized
INFO - 2019-12-04 18:03:13 --> Config Class Initialized
INFO - 2019-12-04 18:03:13 --> Loader Class Initialized
INFO - 2019-12-04 18:03:14 --> Helper loaded: url_helper
INFO - 2019-12-04 18:03:14 --> Helper loaded: common_helper
INFO - 2019-12-04 18:03:14 --> Helper loaded: language_helper
INFO - 2019-12-04 18:03:14 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:03:14 --> Helper loaded: email_helper
INFO - 2019-12-04 18:03:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:03:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:03:14 --> Parser Class Initialized
INFO - 2019-12-04 18:03:14 --> User Agent Class Initialized
INFO - 2019-12-04 18:03:14 --> Model Class Initialized
INFO - 2019-12-04 18:03:14 --> Database Driver Class Initialized
INFO - 2019-12-04 18:03:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:03:14 --> Template Class Initialized
INFO - 2019-12-04 18:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:03:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:03:14 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:03:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:03:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:03:14 --> Encryption Class Initialized
INFO - 2019-12-04 18:03:14 --> Controller Class Initialized
DEBUG - 2019-12-04 18:03:14 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:03:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:03:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:03:14 --> payop MX_Controller Initialized
INFO - 2019-12-04 18:06:13 --> Config Class Initialized
INFO - 2019-12-04 18:06:13 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:06:13 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:06:13 --> Utf8 Class Initialized
INFO - 2019-12-04 18:06:13 --> URI Class Initialized
INFO - 2019-12-04 18:06:13 --> Router Class Initialized
INFO - 2019-12-04 18:06:13 --> Output Class Initialized
INFO - 2019-12-04 18:06:13 --> Security Class Initialized
DEBUG - 2019-12-04 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:06:13 --> CSRF cookie sent
INFO - 2019-12-04 18:06:13 --> CSRF token verified
INFO - 2019-12-04 18:06:13 --> Input Class Initialized
INFO - 2019-12-04 18:06:13 --> Language Class Initialized
INFO - 2019-12-04 18:06:13 --> Language Class Initialized
INFO - 2019-12-04 18:06:13 --> Config Class Initialized
INFO - 2019-12-04 18:06:13 --> Loader Class Initialized
INFO - 2019-12-04 18:06:13 --> Helper loaded: url_helper
INFO - 2019-12-04 18:06:13 --> Helper loaded: common_helper
INFO - 2019-12-04 18:06:14 --> Helper loaded: language_helper
INFO - 2019-12-04 18:06:14 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:06:14 --> Helper loaded: email_helper
INFO - 2019-12-04 18:06:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:06:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:06:14 --> Parser Class Initialized
INFO - 2019-12-04 18:06:14 --> User Agent Class Initialized
INFO - 2019-12-04 18:06:14 --> Model Class Initialized
INFO - 2019-12-04 18:06:14 --> Database Driver Class Initialized
INFO - 2019-12-04 18:06:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:06:14 --> Template Class Initialized
INFO - 2019-12-04 18:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:06:14 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:06:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:06:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:06:14 --> Encryption Class Initialized
INFO - 2019-12-04 18:06:14 --> Controller Class Initialized
DEBUG - 2019-12-04 18:06:14 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:06:14 --> Model Class Initialized
INFO - 2019-12-04 18:06:14 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:06:14 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:06:14 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:06:14 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:06:14 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:06:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:06:14 --> Model Class Initialized
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:06:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:06:14 --> Final output sent to browser
DEBUG - 2019-12-04 18:06:14 --> Total execution time: 0.8131
INFO - 2019-12-04 18:06:21 --> Config Class Initialized
INFO - 2019-12-04 18:06:21 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:06:21 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:06:21 --> Utf8 Class Initialized
INFO - 2019-12-04 18:06:21 --> URI Class Initialized
INFO - 2019-12-04 18:06:21 --> Router Class Initialized
INFO - 2019-12-04 18:06:21 --> Output Class Initialized
INFO - 2019-12-04 18:06:21 --> Security Class Initialized
DEBUG - 2019-12-04 18:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:06:21 --> CSRF cookie sent
INFO - 2019-12-04 18:06:21 --> CSRF token verified
INFO - 2019-12-04 18:06:21 --> Input Class Initialized
INFO - 2019-12-04 18:06:21 --> Language Class Initialized
INFO - 2019-12-04 18:06:21 --> Language Class Initialized
INFO - 2019-12-04 18:06:21 --> Config Class Initialized
INFO - 2019-12-04 18:06:21 --> Loader Class Initialized
INFO - 2019-12-04 18:06:21 --> Helper loaded: url_helper
INFO - 2019-12-04 18:06:21 --> Helper loaded: common_helper
INFO - 2019-12-04 18:06:21 --> Helper loaded: language_helper
INFO - 2019-12-04 18:06:21 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:06:21 --> Helper loaded: email_helper
INFO - 2019-12-04 18:06:21 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:06:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:06:21 --> Parser Class Initialized
INFO - 2019-12-04 18:06:21 --> User Agent Class Initialized
INFO - 2019-12-04 18:06:21 --> Model Class Initialized
INFO - 2019-12-04 18:06:21 --> Database Driver Class Initialized
INFO - 2019-12-04 18:06:22 --> Model Class Initialized
DEBUG - 2019-12-04 18:06:22 --> Template Class Initialized
INFO - 2019-12-04 18:06:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:06:22 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:06:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:06:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:06:22 --> Encryption Class Initialized
INFO - 2019-12-04 18:06:22 --> Controller Class Initialized
DEBUG - 2019-12-04 18:06:22 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:06:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:06:22 --> Model Class Initialized
DEBUG - 2019-12-04 18:06:22 --> payop MX_Controller Initialized
INFO - 2019-12-04 18:07:57 --> Config Class Initialized
INFO - 2019-12-04 18:07:57 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:07:57 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:07:57 --> Utf8 Class Initialized
INFO - 2019-12-04 18:07:57 --> URI Class Initialized
INFO - 2019-12-04 18:07:57 --> Router Class Initialized
INFO - 2019-12-04 18:07:57 --> Output Class Initialized
INFO - 2019-12-04 18:07:57 --> Security Class Initialized
DEBUG - 2019-12-04 18:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:07:57 --> CSRF cookie sent
INFO - 2019-12-04 18:07:57 --> CSRF token verified
INFO - 2019-12-04 18:07:57 --> Input Class Initialized
INFO - 2019-12-04 18:07:57 --> Language Class Initialized
INFO - 2019-12-04 18:07:57 --> Language Class Initialized
INFO - 2019-12-04 18:07:57 --> Config Class Initialized
INFO - 2019-12-04 18:07:57 --> Loader Class Initialized
INFO - 2019-12-04 18:07:57 --> Helper loaded: url_helper
INFO - 2019-12-04 18:07:57 --> Helper loaded: common_helper
INFO - 2019-12-04 18:07:57 --> Helper loaded: language_helper
INFO - 2019-12-04 18:07:57 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:07:57 --> Helper loaded: email_helper
INFO - 2019-12-04 18:07:57 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:07:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:07:57 --> Parser Class Initialized
INFO - 2019-12-04 18:07:57 --> User Agent Class Initialized
INFO - 2019-12-04 18:07:57 --> Model Class Initialized
INFO - 2019-12-04 18:07:57 --> Database Driver Class Initialized
INFO - 2019-12-04 18:07:57 --> Model Class Initialized
DEBUG - 2019-12-04 18:07:57 --> Template Class Initialized
INFO - 2019-12-04 18:07:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:07:57 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:07:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:07:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:07:57 --> Encryption Class Initialized
INFO - 2019-12-04 18:07:57 --> Controller Class Initialized
DEBUG - 2019-12-04 18:07:57 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:07:57 --> Model Class Initialized
INFO - 2019-12-04 18:07:57 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:07:57 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:07:57 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:07:57 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:07:57 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:07:57 --> Model Class Initialized
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:07:57 --> Model Class Initialized
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:07:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:07:57 --> Final output sent to browser
DEBUG - 2019-12-04 18:07:57 --> Total execution time: 0.7941
INFO - 2019-12-04 18:08:54 --> Config Class Initialized
INFO - 2019-12-04 18:08:54 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:08:54 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:08:54 --> Utf8 Class Initialized
INFO - 2019-12-04 18:08:54 --> URI Class Initialized
INFO - 2019-12-04 18:08:54 --> Router Class Initialized
INFO - 2019-12-04 18:08:54 --> Output Class Initialized
INFO - 2019-12-04 18:08:54 --> Security Class Initialized
DEBUG - 2019-12-04 18:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:08:55 --> CSRF cookie sent
INFO - 2019-12-04 18:08:55 --> CSRF token verified
INFO - 2019-12-04 18:08:55 --> Input Class Initialized
INFO - 2019-12-04 18:08:55 --> Language Class Initialized
INFO - 2019-12-04 18:08:55 --> Language Class Initialized
INFO - 2019-12-04 18:08:55 --> Config Class Initialized
INFO - 2019-12-04 18:08:55 --> Loader Class Initialized
INFO - 2019-12-04 18:08:55 --> Helper loaded: url_helper
INFO - 2019-12-04 18:08:55 --> Helper loaded: common_helper
INFO - 2019-12-04 18:08:55 --> Helper loaded: language_helper
INFO - 2019-12-04 18:08:55 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:08:55 --> Helper loaded: email_helper
INFO - 2019-12-04 18:08:55 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:08:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:08:55 --> Parser Class Initialized
INFO - 2019-12-04 18:08:55 --> User Agent Class Initialized
INFO - 2019-12-04 18:08:55 --> Model Class Initialized
INFO - 2019-12-04 18:08:55 --> Database Driver Class Initialized
INFO - 2019-12-04 18:08:55 --> Model Class Initialized
DEBUG - 2019-12-04 18:08:55 --> Template Class Initialized
INFO - 2019-12-04 18:08:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:08:55 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:08:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:08:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:08:55 --> Encryption Class Initialized
INFO - 2019-12-04 18:08:55 --> Controller Class Initialized
DEBUG - 2019-12-04 18:08:55 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:08:55 --> Model Class Initialized
INFO - 2019-12-04 18:08:55 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:08:55 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:08:55 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:08:55 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:08:55 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:08:55 --> Model Class Initialized
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:08:55 --> Model Class Initialized
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:08:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:08:55 --> Final output sent to browser
DEBUG - 2019-12-04 18:08:55 --> Total execution time: 0.8845
INFO - 2019-12-04 18:09:06 --> Config Class Initialized
INFO - 2019-12-04 18:09:06 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:09:06 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:09:06 --> Utf8 Class Initialized
INFO - 2019-12-04 18:09:06 --> URI Class Initialized
INFO - 2019-12-04 18:09:06 --> Router Class Initialized
INFO - 2019-12-04 18:09:06 --> Output Class Initialized
INFO - 2019-12-04 18:09:06 --> Security Class Initialized
DEBUG - 2019-12-04 18:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:09:06 --> CSRF cookie sent
INFO - 2019-12-04 18:09:06 --> CSRF token verified
INFO - 2019-12-04 18:09:06 --> Input Class Initialized
INFO - 2019-12-04 18:09:06 --> Language Class Initialized
INFO - 2019-12-04 18:09:06 --> Language Class Initialized
INFO - 2019-12-04 18:09:06 --> Config Class Initialized
INFO - 2019-12-04 18:09:06 --> Loader Class Initialized
INFO - 2019-12-04 18:09:06 --> Helper loaded: url_helper
INFO - 2019-12-04 18:09:06 --> Helper loaded: common_helper
INFO - 2019-12-04 18:09:06 --> Helper loaded: language_helper
INFO - 2019-12-04 18:09:06 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:09:06 --> Helper loaded: email_helper
INFO - 2019-12-04 18:09:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:09:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:09:06 --> Parser Class Initialized
INFO - 2019-12-04 18:09:06 --> User Agent Class Initialized
INFO - 2019-12-04 18:09:06 --> Model Class Initialized
INFO - 2019-12-04 18:09:06 --> Database Driver Class Initialized
INFO - 2019-12-04 18:09:06 --> Model Class Initialized
DEBUG - 2019-12-04 18:09:06 --> Template Class Initialized
INFO - 2019-12-04 18:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:09:06 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:09:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:09:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:09:06 --> Encryption Class Initialized
INFO - 2019-12-04 18:09:06 --> Controller Class Initialized
DEBUG - 2019-12-04 18:09:06 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:09:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:09:06 --> Model Class Initialized
DEBUG - 2019-12-04 18:09:06 --> payop MX_Controller Initialized
INFO - 2019-12-04 18:11:00 --> Config Class Initialized
INFO - 2019-12-04 18:11:00 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:11:00 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:11:00 --> Utf8 Class Initialized
INFO - 2019-12-04 18:11:00 --> URI Class Initialized
INFO - 2019-12-04 18:11:00 --> Router Class Initialized
INFO - 2019-12-04 18:11:00 --> Output Class Initialized
INFO - 2019-12-04 18:11:00 --> Security Class Initialized
DEBUG - 2019-12-04 18:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:11:00 --> CSRF cookie sent
INFO - 2019-12-04 18:11:00 --> CSRF token verified
INFO - 2019-12-04 18:11:00 --> Input Class Initialized
INFO - 2019-12-04 18:11:00 --> Language Class Initialized
INFO - 2019-12-04 18:11:00 --> Language Class Initialized
INFO - 2019-12-04 18:11:00 --> Config Class Initialized
INFO - 2019-12-04 18:11:00 --> Loader Class Initialized
INFO - 2019-12-04 18:11:00 --> Helper loaded: url_helper
INFO - 2019-12-04 18:11:00 --> Helper loaded: common_helper
INFO - 2019-12-04 18:11:00 --> Helper loaded: language_helper
INFO - 2019-12-04 18:11:00 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:11:00 --> Helper loaded: email_helper
INFO - 2019-12-04 18:11:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:11:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:11:00 --> Parser Class Initialized
INFO - 2019-12-04 18:11:00 --> User Agent Class Initialized
INFO - 2019-12-04 18:11:00 --> Model Class Initialized
INFO - 2019-12-04 18:11:00 --> Database Driver Class Initialized
INFO - 2019-12-04 18:11:00 --> Model Class Initialized
DEBUG - 2019-12-04 18:11:00 --> Template Class Initialized
INFO - 2019-12-04 18:11:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:11:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:11:00 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:11:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:11:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:11:00 --> Encryption Class Initialized
INFO - 2019-12-04 18:11:00 --> Controller Class Initialized
DEBUG - 2019-12-04 18:11:00 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:11:00 --> Model Class Initialized
INFO - 2019-12-04 18:11:00 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 18:11:00 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 18:11:00 --> Could not find the language line "payop"
ERROR - 2019-12-04 18:11:00 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 18:11:00 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 18:11:00 --> Model Class Initialized
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 18:11:00 --> Model Class Initialized
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 18:11:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 18:11:00 --> Final output sent to browser
DEBUG - 2019-12-04 18:11:00 --> Total execution time: 0.7561
INFO - 2019-12-04 18:11:09 --> Config Class Initialized
INFO - 2019-12-04 18:11:09 --> Hooks Class Initialized
DEBUG - 2019-12-04 18:11:09 --> UTF-8 Support Enabled
INFO - 2019-12-04 18:11:09 --> Utf8 Class Initialized
INFO - 2019-12-04 18:11:09 --> URI Class Initialized
INFO - 2019-12-04 18:11:09 --> Router Class Initialized
INFO - 2019-12-04 18:11:09 --> Output Class Initialized
INFO - 2019-12-04 18:11:09 --> Security Class Initialized
DEBUG - 2019-12-04 18:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 18:11:09 --> CSRF cookie sent
INFO - 2019-12-04 18:11:09 --> CSRF token verified
INFO - 2019-12-04 18:11:09 --> Input Class Initialized
INFO - 2019-12-04 18:11:09 --> Language Class Initialized
INFO - 2019-12-04 18:11:09 --> Language Class Initialized
INFO - 2019-12-04 18:11:09 --> Config Class Initialized
INFO - 2019-12-04 18:11:09 --> Loader Class Initialized
INFO - 2019-12-04 18:11:09 --> Helper loaded: url_helper
INFO - 2019-12-04 18:11:09 --> Helper loaded: common_helper
INFO - 2019-12-04 18:11:09 --> Helper loaded: language_helper
INFO - 2019-12-04 18:11:09 --> Helper loaded: cookie_helper
INFO - 2019-12-04 18:11:09 --> Helper loaded: email_helper
INFO - 2019-12-04 18:11:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 18:11:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 18:11:09 --> Parser Class Initialized
INFO - 2019-12-04 18:11:09 --> User Agent Class Initialized
INFO - 2019-12-04 18:11:09 --> Model Class Initialized
INFO - 2019-12-04 18:11:09 --> Database Driver Class Initialized
INFO - 2019-12-04 18:11:09 --> Model Class Initialized
DEBUG - 2019-12-04 18:11:09 --> Template Class Initialized
INFO - 2019-12-04 18:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 18:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 18:11:09 --> Pagination Class Initialized
DEBUG - 2019-12-04 18:11:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 18:11:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 18:11:09 --> Encryption Class Initialized
INFO - 2019-12-04 18:11:09 --> Controller Class Initialized
DEBUG - 2019-12-04 18:11:09 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 18:11:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 18:11:09 --> Model Class Initialized
DEBUG - 2019-12-04 18:11:09 --> payop MX_Controller Initialized
INFO - 2019-12-04 21:39:18 --> Config Class Initialized
INFO - 2019-12-04 21:39:18 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:39:18 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:39:18 --> Utf8 Class Initialized
INFO - 2019-12-04 21:39:18 --> URI Class Initialized
DEBUG - 2019-12-04 21:39:19 --> No URI present. Default controller set.
INFO - 2019-12-04 21:39:19 --> Router Class Initialized
INFO - 2019-12-04 21:39:19 --> Output Class Initialized
INFO - 2019-12-04 21:39:19 --> Security Class Initialized
DEBUG - 2019-12-04 21:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:39:19 --> CSRF cookie sent
INFO - 2019-12-04 21:39:19 --> Input Class Initialized
INFO - 2019-12-04 21:39:19 --> Language Class Initialized
INFO - 2019-12-04 21:39:19 --> Language Class Initialized
INFO - 2019-12-04 21:39:19 --> Config Class Initialized
INFO - 2019-12-04 21:39:19 --> Loader Class Initialized
INFO - 2019-12-04 21:39:19 --> Helper loaded: url_helper
INFO - 2019-12-04 21:39:19 --> Helper loaded: common_helper
INFO - 2019-12-04 21:39:19 --> Helper loaded: language_helper
INFO - 2019-12-04 21:39:19 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:39:19 --> Helper loaded: email_helper
INFO - 2019-12-04 21:39:19 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:39:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:39:19 --> Parser Class Initialized
INFO - 2019-12-04 21:39:19 --> User Agent Class Initialized
INFO - 2019-12-04 21:39:19 --> Model Class Initialized
INFO - 2019-12-04 21:39:19 --> Database Driver Class Initialized
INFO - 2019-12-04 21:39:19 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:19 --> Template Class Initialized
INFO - 2019-12-04 21:39:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:39:19 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:39:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:39:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:39:19 --> Encryption Class Initialized
DEBUG - 2019-12-04 21:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 21:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-04 21:39:19 --> Controller Class Initialized
DEBUG - 2019-12-04 21:39:19 --> pergo MX_Controller Initialized
DEBUG - 2019-12-04 21:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 21:39:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-04 21:39:19 --> Model Class Initialized
INFO - 2019-12-04 21:39:20 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 21:39:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-04 21:39:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-04 21:39:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-04 21:39:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-04 21:39:20 --> Final output sent to browser
DEBUG - 2019-12-04 21:39:20 --> Total execution time: 1.6037
INFO - 2019-12-04 21:39:25 --> Config Class Initialized
INFO - 2019-12-04 21:39:25 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:39:25 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:39:25 --> Utf8 Class Initialized
INFO - 2019-12-04 21:39:25 --> URI Class Initialized
INFO - 2019-12-04 21:39:25 --> Router Class Initialized
INFO - 2019-12-04 21:39:25 --> Output Class Initialized
INFO - 2019-12-04 21:39:25 --> Security Class Initialized
DEBUG - 2019-12-04 21:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:39:26 --> CSRF cookie sent
INFO - 2019-12-04 21:39:26 --> Input Class Initialized
INFO - 2019-12-04 21:39:26 --> Language Class Initialized
INFO - 2019-12-04 21:39:26 --> Language Class Initialized
INFO - 2019-12-04 21:39:26 --> Config Class Initialized
INFO - 2019-12-04 21:39:26 --> Loader Class Initialized
INFO - 2019-12-04 21:39:26 --> Helper loaded: url_helper
INFO - 2019-12-04 21:39:26 --> Helper loaded: common_helper
INFO - 2019-12-04 21:39:26 --> Helper loaded: language_helper
INFO - 2019-12-04 21:39:26 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:39:26 --> Helper loaded: email_helper
INFO - 2019-12-04 21:39:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:39:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:39:26 --> Parser Class Initialized
INFO - 2019-12-04 21:39:26 --> User Agent Class Initialized
INFO - 2019-12-04 21:39:26 --> Model Class Initialized
INFO - 2019-12-04 21:39:26 --> Database Driver Class Initialized
INFO - 2019-12-04 21:39:26 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:26 --> Template Class Initialized
INFO - 2019-12-04 21:39:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:39:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:39:26 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:39:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:39:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:39:26 --> Encryption Class Initialized
INFO - 2019-12-04 21:39:26 --> Controller Class Initialized
DEBUG - 2019-12-04 21:39:26 --> package MX_Controller Initialized
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-04 21:39:26 --> Model Class Initialized
INFO - 2019-12-04 21:39:26 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 21:39:26 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 21:39:26 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 21:39:26 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-04 21:39:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 21:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 21:39:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 21:39:27 --> Final output sent to browser
DEBUG - 2019-12-04 21:39:27 --> Total execution time: 1.3089
INFO - 2019-12-04 21:39:48 --> Config Class Initialized
INFO - 2019-12-04 21:39:48 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:39:49 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:39:49 --> Utf8 Class Initialized
INFO - 2019-12-04 21:39:49 --> URI Class Initialized
INFO - 2019-12-04 21:39:49 --> Router Class Initialized
INFO - 2019-12-04 21:39:49 --> Output Class Initialized
INFO - 2019-12-04 21:39:49 --> Security Class Initialized
DEBUG - 2019-12-04 21:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:39:49 --> CSRF cookie sent
INFO - 2019-12-04 21:39:49 --> CSRF token verified
INFO - 2019-12-04 21:39:49 --> Input Class Initialized
INFO - 2019-12-04 21:39:49 --> Language Class Initialized
INFO - 2019-12-04 21:39:49 --> Language Class Initialized
INFO - 2019-12-04 21:39:49 --> Config Class Initialized
INFO - 2019-12-04 21:39:49 --> Loader Class Initialized
INFO - 2019-12-04 21:39:49 --> Helper loaded: url_helper
INFO - 2019-12-04 21:39:49 --> Helper loaded: common_helper
INFO - 2019-12-04 21:39:49 --> Helper loaded: language_helper
INFO - 2019-12-04 21:39:49 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:39:49 --> Helper loaded: email_helper
INFO - 2019-12-04 21:39:49 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:39:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:39:49 --> Parser Class Initialized
INFO - 2019-12-04 21:39:49 --> User Agent Class Initialized
INFO - 2019-12-04 21:39:49 --> Model Class Initialized
INFO - 2019-12-04 21:39:49 --> Database Driver Class Initialized
INFO - 2019-12-04 21:39:49 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:49 --> Template Class Initialized
INFO - 2019-12-04 21:39:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:39:49 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:39:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:39:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:39:49 --> Encryption Class Initialized
INFO - 2019-12-04 21:39:49 --> Controller Class Initialized
DEBUG - 2019-12-04 21:39:49 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:39:49 --> Model Class Initialized
INFO - 2019-12-04 21:39:49 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 21:39:49 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 21:39:49 --> Could not find the language line "payop"
ERROR - 2019-12-04 21:39:49 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 21:39:49 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 21:39:49 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 21:39:49 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 21:39:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 21:39:49 --> Final output sent to browser
DEBUG - 2019-12-04 21:39:49 --> Total execution time: 0.8979
INFO - 2019-12-04 21:39:58 --> Config Class Initialized
INFO - 2019-12-04 21:39:58 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:39:58 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:39:58 --> Utf8 Class Initialized
INFO - 2019-12-04 21:39:58 --> URI Class Initialized
INFO - 2019-12-04 21:39:58 --> Router Class Initialized
INFO - 2019-12-04 21:39:58 --> Output Class Initialized
INFO - 2019-12-04 21:39:58 --> Security Class Initialized
DEBUG - 2019-12-04 21:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:39:58 --> CSRF cookie sent
INFO - 2019-12-04 21:39:58 --> CSRF token verified
INFO - 2019-12-04 21:39:58 --> Input Class Initialized
INFO - 2019-12-04 21:39:58 --> Language Class Initialized
INFO - 2019-12-04 21:39:58 --> Language Class Initialized
INFO - 2019-12-04 21:39:58 --> Config Class Initialized
INFO - 2019-12-04 21:39:58 --> Loader Class Initialized
INFO - 2019-12-04 21:39:58 --> Helper loaded: url_helper
INFO - 2019-12-04 21:39:58 --> Helper loaded: common_helper
INFO - 2019-12-04 21:39:58 --> Helper loaded: language_helper
INFO - 2019-12-04 21:39:58 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:39:58 --> Helper loaded: email_helper
INFO - 2019-12-04 21:39:58 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:39:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:39:58 --> Parser Class Initialized
INFO - 2019-12-04 21:39:58 --> User Agent Class Initialized
INFO - 2019-12-04 21:39:58 --> Model Class Initialized
INFO - 2019-12-04 21:39:58 --> Database Driver Class Initialized
INFO - 2019-12-04 21:39:58 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:58 --> Template Class Initialized
INFO - 2019-12-04 21:39:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:39:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:39:58 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:39:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:39:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:39:58 --> Encryption Class Initialized
INFO - 2019-12-04 21:39:58 --> Controller Class Initialized
DEBUG - 2019-12-04 21:39:58 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:39:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:39:58 --> Model Class Initialized
DEBUG - 2019-12-04 21:39:58 --> payop MX_Controller Initialized
INFO - 2019-12-04 21:53:04 --> Config Class Initialized
INFO - 2019-12-04 21:53:04 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:53:04 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:53:04 --> Utf8 Class Initialized
INFO - 2019-12-04 21:53:04 --> URI Class Initialized
INFO - 2019-12-04 21:53:04 --> Router Class Initialized
INFO - 2019-12-04 21:53:04 --> Output Class Initialized
INFO - 2019-12-04 21:53:04 --> Security Class Initialized
DEBUG - 2019-12-04 21:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:53:04 --> CSRF cookie sent
INFO - 2019-12-04 21:53:04 --> CSRF token verified
INFO - 2019-12-04 21:53:04 --> Input Class Initialized
INFO - 2019-12-04 21:53:04 --> Language Class Initialized
INFO - 2019-12-04 21:53:04 --> Language Class Initialized
INFO - 2019-12-04 21:53:04 --> Config Class Initialized
INFO - 2019-12-04 21:53:04 --> Loader Class Initialized
INFO - 2019-12-04 21:53:04 --> Helper loaded: url_helper
INFO - 2019-12-04 21:53:04 --> Helper loaded: common_helper
INFO - 2019-12-04 21:53:04 --> Helper loaded: language_helper
INFO - 2019-12-04 21:53:04 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:53:04 --> Helper loaded: email_helper
INFO - 2019-12-04 21:53:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:53:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:53:04 --> Parser Class Initialized
INFO - 2019-12-04 21:53:04 --> User Agent Class Initialized
INFO - 2019-12-04 21:53:04 --> Model Class Initialized
INFO - 2019-12-04 21:53:04 --> Database Driver Class Initialized
INFO - 2019-12-04 21:53:04 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:04 --> Template Class Initialized
INFO - 2019-12-04 21:53:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:53:04 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:53:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:53:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:53:04 --> Encryption Class Initialized
INFO - 2019-12-04 21:53:05 --> Controller Class Initialized
DEBUG - 2019-12-04 21:53:05 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:53:05 --> Model Class Initialized
INFO - 2019-12-04 21:53:05 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 21:53:05 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 21:53:05 --> Could not find the language line "payop"
ERROR - 2019-12-04 21:53:05 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 21:53:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 21:53:05 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 21:53:05 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 21:53:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 21:53:05 --> Final output sent to browser
DEBUG - 2019-12-04 21:53:05 --> Total execution time: 0.8186
INFO - 2019-12-04 21:53:15 --> Config Class Initialized
INFO - 2019-12-04 21:53:15 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:53:15 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:53:15 --> Utf8 Class Initialized
INFO - 2019-12-04 21:53:15 --> URI Class Initialized
INFO - 2019-12-04 21:53:15 --> Router Class Initialized
INFO - 2019-12-04 21:53:15 --> Output Class Initialized
INFO - 2019-12-04 21:53:15 --> Security Class Initialized
DEBUG - 2019-12-04 21:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:53:15 --> CSRF cookie sent
INFO - 2019-12-04 21:53:15 --> CSRF token verified
INFO - 2019-12-04 21:53:15 --> Input Class Initialized
INFO - 2019-12-04 21:53:15 --> Language Class Initialized
INFO - 2019-12-04 21:53:15 --> Language Class Initialized
INFO - 2019-12-04 21:53:15 --> Config Class Initialized
INFO - 2019-12-04 21:53:15 --> Loader Class Initialized
INFO - 2019-12-04 21:53:15 --> Helper loaded: url_helper
INFO - 2019-12-04 21:53:15 --> Helper loaded: common_helper
INFO - 2019-12-04 21:53:15 --> Helper loaded: language_helper
INFO - 2019-12-04 21:53:15 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:53:15 --> Helper loaded: email_helper
INFO - 2019-12-04 21:53:15 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:53:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:53:15 --> Parser Class Initialized
INFO - 2019-12-04 21:53:15 --> User Agent Class Initialized
INFO - 2019-12-04 21:53:15 --> Model Class Initialized
INFO - 2019-12-04 21:53:15 --> Database Driver Class Initialized
INFO - 2019-12-04 21:53:15 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:15 --> Template Class Initialized
INFO - 2019-12-04 21:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:53:15 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:53:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:53:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:53:15 --> Encryption Class Initialized
INFO - 2019-12-04 21:53:15 --> Controller Class Initialized
DEBUG - 2019-12-04 21:53:15 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:53:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:53:15 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:15 --> payop MX_Controller Initialized
ERROR - 2019-12-04 21:53:15 --> Severity: Notice --> Undefined variable: secretKey D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 97
INFO - 2019-12-04 21:53:52 --> Config Class Initialized
INFO - 2019-12-04 21:53:52 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:53:52 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:53:52 --> Utf8 Class Initialized
INFO - 2019-12-04 21:53:52 --> URI Class Initialized
INFO - 2019-12-04 21:53:52 --> Router Class Initialized
INFO - 2019-12-04 21:53:52 --> Output Class Initialized
INFO - 2019-12-04 21:53:52 --> Security Class Initialized
DEBUG - 2019-12-04 21:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:53:52 --> CSRF cookie sent
INFO - 2019-12-04 21:53:52 --> CSRF token verified
INFO - 2019-12-04 21:53:52 --> Input Class Initialized
INFO - 2019-12-04 21:53:52 --> Language Class Initialized
INFO - 2019-12-04 21:53:52 --> Language Class Initialized
INFO - 2019-12-04 21:53:52 --> Config Class Initialized
INFO - 2019-12-04 21:53:52 --> Loader Class Initialized
INFO - 2019-12-04 21:53:52 --> Helper loaded: url_helper
INFO - 2019-12-04 21:53:52 --> Helper loaded: common_helper
INFO - 2019-12-04 21:53:52 --> Helper loaded: language_helper
INFO - 2019-12-04 21:53:52 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:53:52 --> Helper loaded: email_helper
INFO - 2019-12-04 21:53:52 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:53:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:53:52 --> Parser Class Initialized
INFO - 2019-12-04 21:53:52 --> User Agent Class Initialized
INFO - 2019-12-04 21:53:52 --> Model Class Initialized
INFO - 2019-12-04 21:53:52 --> Database Driver Class Initialized
INFO - 2019-12-04 21:53:52 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:52 --> Template Class Initialized
INFO - 2019-12-04 21:53:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:53:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:53:52 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:53:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:53:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:53:52 --> Encryption Class Initialized
INFO - 2019-12-04 21:53:52 --> Controller Class Initialized
DEBUG - 2019-12-04 21:53:52 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:53:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:53:52 --> Model Class Initialized
INFO - 2019-12-04 21:53:52 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 21:53:53 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 21:53:53 --> Could not find the language line "payop"
ERROR - 2019-12-04 21:53:53 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 21:53:53 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 21:53:53 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 21:53:53 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 21:53:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 21:53:53 --> Final output sent to browser
DEBUG - 2019-12-04 21:53:53 --> Total execution time: 0.8706
INFO - 2019-12-04 21:53:55 --> Config Class Initialized
INFO - 2019-12-04 21:53:55 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:53:55 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:53:55 --> Utf8 Class Initialized
INFO - 2019-12-04 21:53:55 --> URI Class Initialized
INFO - 2019-12-04 21:53:55 --> Router Class Initialized
INFO - 2019-12-04 21:53:55 --> Output Class Initialized
INFO - 2019-12-04 21:53:55 --> Security Class Initialized
DEBUG - 2019-12-04 21:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:53:55 --> CSRF cookie sent
INFO - 2019-12-04 21:53:55 --> CSRF token verified
INFO - 2019-12-04 21:53:55 --> Input Class Initialized
INFO - 2019-12-04 21:53:55 --> Language Class Initialized
INFO - 2019-12-04 21:53:55 --> Language Class Initialized
INFO - 2019-12-04 21:53:55 --> Config Class Initialized
INFO - 2019-12-04 21:53:55 --> Loader Class Initialized
INFO - 2019-12-04 21:53:55 --> Helper loaded: url_helper
INFO - 2019-12-04 21:53:55 --> Helper loaded: common_helper
INFO - 2019-12-04 21:53:55 --> Helper loaded: language_helper
INFO - 2019-12-04 21:53:55 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:53:55 --> Helper loaded: email_helper
INFO - 2019-12-04 21:53:55 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:53:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:53:55 --> Parser Class Initialized
INFO - 2019-12-04 21:53:55 --> User Agent Class Initialized
INFO - 2019-12-04 21:53:56 --> Model Class Initialized
INFO - 2019-12-04 21:53:56 --> Database Driver Class Initialized
INFO - 2019-12-04 21:53:56 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:56 --> Template Class Initialized
INFO - 2019-12-04 21:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:53:56 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:53:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:53:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:53:56 --> Encryption Class Initialized
INFO - 2019-12-04 21:53:56 --> Controller Class Initialized
DEBUG - 2019-12-04 21:53:56 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:53:56 --> Model Class Initialized
INFO - 2019-12-04 21:53:56 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 21:53:56 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 21:53:56 --> Could not find the language line "payop"
ERROR - 2019-12-04 21:53:56 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 21:53:56 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 21:53:56 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 21:53:56 --> Model Class Initialized
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 21:53:56 --> Final output sent to browser
DEBUG - 2019-12-04 21:53:56 --> Total execution time: 0.8529
INFO - 2019-12-04 21:54:05 --> Config Class Initialized
INFO - 2019-12-04 21:54:05 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:54:05 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:54:05 --> Utf8 Class Initialized
INFO - 2019-12-04 21:54:05 --> URI Class Initialized
INFO - 2019-12-04 21:54:05 --> Router Class Initialized
INFO - 2019-12-04 21:54:05 --> Output Class Initialized
INFO - 2019-12-04 21:54:05 --> Security Class Initialized
DEBUG - 2019-12-04 21:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:54:05 --> CSRF cookie sent
INFO - 2019-12-04 21:54:05 --> CSRF token verified
INFO - 2019-12-04 21:54:05 --> Input Class Initialized
INFO - 2019-12-04 21:54:05 --> Language Class Initialized
INFO - 2019-12-04 21:54:06 --> Language Class Initialized
INFO - 2019-12-04 21:54:06 --> Config Class Initialized
INFO - 2019-12-04 21:54:06 --> Loader Class Initialized
INFO - 2019-12-04 21:54:06 --> Helper loaded: url_helper
INFO - 2019-12-04 21:54:06 --> Helper loaded: common_helper
INFO - 2019-12-04 21:54:06 --> Helper loaded: language_helper
INFO - 2019-12-04 21:54:06 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:54:06 --> Helper loaded: email_helper
INFO - 2019-12-04 21:54:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:54:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:54:06 --> Parser Class Initialized
INFO - 2019-12-04 21:54:06 --> User Agent Class Initialized
INFO - 2019-12-04 21:54:06 --> Model Class Initialized
INFO - 2019-12-04 21:54:06 --> Database Driver Class Initialized
INFO - 2019-12-04 21:54:06 --> Model Class Initialized
DEBUG - 2019-12-04 21:54:06 --> Template Class Initialized
INFO - 2019-12-04 21:54:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:54:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:54:06 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:54:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:54:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:54:06 --> Encryption Class Initialized
INFO - 2019-12-04 21:54:06 --> Controller Class Initialized
DEBUG - 2019-12-04 21:54:06 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:54:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:54:06 --> Model Class Initialized
ERROR - 2019-12-04 21:54:06 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 59
INFO - 2019-12-04 21:54:26 --> Config Class Initialized
INFO - 2019-12-04 21:54:26 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:54:26 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:54:26 --> Utf8 Class Initialized
INFO - 2019-12-04 21:54:26 --> URI Class Initialized
INFO - 2019-12-04 21:54:26 --> Router Class Initialized
INFO - 2019-12-04 21:54:27 --> Output Class Initialized
INFO - 2019-12-04 21:54:27 --> Security Class Initialized
DEBUG - 2019-12-04 21:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:54:27 --> CSRF cookie sent
INFO - 2019-12-04 21:54:27 --> CSRF token verified
INFO - 2019-12-04 21:54:27 --> Input Class Initialized
INFO - 2019-12-04 21:54:27 --> Language Class Initialized
INFO - 2019-12-04 21:54:27 --> Language Class Initialized
INFO - 2019-12-04 21:54:27 --> Config Class Initialized
INFO - 2019-12-04 21:54:27 --> Loader Class Initialized
INFO - 2019-12-04 21:54:27 --> Helper loaded: url_helper
INFO - 2019-12-04 21:54:27 --> Helper loaded: common_helper
INFO - 2019-12-04 21:54:27 --> Helper loaded: language_helper
INFO - 2019-12-04 21:54:27 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:54:27 --> Helper loaded: email_helper
INFO - 2019-12-04 21:54:27 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:54:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:54:27 --> Parser Class Initialized
INFO - 2019-12-04 21:54:27 --> User Agent Class Initialized
INFO - 2019-12-04 21:54:27 --> Model Class Initialized
INFO - 2019-12-04 21:54:27 --> Database Driver Class Initialized
INFO - 2019-12-04 21:54:27 --> Model Class Initialized
DEBUG - 2019-12-04 21:54:27 --> Template Class Initialized
INFO - 2019-12-04 21:54:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:54:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:54:27 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:54:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:54:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:54:27 --> Encryption Class Initialized
INFO - 2019-12-04 21:54:27 --> Controller Class Initialized
DEBUG - 2019-12-04 21:54:27 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:54:27 --> Model Class Initialized
INFO - 2019-12-04 21:54:27 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 21:54:27 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 21:54:27 --> Could not find the language line "payop"
ERROR - 2019-12-04 21:54:27 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 21:54:27 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 21:54:27 --> Model Class Initialized
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 21:54:27 --> Model Class Initialized
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 21:54:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 21:54:27 --> Final output sent to browser
DEBUG - 2019-12-04 21:54:27 --> Total execution time: 0.8898
INFO - 2019-12-04 21:54:37 --> Config Class Initialized
INFO - 2019-12-04 21:54:37 --> Hooks Class Initialized
DEBUG - 2019-12-04 21:54:37 --> UTF-8 Support Enabled
INFO - 2019-12-04 21:54:37 --> Utf8 Class Initialized
INFO - 2019-12-04 21:54:37 --> URI Class Initialized
INFO - 2019-12-04 21:54:37 --> Router Class Initialized
INFO - 2019-12-04 21:54:37 --> Output Class Initialized
INFO - 2019-12-04 21:54:37 --> Security Class Initialized
DEBUG - 2019-12-04 21:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 21:54:37 --> CSRF cookie sent
INFO - 2019-12-04 21:54:37 --> CSRF token verified
INFO - 2019-12-04 21:54:37 --> Input Class Initialized
INFO - 2019-12-04 21:54:37 --> Language Class Initialized
INFO - 2019-12-04 21:54:37 --> Language Class Initialized
INFO - 2019-12-04 21:54:37 --> Config Class Initialized
INFO - 2019-12-04 21:54:37 --> Loader Class Initialized
INFO - 2019-12-04 21:54:37 --> Helper loaded: url_helper
INFO - 2019-12-04 21:54:37 --> Helper loaded: common_helper
INFO - 2019-12-04 21:54:37 --> Helper loaded: language_helper
INFO - 2019-12-04 21:54:37 --> Helper loaded: cookie_helper
INFO - 2019-12-04 21:54:37 --> Helper loaded: email_helper
INFO - 2019-12-04 21:54:37 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 21:54:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 21:54:37 --> Parser Class Initialized
INFO - 2019-12-04 21:54:37 --> User Agent Class Initialized
INFO - 2019-12-04 21:54:37 --> Model Class Initialized
INFO - 2019-12-04 21:54:37 --> Database Driver Class Initialized
INFO - 2019-12-04 21:54:37 --> Model Class Initialized
DEBUG - 2019-12-04 21:54:37 --> Template Class Initialized
INFO - 2019-12-04 21:54:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 21:54:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 21:54:37 --> Pagination Class Initialized
DEBUG - 2019-12-04 21:54:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 21:54:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 21:54:37 --> Encryption Class Initialized
INFO - 2019-12-04 21:54:37 --> Controller Class Initialized
DEBUG - 2019-12-04 21:54:37 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 21:54:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 21:54:37 --> Model Class Initialized
DEBUG - 2019-12-04 21:54:37 --> payop MX_Controller Initialized
INFO - 2019-12-04 22:05:21 --> Config Class Initialized
INFO - 2019-12-04 22:05:21 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:05:21 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:05:21 --> Utf8 Class Initialized
INFO - 2019-12-04 22:05:21 --> URI Class Initialized
INFO - 2019-12-04 22:05:21 --> Router Class Initialized
INFO - 2019-12-04 22:05:21 --> Output Class Initialized
INFO - 2019-12-04 22:05:21 --> Security Class Initialized
DEBUG - 2019-12-04 22:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:05:21 --> CSRF cookie sent
INFO - 2019-12-04 22:05:21 --> CSRF token verified
INFO - 2019-12-04 22:05:22 --> Input Class Initialized
INFO - 2019-12-04 22:05:22 --> Language Class Initialized
INFO - 2019-12-04 22:05:22 --> Language Class Initialized
INFO - 2019-12-04 22:05:22 --> Config Class Initialized
INFO - 2019-12-04 22:05:22 --> Loader Class Initialized
INFO - 2019-12-04 22:05:22 --> Helper loaded: url_helper
INFO - 2019-12-04 22:05:22 --> Helper loaded: common_helper
INFO - 2019-12-04 22:05:22 --> Helper loaded: language_helper
INFO - 2019-12-04 22:05:22 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:05:22 --> Helper loaded: email_helper
INFO - 2019-12-04 22:05:22 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:05:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:05:22 --> Parser Class Initialized
INFO - 2019-12-04 22:05:22 --> User Agent Class Initialized
INFO - 2019-12-04 22:05:22 --> Model Class Initialized
INFO - 2019-12-04 22:05:22 --> Database Driver Class Initialized
INFO - 2019-12-04 22:05:22 --> Model Class Initialized
DEBUG - 2019-12-04 22:05:22 --> Template Class Initialized
INFO - 2019-12-04 22:05:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:05:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:05:22 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:05:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:05:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:05:22 --> Encryption Class Initialized
INFO - 2019-12-04 22:05:22 --> Controller Class Initialized
DEBUG - 2019-12-04 22:05:22 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:05:22 --> Model Class Initialized
INFO - 2019-12-04 22:05:22 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:05:22 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:05:22 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:05:22 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:05:22 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:05:22 --> Model Class Initialized
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:05:22 --> Model Class Initialized
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:05:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:05:22 --> Final output sent to browser
DEBUG - 2019-12-04 22:05:22 --> Total execution time: 0.9234
INFO - 2019-12-04 22:05:30 --> Config Class Initialized
INFO - 2019-12-04 22:05:30 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:05:30 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:05:30 --> Utf8 Class Initialized
INFO - 2019-12-04 22:05:30 --> URI Class Initialized
INFO - 2019-12-04 22:05:30 --> Router Class Initialized
INFO - 2019-12-04 22:05:30 --> Output Class Initialized
INFO - 2019-12-04 22:05:30 --> Security Class Initialized
DEBUG - 2019-12-04 22:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:05:30 --> CSRF cookie sent
INFO - 2019-12-04 22:05:30 --> CSRF token verified
INFO - 2019-12-04 22:05:30 --> Input Class Initialized
INFO - 2019-12-04 22:05:30 --> Language Class Initialized
INFO - 2019-12-04 22:05:30 --> Language Class Initialized
INFO - 2019-12-04 22:05:30 --> Config Class Initialized
INFO - 2019-12-04 22:05:30 --> Loader Class Initialized
INFO - 2019-12-04 22:05:30 --> Helper loaded: url_helper
INFO - 2019-12-04 22:05:30 --> Helper loaded: common_helper
INFO - 2019-12-04 22:05:30 --> Helper loaded: language_helper
INFO - 2019-12-04 22:05:30 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:05:30 --> Helper loaded: email_helper
INFO - 2019-12-04 22:05:30 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:05:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:05:30 --> Parser Class Initialized
INFO - 2019-12-04 22:05:30 --> User Agent Class Initialized
INFO - 2019-12-04 22:05:30 --> Model Class Initialized
INFO - 2019-12-04 22:05:30 --> Database Driver Class Initialized
INFO - 2019-12-04 22:05:30 --> Model Class Initialized
DEBUG - 2019-12-04 22:05:31 --> Template Class Initialized
INFO - 2019-12-04 22:05:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:05:31 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:05:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:05:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:05:31 --> Encryption Class Initialized
INFO - 2019-12-04 22:05:31 --> Controller Class Initialized
DEBUG - 2019-12-04 22:05:31 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:05:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:05:31 --> Model Class Initialized
DEBUG - 2019-12-04 22:05:31 --> payop MX_Controller Initialized
INFO - 2019-12-04 22:06:56 --> Config Class Initialized
INFO - 2019-12-04 22:06:56 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:06:56 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:06:56 --> Utf8 Class Initialized
INFO - 2019-12-04 22:06:56 --> URI Class Initialized
INFO - 2019-12-04 22:06:56 --> Router Class Initialized
INFO - 2019-12-04 22:06:56 --> Output Class Initialized
INFO - 2019-12-04 22:06:56 --> Security Class Initialized
DEBUG - 2019-12-04 22:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:06:56 --> CSRF cookie sent
INFO - 2019-12-04 22:06:56 --> CSRF token verified
INFO - 2019-12-04 22:06:56 --> Input Class Initialized
INFO - 2019-12-04 22:06:56 --> Language Class Initialized
INFO - 2019-12-04 22:06:56 --> Language Class Initialized
INFO - 2019-12-04 22:06:56 --> Config Class Initialized
INFO - 2019-12-04 22:06:56 --> Loader Class Initialized
INFO - 2019-12-04 22:06:56 --> Helper loaded: url_helper
INFO - 2019-12-04 22:06:57 --> Helper loaded: common_helper
INFO - 2019-12-04 22:06:57 --> Helper loaded: language_helper
INFO - 2019-12-04 22:06:57 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:06:57 --> Helper loaded: email_helper
INFO - 2019-12-04 22:06:57 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:06:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:06:57 --> Parser Class Initialized
INFO - 2019-12-04 22:06:57 --> User Agent Class Initialized
INFO - 2019-12-04 22:06:57 --> Model Class Initialized
INFO - 2019-12-04 22:06:57 --> Database Driver Class Initialized
INFO - 2019-12-04 22:06:57 --> Model Class Initialized
DEBUG - 2019-12-04 22:06:57 --> Template Class Initialized
INFO - 2019-12-04 22:06:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:06:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:06:57 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:06:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:06:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:06:57 --> Encryption Class Initialized
INFO - 2019-12-04 22:06:57 --> Controller Class Initialized
DEBUG - 2019-12-04 22:06:57 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:06:57 --> Model Class Initialized
INFO - 2019-12-04 22:06:57 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:06:57 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:06:57 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:06:57 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:06:57 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:06:57 --> Model Class Initialized
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:06:57 --> Model Class Initialized
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:06:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:06:57 --> Final output sent to browser
DEBUG - 2019-12-04 22:06:57 --> Total execution time: 0.8806
INFO - 2019-12-04 22:07:06 --> Config Class Initialized
INFO - 2019-12-04 22:07:07 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:07:07 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:07:07 --> Utf8 Class Initialized
INFO - 2019-12-04 22:07:07 --> URI Class Initialized
INFO - 2019-12-04 22:07:07 --> Router Class Initialized
INFO - 2019-12-04 22:07:07 --> Output Class Initialized
INFO - 2019-12-04 22:07:07 --> Security Class Initialized
DEBUG - 2019-12-04 22:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:07:07 --> CSRF cookie sent
INFO - 2019-12-04 22:07:07 --> CSRF token verified
INFO - 2019-12-04 22:07:07 --> Input Class Initialized
INFO - 2019-12-04 22:07:07 --> Language Class Initialized
INFO - 2019-12-04 22:07:07 --> Language Class Initialized
INFO - 2019-12-04 22:07:07 --> Config Class Initialized
INFO - 2019-12-04 22:07:07 --> Loader Class Initialized
INFO - 2019-12-04 22:07:07 --> Helper loaded: url_helper
INFO - 2019-12-04 22:07:07 --> Helper loaded: common_helper
INFO - 2019-12-04 22:07:07 --> Helper loaded: language_helper
INFO - 2019-12-04 22:07:07 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:07:07 --> Helper loaded: email_helper
INFO - 2019-12-04 22:07:07 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:07:07 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:07:07 --> Parser Class Initialized
INFO - 2019-12-04 22:07:07 --> User Agent Class Initialized
INFO - 2019-12-04 22:07:07 --> Model Class Initialized
INFO - 2019-12-04 22:07:07 --> Database Driver Class Initialized
INFO - 2019-12-04 22:07:07 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:07 --> Template Class Initialized
INFO - 2019-12-04 22:07:07 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:07:07 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:07:07 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:07:07 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:07:07 --> Encryption Class Initialized
INFO - 2019-12-04 22:07:07 --> Controller Class Initialized
DEBUG - 2019-12-04 22:07:07 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:07:07 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:07:07 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:07 --> payop MX_Controller Initialized
ERROR - 2019-12-04 22:07:08 --> Severity: Notice --> Undefined variable: tranx D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 166
INFO - 2019-12-04 22:07:32 --> Config Class Initialized
INFO - 2019-12-04 22:07:32 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:07:32 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:07:32 --> Utf8 Class Initialized
INFO - 2019-12-04 22:07:32 --> URI Class Initialized
INFO - 2019-12-04 22:07:32 --> Router Class Initialized
INFO - 2019-12-04 22:07:32 --> Output Class Initialized
INFO - 2019-12-04 22:07:32 --> Security Class Initialized
DEBUG - 2019-12-04 22:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:07:32 --> CSRF cookie sent
INFO - 2019-12-04 22:07:32 --> CSRF token verified
INFO - 2019-12-04 22:07:32 --> Input Class Initialized
INFO - 2019-12-04 22:07:32 --> Language Class Initialized
INFO - 2019-12-04 22:07:32 --> Language Class Initialized
INFO - 2019-12-04 22:07:32 --> Config Class Initialized
INFO - 2019-12-04 22:07:32 --> Loader Class Initialized
INFO - 2019-12-04 22:07:32 --> Helper loaded: url_helper
INFO - 2019-12-04 22:07:32 --> Helper loaded: common_helper
INFO - 2019-12-04 22:07:32 --> Helper loaded: language_helper
INFO - 2019-12-04 22:07:32 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:07:32 --> Helper loaded: email_helper
INFO - 2019-12-04 22:07:32 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:07:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:07:32 --> Parser Class Initialized
INFO - 2019-12-04 22:07:32 --> User Agent Class Initialized
INFO - 2019-12-04 22:07:32 --> Model Class Initialized
INFO - 2019-12-04 22:07:32 --> Database Driver Class Initialized
INFO - 2019-12-04 22:07:32 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:32 --> Template Class Initialized
INFO - 2019-12-04 22:07:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:07:32 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:07:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:07:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:07:32 --> Encryption Class Initialized
INFO - 2019-12-04 22:07:32 --> Controller Class Initialized
DEBUG - 2019-12-04 22:07:32 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:07:32 --> Model Class Initialized
INFO - 2019-12-04 22:07:32 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:07:32 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:07:32 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:07:32 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:07:32 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:07:32 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:07:32 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:07:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:07:32 --> Final output sent to browser
DEBUG - 2019-12-04 22:07:32 --> Total execution time: 0.8164
INFO - 2019-12-04 22:07:42 --> Config Class Initialized
INFO - 2019-12-04 22:07:42 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:07:42 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:07:42 --> Utf8 Class Initialized
INFO - 2019-12-04 22:07:42 --> URI Class Initialized
INFO - 2019-12-04 22:07:42 --> Router Class Initialized
INFO - 2019-12-04 22:07:42 --> Output Class Initialized
INFO - 2019-12-04 22:07:42 --> Security Class Initialized
DEBUG - 2019-12-04 22:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:07:42 --> CSRF cookie sent
INFO - 2019-12-04 22:07:42 --> CSRF token verified
INFO - 2019-12-04 22:07:42 --> Input Class Initialized
INFO - 2019-12-04 22:07:42 --> Language Class Initialized
INFO - 2019-12-04 22:07:42 --> Language Class Initialized
INFO - 2019-12-04 22:07:42 --> Config Class Initialized
INFO - 2019-12-04 22:07:42 --> Loader Class Initialized
INFO - 2019-12-04 22:07:42 --> Helper loaded: url_helper
INFO - 2019-12-04 22:07:42 --> Helper loaded: common_helper
INFO - 2019-12-04 22:07:42 --> Helper loaded: language_helper
INFO - 2019-12-04 22:07:42 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:07:42 --> Helper loaded: email_helper
INFO - 2019-12-04 22:07:42 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:07:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:07:42 --> Parser Class Initialized
INFO - 2019-12-04 22:07:42 --> User Agent Class Initialized
INFO - 2019-12-04 22:07:42 --> Model Class Initialized
INFO - 2019-12-04 22:07:42 --> Database Driver Class Initialized
INFO - 2019-12-04 22:07:42 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:42 --> Template Class Initialized
INFO - 2019-12-04 22:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:07:42 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:07:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:07:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:07:42 --> Encryption Class Initialized
INFO - 2019-12-04 22:07:42 --> Controller Class Initialized
DEBUG - 2019-12-04 22:07:42 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:07:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:07:42 --> Model Class Initialized
DEBUG - 2019-12-04 22:07:42 --> payop MX_Controller Initialized
ERROR - 2019-12-04 22:07:43 --> Severity: Notice --> Undefined index: status D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 167
ERROR - 2019-12-04 22:07:43 --> Severity: Notice --> Undefined index: message D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 191
INFO - 2019-12-04 22:08:14 --> Config Class Initialized
INFO - 2019-12-04 22:08:14 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:08:14 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:08:14 --> Utf8 Class Initialized
INFO - 2019-12-04 22:08:14 --> URI Class Initialized
INFO - 2019-12-04 22:08:14 --> Router Class Initialized
INFO - 2019-12-04 22:08:14 --> Output Class Initialized
INFO - 2019-12-04 22:08:14 --> Security Class Initialized
DEBUG - 2019-12-04 22:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:08:14 --> CSRF cookie sent
INFO - 2019-12-04 22:08:14 --> CSRF token verified
INFO - 2019-12-04 22:08:14 --> Input Class Initialized
INFO - 2019-12-04 22:08:14 --> Language Class Initialized
INFO - 2019-12-04 22:08:14 --> Language Class Initialized
INFO - 2019-12-04 22:08:14 --> Config Class Initialized
INFO - 2019-12-04 22:08:14 --> Loader Class Initialized
INFO - 2019-12-04 22:08:14 --> Helper loaded: url_helper
INFO - 2019-12-04 22:08:14 --> Helper loaded: common_helper
INFO - 2019-12-04 22:08:14 --> Helper loaded: language_helper
INFO - 2019-12-04 22:08:14 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:08:14 --> Helper loaded: email_helper
INFO - 2019-12-04 22:08:14 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:08:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:08:14 --> Parser Class Initialized
INFO - 2019-12-04 22:08:14 --> User Agent Class Initialized
INFO - 2019-12-04 22:08:14 --> Model Class Initialized
INFO - 2019-12-04 22:08:14 --> Database Driver Class Initialized
INFO - 2019-12-04 22:08:14 --> Model Class Initialized
DEBUG - 2019-12-04 22:08:14 --> Template Class Initialized
INFO - 2019-12-04 22:08:14 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:08:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:08:14 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:08:14 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:08:14 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:08:14 --> Encryption Class Initialized
INFO - 2019-12-04 22:08:14 --> Controller Class Initialized
DEBUG - 2019-12-04 22:08:14 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:08:14 --> Model Class Initialized
INFO - 2019-12-04 22:08:14 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:08:14 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:08:14 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:08:14 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:08:14 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:08:14 --> Model Class Initialized
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:08:14 --> Model Class Initialized
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:08:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:08:14 --> Final output sent to browser
DEBUG - 2019-12-04 22:08:14 --> Total execution time: 0.9198
INFO - 2019-12-04 22:08:24 --> Config Class Initialized
INFO - 2019-12-04 22:08:24 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:08:24 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:08:24 --> Utf8 Class Initialized
INFO - 2019-12-04 22:08:24 --> URI Class Initialized
INFO - 2019-12-04 22:08:24 --> Router Class Initialized
INFO - 2019-12-04 22:08:24 --> Output Class Initialized
INFO - 2019-12-04 22:08:24 --> Security Class Initialized
DEBUG - 2019-12-04 22:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:08:24 --> CSRF cookie sent
INFO - 2019-12-04 22:08:24 --> CSRF token verified
INFO - 2019-12-04 22:08:24 --> Input Class Initialized
INFO - 2019-12-04 22:08:24 --> Language Class Initialized
INFO - 2019-12-04 22:08:24 --> Language Class Initialized
INFO - 2019-12-04 22:08:24 --> Config Class Initialized
INFO - 2019-12-04 22:08:24 --> Loader Class Initialized
INFO - 2019-12-04 22:08:24 --> Helper loaded: url_helper
INFO - 2019-12-04 22:08:24 --> Helper loaded: common_helper
INFO - 2019-12-04 22:08:24 --> Helper loaded: language_helper
INFO - 2019-12-04 22:08:24 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:08:24 --> Helper loaded: email_helper
INFO - 2019-12-04 22:08:24 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:08:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:08:24 --> Parser Class Initialized
INFO - 2019-12-04 22:08:24 --> User Agent Class Initialized
INFO - 2019-12-04 22:08:24 --> Model Class Initialized
INFO - 2019-12-04 22:08:24 --> Database Driver Class Initialized
INFO - 2019-12-04 22:08:24 --> Model Class Initialized
DEBUG - 2019-12-04 22:08:25 --> Template Class Initialized
INFO - 2019-12-04 22:08:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:08:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:08:25 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:08:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:08:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:08:25 --> Encryption Class Initialized
INFO - 2019-12-04 22:08:25 --> Controller Class Initialized
DEBUG - 2019-12-04 22:08:25 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:08:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:08:25 --> Model Class Initialized
DEBUG - 2019-12-04 22:08:25 --> payop MX_Controller Initialized
INFO - 2019-12-04 22:11:00 --> Config Class Initialized
INFO - 2019-12-04 22:11:00 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:11:00 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:11:00 --> Utf8 Class Initialized
INFO - 2019-12-04 22:11:00 --> URI Class Initialized
INFO - 2019-12-04 22:11:00 --> Router Class Initialized
INFO - 2019-12-04 22:11:00 --> Output Class Initialized
INFO - 2019-12-04 22:11:00 --> Security Class Initialized
DEBUG - 2019-12-04 22:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:11:00 --> CSRF cookie sent
INFO - 2019-12-04 22:11:00 --> CSRF token verified
INFO - 2019-12-04 22:11:00 --> Input Class Initialized
INFO - 2019-12-04 22:11:00 --> Language Class Initialized
INFO - 2019-12-04 22:11:00 --> Language Class Initialized
INFO - 2019-12-04 22:11:00 --> Config Class Initialized
INFO - 2019-12-04 22:11:00 --> Loader Class Initialized
INFO - 2019-12-04 22:11:00 --> Helper loaded: url_helper
INFO - 2019-12-04 22:11:00 --> Helper loaded: common_helper
INFO - 2019-12-04 22:11:00 --> Helper loaded: language_helper
INFO - 2019-12-04 22:11:00 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:11:00 --> Helper loaded: email_helper
INFO - 2019-12-04 22:11:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:11:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:11:00 --> Parser Class Initialized
INFO - 2019-12-04 22:11:00 --> User Agent Class Initialized
INFO - 2019-12-04 22:11:00 --> Model Class Initialized
INFO - 2019-12-04 22:11:00 --> Database Driver Class Initialized
INFO - 2019-12-04 22:11:00 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:00 --> Template Class Initialized
INFO - 2019-12-04 22:11:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:11:01 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:11:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:11:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:11:01 --> Encryption Class Initialized
INFO - 2019-12-04 22:11:01 --> Controller Class Initialized
DEBUG - 2019-12-04 22:11:01 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:11:01 --> Model Class Initialized
INFO - 2019-12-04 22:11:01 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:11:01 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:11:01 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:11:01 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:11:01 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:11:01 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:11:01 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:11:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:11:01 --> Final output sent to browser
DEBUG - 2019-12-04 22:11:01 --> Total execution time: 0.8691
INFO - 2019-12-04 22:11:08 --> Config Class Initialized
INFO - 2019-12-04 22:11:08 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:11:08 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:11:08 --> Utf8 Class Initialized
INFO - 2019-12-04 22:11:08 --> URI Class Initialized
INFO - 2019-12-04 22:11:08 --> Router Class Initialized
INFO - 2019-12-04 22:11:08 --> Output Class Initialized
INFO - 2019-12-04 22:11:08 --> Security Class Initialized
DEBUG - 2019-12-04 22:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:11:09 --> CSRF cookie sent
INFO - 2019-12-04 22:11:09 --> CSRF token verified
INFO - 2019-12-04 22:11:09 --> Input Class Initialized
INFO - 2019-12-04 22:11:09 --> Language Class Initialized
INFO - 2019-12-04 22:11:09 --> Language Class Initialized
INFO - 2019-12-04 22:11:09 --> Config Class Initialized
INFO - 2019-12-04 22:11:09 --> Loader Class Initialized
INFO - 2019-12-04 22:11:09 --> Helper loaded: url_helper
INFO - 2019-12-04 22:11:09 --> Helper loaded: common_helper
INFO - 2019-12-04 22:11:09 --> Helper loaded: language_helper
INFO - 2019-12-04 22:11:09 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:11:09 --> Helper loaded: email_helper
INFO - 2019-12-04 22:11:09 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:11:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:11:09 --> Parser Class Initialized
INFO - 2019-12-04 22:11:09 --> User Agent Class Initialized
INFO - 2019-12-04 22:11:09 --> Model Class Initialized
INFO - 2019-12-04 22:11:09 --> Database Driver Class Initialized
INFO - 2019-12-04 22:11:09 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:09 --> Template Class Initialized
INFO - 2019-12-04 22:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:11:09 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:11:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:11:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:11:09 --> Encryption Class Initialized
INFO - 2019-12-04 22:11:09 --> Controller Class Initialized
DEBUG - 2019-12-04 22:11:09 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:11:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:11:09 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:09 --> payop MX_Controller Initialized
INFO - 2019-12-04 22:11:49 --> Config Class Initialized
INFO - 2019-12-04 22:11:49 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:11:49 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:11:49 --> Utf8 Class Initialized
INFO - 2019-12-04 22:11:49 --> URI Class Initialized
INFO - 2019-12-04 22:11:49 --> Router Class Initialized
INFO - 2019-12-04 22:11:49 --> Output Class Initialized
INFO - 2019-12-04 22:11:49 --> Security Class Initialized
DEBUG - 2019-12-04 22:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:11:49 --> CSRF cookie sent
INFO - 2019-12-04 22:11:49 --> CSRF token verified
INFO - 2019-12-04 22:11:49 --> Input Class Initialized
INFO - 2019-12-04 22:11:49 --> Language Class Initialized
INFO - 2019-12-04 22:11:49 --> Language Class Initialized
INFO - 2019-12-04 22:11:49 --> Config Class Initialized
INFO - 2019-12-04 22:11:49 --> Loader Class Initialized
INFO - 2019-12-04 22:11:49 --> Helper loaded: url_helper
INFO - 2019-12-04 22:11:49 --> Helper loaded: common_helper
INFO - 2019-12-04 22:11:49 --> Helper loaded: language_helper
INFO - 2019-12-04 22:11:49 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:11:49 --> Helper loaded: email_helper
INFO - 2019-12-04 22:11:49 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:11:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:11:49 --> Parser Class Initialized
INFO - 2019-12-04 22:11:49 --> User Agent Class Initialized
INFO - 2019-12-04 22:11:49 --> Model Class Initialized
INFO - 2019-12-04 22:11:49 --> Database Driver Class Initialized
INFO - 2019-12-04 22:11:49 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:49 --> Template Class Initialized
INFO - 2019-12-04 22:11:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:11:49 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:11:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:11:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:11:49 --> Encryption Class Initialized
INFO - 2019-12-04 22:11:49 --> Controller Class Initialized
DEBUG - 2019-12-04 22:11:49 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:11:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:11:49 --> Model Class Initialized
DEBUG - 2019-12-04 22:11:49 --> payop MX_Controller Initialized
INFO - 2019-12-04 22:13:20 --> Config Class Initialized
INFO - 2019-12-04 22:13:20 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:13:20 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:13:20 --> Utf8 Class Initialized
INFO - 2019-12-04 22:13:20 --> URI Class Initialized
INFO - 2019-12-04 22:13:20 --> Router Class Initialized
INFO - 2019-12-04 22:13:20 --> Output Class Initialized
INFO - 2019-12-04 22:13:20 --> Security Class Initialized
DEBUG - 2019-12-04 22:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:13:20 --> CSRF cookie sent
INFO - 2019-12-04 22:13:20 --> CSRF token verified
INFO - 2019-12-04 22:13:20 --> Input Class Initialized
INFO - 2019-12-04 22:13:20 --> Language Class Initialized
INFO - 2019-12-04 22:13:20 --> Language Class Initialized
INFO - 2019-12-04 22:13:20 --> Config Class Initialized
INFO - 2019-12-04 22:13:20 --> Loader Class Initialized
INFO - 2019-12-04 22:13:20 --> Helper loaded: url_helper
INFO - 2019-12-04 22:13:20 --> Helper loaded: common_helper
INFO - 2019-12-04 22:13:20 --> Helper loaded: language_helper
INFO - 2019-12-04 22:13:20 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:13:20 --> Helper loaded: email_helper
INFO - 2019-12-04 22:13:20 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:13:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:13:20 --> Parser Class Initialized
INFO - 2019-12-04 22:13:20 --> User Agent Class Initialized
INFO - 2019-12-04 22:13:20 --> Model Class Initialized
INFO - 2019-12-04 22:13:20 --> Database Driver Class Initialized
INFO - 2019-12-04 22:13:20 --> Model Class Initialized
DEBUG - 2019-12-04 22:13:20 --> Template Class Initialized
INFO - 2019-12-04 22:13:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:13:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:13:21 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:13:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:13:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:13:21 --> Encryption Class Initialized
INFO - 2019-12-04 22:13:21 --> Controller Class Initialized
DEBUG - 2019-12-04 22:13:21 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:13:21 --> Model Class Initialized
INFO - 2019-12-04 22:13:21 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:13:21 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:13:21 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:13:21 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:13:21 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:13:21 --> Model Class Initialized
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:13:21 --> Model Class Initialized
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:13:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:13:21 --> Final output sent to browser
DEBUG - 2019-12-04 22:13:21 --> Total execution time: 0.9224
INFO - 2019-12-04 22:13:36 --> Config Class Initialized
INFO - 2019-12-04 22:13:36 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:13:36 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:13:36 --> Utf8 Class Initialized
INFO - 2019-12-04 22:13:36 --> URI Class Initialized
INFO - 2019-12-04 22:13:36 --> Router Class Initialized
INFO - 2019-12-04 22:13:36 --> Output Class Initialized
INFO - 2019-12-04 22:13:36 --> Security Class Initialized
DEBUG - 2019-12-04 22:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:13:36 --> CSRF cookie sent
INFO - 2019-12-04 22:13:36 --> CSRF token verified
INFO - 2019-12-04 22:13:36 --> Input Class Initialized
INFO - 2019-12-04 22:13:36 --> Language Class Initialized
INFO - 2019-12-04 22:13:36 --> Language Class Initialized
INFO - 2019-12-04 22:13:36 --> Config Class Initialized
INFO - 2019-12-04 22:13:36 --> Loader Class Initialized
INFO - 2019-12-04 22:13:36 --> Helper loaded: url_helper
INFO - 2019-12-04 22:13:36 --> Helper loaded: common_helper
INFO - 2019-12-04 22:13:36 --> Helper loaded: language_helper
INFO - 2019-12-04 22:13:36 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:13:36 --> Helper loaded: email_helper
INFO - 2019-12-04 22:13:36 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:13:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:13:36 --> Parser Class Initialized
INFO - 2019-12-04 22:13:36 --> User Agent Class Initialized
INFO - 2019-12-04 22:13:36 --> Model Class Initialized
INFO - 2019-12-04 22:13:36 --> Database Driver Class Initialized
INFO - 2019-12-04 22:13:36 --> Model Class Initialized
DEBUG - 2019-12-04 22:13:36 --> Template Class Initialized
INFO - 2019-12-04 22:13:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:13:36 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:13:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:13:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:13:36 --> Encryption Class Initialized
INFO - 2019-12-04 22:13:36 --> Controller Class Initialized
DEBUG - 2019-12-04 22:13:36 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:13:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:13:36 --> Model Class Initialized
DEBUG - 2019-12-04 22:13:36 --> payop MX_Controller Initialized
DEBUG - 2019-12-04 22:13:38 --> orders MX_Controller Initialized
DEBUG - 2019-12-04 22:13:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payop/index.php
INFO - 2019-12-04 22:13:38 --> Final output sent to browser
DEBUG - 2019-12-04 22:13:38 --> Total execution time: 2.6453
INFO - 2019-12-04 22:25:50 --> Config Class Initialized
INFO - 2019-12-04 22:25:50 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:25:50 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:25:50 --> Utf8 Class Initialized
INFO - 2019-12-04 22:25:50 --> URI Class Initialized
DEBUG - 2019-12-04 22:25:50 --> No URI present. Default controller set.
INFO - 2019-12-04 22:25:50 --> Router Class Initialized
INFO - 2019-12-04 22:25:50 --> Output Class Initialized
INFO - 2019-12-04 22:25:50 --> Security Class Initialized
DEBUG - 2019-12-04 22:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:25:50 --> CSRF cookie sent
INFO - 2019-12-04 22:25:50 --> Input Class Initialized
INFO - 2019-12-04 22:25:50 --> Language Class Initialized
INFO - 2019-12-04 22:25:50 --> Language Class Initialized
INFO - 2019-12-04 22:25:50 --> Config Class Initialized
INFO - 2019-12-04 22:25:50 --> Loader Class Initialized
INFO - 2019-12-04 22:25:50 --> Helper loaded: url_helper
INFO - 2019-12-04 22:25:50 --> Helper loaded: common_helper
INFO - 2019-12-04 22:25:50 --> Helper loaded: language_helper
INFO - 2019-12-04 22:25:50 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:25:50 --> Helper loaded: email_helper
INFO - 2019-12-04 22:25:50 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:25:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:25:50 --> Parser Class Initialized
INFO - 2019-12-04 22:25:50 --> User Agent Class Initialized
INFO - 2019-12-04 22:25:50 --> Model Class Initialized
INFO - 2019-12-04 22:25:50 --> Database Driver Class Initialized
INFO - 2019-12-04 22:25:50 --> Model Class Initialized
DEBUG - 2019-12-04 22:25:50 --> Template Class Initialized
INFO - 2019-12-04 22:25:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:25:50 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:25:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:25:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:25:50 --> Encryption Class Initialized
DEBUG - 2019-12-04 22:25:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:25:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-04 22:25:50 --> Controller Class Initialized
DEBUG - 2019-12-04 22:25:50 --> pergo MX_Controller Initialized
DEBUG - 2019-12-04 22:25:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:25:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-04 22:25:50 --> Model Class Initialized
INFO - 2019-12-04 22:25:50 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:25:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-04 22:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-04 22:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-04 22:25:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-04 22:25:51 --> Final output sent to browser
DEBUG - 2019-12-04 22:25:51 --> Total execution time: 0.7038
INFO - 2019-12-04 22:25:59 --> Config Class Initialized
INFO - 2019-12-04 22:25:59 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:25:59 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:25:59 --> Utf8 Class Initialized
INFO - 2019-12-04 22:25:59 --> URI Class Initialized
INFO - 2019-12-04 22:25:59 --> Router Class Initialized
INFO - 2019-12-04 22:25:59 --> Output Class Initialized
INFO - 2019-12-04 22:25:59 --> Security Class Initialized
DEBUG - 2019-12-04 22:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:25:59 --> CSRF cookie sent
INFO - 2019-12-04 22:25:59 --> Input Class Initialized
INFO - 2019-12-04 22:25:59 --> Language Class Initialized
INFO - 2019-12-04 22:25:59 --> Language Class Initialized
INFO - 2019-12-04 22:25:59 --> Config Class Initialized
INFO - 2019-12-04 22:25:59 --> Loader Class Initialized
INFO - 2019-12-04 22:25:59 --> Helper loaded: url_helper
INFO - 2019-12-04 22:25:59 --> Helper loaded: common_helper
INFO - 2019-12-04 22:25:59 --> Helper loaded: language_helper
INFO - 2019-12-04 22:25:59 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:25:59 --> Helper loaded: email_helper
INFO - 2019-12-04 22:25:59 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:25:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:25:59 --> Parser Class Initialized
INFO - 2019-12-04 22:25:59 --> User Agent Class Initialized
INFO - 2019-12-04 22:25:59 --> Model Class Initialized
INFO - 2019-12-04 22:25:59 --> Database Driver Class Initialized
INFO - 2019-12-04 22:25:59 --> Model Class Initialized
DEBUG - 2019-12-04 22:25:59 --> Template Class Initialized
INFO - 2019-12-04 22:25:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:25:59 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:25:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:25:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:25:59 --> Encryption Class Initialized
INFO - 2019-12-04 22:25:59 --> Controller Class Initialized
DEBUG - 2019-12-04 22:25:59 --> auth MX_Controller Initialized
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-04 22:25:59 --> Model Class Initialized
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-04 22:25:59 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-12-04 22:25:59 --> pergo MX_Controller Initialized
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-12-04 22:25:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-04 22:25:59 --> Final output sent to browser
DEBUG - 2019-12-04 22:26:00 --> Total execution time: 0.9562
INFO - 2019-12-04 22:26:01 --> Config Class Initialized
INFO - 2019-12-04 22:26:01 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:26:01 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:26:01 --> Utf8 Class Initialized
INFO - 2019-12-04 22:26:01 --> URI Class Initialized
INFO - 2019-12-04 22:26:01 --> Router Class Initialized
INFO - 2019-12-04 22:26:01 --> Output Class Initialized
INFO - 2019-12-04 22:26:01 --> Security Class Initialized
DEBUG - 2019-12-04 22:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:26:01 --> CSRF cookie sent
INFO - 2019-12-04 22:26:06 --> Config Class Initialized
INFO - 2019-12-04 22:26:06 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:26:06 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:26:06 --> Utf8 Class Initialized
INFO - 2019-12-04 22:26:06 --> URI Class Initialized
INFO - 2019-12-04 22:26:06 --> Router Class Initialized
INFO - 2019-12-04 22:26:06 --> Output Class Initialized
INFO - 2019-12-04 22:26:06 --> Security Class Initialized
DEBUG - 2019-12-04 22:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:26:06 --> CSRF cookie sent
INFO - 2019-12-04 22:26:06 --> CSRF token verified
INFO - 2019-12-04 22:26:06 --> Input Class Initialized
INFO - 2019-12-04 22:26:06 --> Language Class Initialized
INFO - 2019-12-04 22:26:06 --> Language Class Initialized
INFO - 2019-12-04 22:26:06 --> Config Class Initialized
INFO - 2019-12-04 22:26:06 --> Loader Class Initialized
INFO - 2019-12-04 22:26:06 --> Helper loaded: url_helper
INFO - 2019-12-04 22:26:06 --> Helper loaded: common_helper
INFO - 2019-12-04 22:26:06 --> Helper loaded: language_helper
INFO - 2019-12-04 22:26:06 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:26:06 --> Helper loaded: email_helper
INFO - 2019-12-04 22:26:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:26:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:26:06 --> Parser Class Initialized
INFO - 2019-12-04 22:26:06 --> User Agent Class Initialized
INFO - 2019-12-04 22:26:06 --> Model Class Initialized
INFO - 2019-12-04 22:26:06 --> Database Driver Class Initialized
INFO - 2019-12-04 22:26:06 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:06 --> Template Class Initialized
INFO - 2019-12-04 22:26:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:26:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:26:06 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:26:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:26:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:26:06 --> Encryption Class Initialized
INFO - 2019-12-04 22:26:06 --> Controller Class Initialized
DEBUG - 2019-12-04 22:26:06 --> auth MX_Controller Initialized
DEBUG - 2019-12-04 22:26:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-12-04 22:26:06 --> Model Class Initialized
INFO - 2019-12-04 22:26:11 --> Config Class Initialized
INFO - 2019-12-04 22:26:11 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:26:11 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:26:11 --> Utf8 Class Initialized
INFO - 2019-12-04 22:26:11 --> URI Class Initialized
INFO - 2019-12-04 22:26:11 --> Router Class Initialized
INFO - 2019-12-04 22:26:11 --> Output Class Initialized
INFO - 2019-12-04 22:26:11 --> Security Class Initialized
DEBUG - 2019-12-04 22:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:26:11 --> CSRF cookie sent
INFO - 2019-12-04 22:26:11 --> Input Class Initialized
INFO - 2019-12-04 22:26:11 --> Language Class Initialized
INFO - 2019-12-04 22:26:11 --> Language Class Initialized
INFO - 2019-12-04 22:26:11 --> Config Class Initialized
INFO - 2019-12-04 22:26:11 --> Loader Class Initialized
INFO - 2019-12-04 22:26:11 --> Helper loaded: url_helper
INFO - 2019-12-04 22:26:11 --> Helper loaded: common_helper
INFO - 2019-12-04 22:26:11 --> Helper loaded: language_helper
INFO - 2019-12-04 22:26:11 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:26:11 --> Helper loaded: email_helper
INFO - 2019-12-04 22:26:11 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:26:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:26:11 --> Parser Class Initialized
INFO - 2019-12-04 22:26:11 --> User Agent Class Initialized
INFO - 2019-12-04 22:26:11 --> Model Class Initialized
INFO - 2019-12-04 22:26:11 --> Database Driver Class Initialized
INFO - 2019-12-04 22:26:11 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:11 --> Template Class Initialized
INFO - 2019-12-04 22:26:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:26:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:26:11 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:26:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:26:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:26:11 --> Encryption Class Initialized
INFO - 2019-12-04 22:26:11 --> Controller Class Initialized
DEBUG - 2019-12-04 22:26:11 --> statistics MX_Controller Initialized
DEBUG - 2019-12-04 22:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-12-04 22:26:11 --> Model Class Initialized
ERROR - 2019-12-04 22:26:11 --> Could not find the language line "Pending"
ERROR - 2019-12-04 22:26:11 --> Could not find the language line "Pending"
INFO - 2019-12-04 22:26:11 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:26:11 --> Could not find the language line "total_orders"
ERROR - 2019-12-04 22:26:11 --> Could not find the language line "total_orders"
ERROR - 2019-12-04 22:26:11 --> Could not find the language line "Pending"
DEBUG - 2019-12-04 22:26:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-12-04 22:26:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:26:12 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:26:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:26:12 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:26:12 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:26:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:26:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:26:12 --> Final output sent to browser
DEBUG - 2019-12-04 22:26:12 --> Total execution time: 1.1237
INFO - 2019-12-04 22:26:23 --> Config Class Initialized
INFO - 2019-12-04 22:26:23 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:26:23 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:26:23 --> Utf8 Class Initialized
INFO - 2019-12-04 22:26:23 --> URI Class Initialized
INFO - 2019-12-04 22:26:23 --> Router Class Initialized
INFO - 2019-12-04 22:26:23 --> Output Class Initialized
INFO - 2019-12-04 22:26:23 --> Security Class Initialized
DEBUG - 2019-12-04 22:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:26:23 --> CSRF cookie sent
INFO - 2019-12-04 22:26:23 --> Input Class Initialized
INFO - 2019-12-04 22:26:23 --> Language Class Initialized
INFO - 2019-12-04 22:26:23 --> Language Class Initialized
INFO - 2019-12-04 22:26:23 --> Config Class Initialized
INFO - 2019-12-04 22:26:23 --> Loader Class Initialized
INFO - 2019-12-04 22:26:23 --> Helper loaded: url_helper
INFO - 2019-12-04 22:26:23 --> Helper loaded: common_helper
INFO - 2019-12-04 22:26:23 --> Helper loaded: language_helper
INFO - 2019-12-04 22:26:23 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:26:23 --> Helper loaded: email_helper
INFO - 2019-12-04 22:26:23 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:26:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:26:23 --> Parser Class Initialized
INFO - 2019-12-04 22:26:23 --> User Agent Class Initialized
INFO - 2019-12-04 22:26:23 --> Model Class Initialized
INFO - 2019-12-04 22:26:23 --> Database Driver Class Initialized
INFO - 2019-12-04 22:26:23 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:23 --> Template Class Initialized
INFO - 2019-12-04 22:26:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:26:23 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:26:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:26:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:26:23 --> Encryption Class Initialized
INFO - 2019-12-04 22:26:23 --> Controller Class Initialized
DEBUG - 2019-12-04 22:26:23 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:26:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:26:23 --> Model Class Initialized
INFO - 2019-12-04 22:26:23 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:26:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:26:24 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:26:24 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:26:24 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:26:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:26:24 --> Final output sent to browser
DEBUG - 2019-12-04 22:26:24 --> Total execution time: 0.9142
INFO - 2019-12-04 22:26:27 --> Config Class Initialized
INFO - 2019-12-04 22:26:27 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:26:27 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:26:27 --> Utf8 Class Initialized
INFO - 2019-12-04 22:26:27 --> URI Class Initialized
INFO - 2019-12-04 22:26:27 --> Router Class Initialized
INFO - 2019-12-04 22:26:27 --> Output Class Initialized
INFO - 2019-12-04 22:26:27 --> Security Class Initialized
DEBUG - 2019-12-04 22:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:26:27 --> CSRF cookie sent
INFO - 2019-12-04 22:26:27 --> Input Class Initialized
INFO - 2019-12-04 22:26:27 --> Language Class Initialized
INFO - 2019-12-04 22:26:27 --> Language Class Initialized
INFO - 2019-12-04 22:26:27 --> Config Class Initialized
INFO - 2019-12-04 22:26:27 --> Loader Class Initialized
INFO - 2019-12-04 22:26:27 --> Helper loaded: url_helper
INFO - 2019-12-04 22:26:27 --> Helper loaded: common_helper
INFO - 2019-12-04 22:26:27 --> Helper loaded: language_helper
INFO - 2019-12-04 22:26:27 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:26:27 --> Helper loaded: email_helper
INFO - 2019-12-04 22:26:27 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:26:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:26:27 --> Parser Class Initialized
INFO - 2019-12-04 22:26:27 --> User Agent Class Initialized
INFO - 2019-12-04 22:26:27 --> Model Class Initialized
INFO - 2019-12-04 22:26:27 --> Database Driver Class Initialized
INFO - 2019-12-04 22:26:27 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:27 --> Template Class Initialized
INFO - 2019-12-04 22:26:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:26:27 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:26:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:26:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:26:27 --> Encryption Class Initialized
INFO - 2019-12-04 22:26:27 --> Controller Class Initialized
DEBUG - 2019-12-04 22:26:27 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:26:27 --> Model Class Initialized
INFO - 2019-12-04 22:26:27 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:26:27 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:26:27 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:26:27 --> Model Class Initialized
DEBUG - 2019-12-04 22:26:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:26:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:26:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:26:28 --> Final output sent to browser
DEBUG - 2019-12-04 22:26:28 --> Total execution time: 0.8328
INFO - 2019-12-04 22:34:42 --> Config Class Initialized
INFO - 2019-12-04 22:34:42 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:34:42 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:34:42 --> Utf8 Class Initialized
INFO - 2019-12-04 22:34:42 --> URI Class Initialized
INFO - 2019-12-04 22:34:42 --> Router Class Initialized
INFO - 2019-12-04 22:34:42 --> Output Class Initialized
INFO - 2019-12-04 22:34:42 --> Security Class Initialized
DEBUG - 2019-12-04 22:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:34:42 --> CSRF cookie sent
INFO - 2019-12-04 22:34:42 --> Input Class Initialized
INFO - 2019-12-04 22:34:42 --> Language Class Initialized
INFO - 2019-12-04 22:34:42 --> Language Class Initialized
INFO - 2019-12-04 22:34:42 --> Config Class Initialized
INFO - 2019-12-04 22:34:42 --> Loader Class Initialized
INFO - 2019-12-04 22:34:42 --> Helper loaded: url_helper
INFO - 2019-12-04 22:34:42 --> Helper loaded: common_helper
INFO - 2019-12-04 22:34:42 --> Helper loaded: language_helper
INFO - 2019-12-04 22:34:42 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:34:42 --> Helper loaded: email_helper
INFO - 2019-12-04 22:34:42 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:34:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:34:42 --> Parser Class Initialized
INFO - 2019-12-04 22:34:42 --> User Agent Class Initialized
INFO - 2019-12-04 22:34:42 --> Model Class Initialized
INFO - 2019-12-04 22:34:42 --> Database Driver Class Initialized
INFO - 2019-12-04 22:34:42 --> Model Class Initialized
DEBUG - 2019-12-04 22:34:42 --> Template Class Initialized
INFO - 2019-12-04 22:34:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:34:42 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:34:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:34:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:34:42 --> Encryption Class Initialized
INFO - 2019-12-04 22:34:42 --> Controller Class Initialized
DEBUG - 2019-12-04 22:34:42 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:34:42 --> Model Class Initialized
INFO - 2019-12-04 22:34:42 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:34:42 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:34:42 --> Model Class Initialized
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:34:42 --> Model Class Initialized
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:34:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:34:42 --> Final output sent to browser
DEBUG - 2019-12-04 22:34:42 --> Total execution time: 0.8099
INFO - 2019-12-04 22:35:01 --> Config Class Initialized
INFO - 2019-12-04 22:35:01 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:35:01 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:35:01 --> Utf8 Class Initialized
INFO - 2019-12-04 22:35:01 --> URI Class Initialized
INFO - 2019-12-04 22:35:01 --> Router Class Initialized
INFO - 2019-12-04 22:35:01 --> Output Class Initialized
INFO - 2019-12-04 22:35:01 --> Security Class Initialized
DEBUG - 2019-12-04 22:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:35:01 --> CSRF cookie sent
INFO - 2019-12-04 22:35:01 --> Input Class Initialized
INFO - 2019-12-04 22:35:01 --> Language Class Initialized
INFO - 2019-12-04 22:35:01 --> Language Class Initialized
INFO - 2019-12-04 22:35:01 --> Config Class Initialized
INFO - 2019-12-04 22:35:01 --> Loader Class Initialized
INFO - 2019-12-04 22:35:01 --> Helper loaded: url_helper
INFO - 2019-12-04 22:35:01 --> Helper loaded: common_helper
INFO - 2019-12-04 22:35:01 --> Helper loaded: language_helper
INFO - 2019-12-04 22:35:01 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:35:01 --> Helper loaded: email_helper
INFO - 2019-12-04 22:35:01 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:35:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:35:01 --> Parser Class Initialized
INFO - 2019-12-04 22:35:01 --> User Agent Class Initialized
INFO - 2019-12-04 22:35:01 --> Model Class Initialized
INFO - 2019-12-04 22:35:02 --> Database Driver Class Initialized
INFO - 2019-12-04 22:35:02 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:02 --> Template Class Initialized
INFO - 2019-12-04 22:35:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:35:02 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:35:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:35:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:35:02 --> Encryption Class Initialized
INFO - 2019-12-04 22:35:02 --> Controller Class Initialized
DEBUG - 2019-12-04 22:35:02 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:35:02 --> Model Class Initialized
INFO - 2019-12-04 22:35:02 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:35:02 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:35:02 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:35:02 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:35:02 --> Final output sent to browser
DEBUG - 2019-12-04 22:35:02 --> Total execution time: 0.8444
INFO - 2019-12-04 22:35:27 --> Config Class Initialized
INFO - 2019-12-04 22:35:27 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:35:27 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:35:27 --> Utf8 Class Initialized
INFO - 2019-12-04 22:35:27 --> URI Class Initialized
INFO - 2019-12-04 22:35:27 --> Router Class Initialized
INFO - 2019-12-04 22:35:27 --> Output Class Initialized
INFO - 2019-12-04 22:35:27 --> Security Class Initialized
DEBUG - 2019-12-04 22:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:35:27 --> CSRF cookie sent
INFO - 2019-12-04 22:35:27 --> CSRF token verified
INFO - 2019-12-04 22:35:27 --> Input Class Initialized
INFO - 2019-12-04 22:35:27 --> Language Class Initialized
INFO - 2019-12-04 22:35:27 --> Language Class Initialized
INFO - 2019-12-04 22:35:27 --> Config Class Initialized
INFO - 2019-12-04 22:35:27 --> Loader Class Initialized
INFO - 2019-12-04 22:35:27 --> Helper loaded: url_helper
INFO - 2019-12-04 22:35:27 --> Helper loaded: common_helper
INFO - 2019-12-04 22:35:27 --> Helper loaded: language_helper
INFO - 2019-12-04 22:35:27 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:35:27 --> Helper loaded: email_helper
INFO - 2019-12-04 22:35:27 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:35:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:35:27 --> Parser Class Initialized
INFO - 2019-12-04 22:35:27 --> User Agent Class Initialized
INFO - 2019-12-04 22:35:27 --> Model Class Initialized
INFO - 2019-12-04 22:35:27 --> Database Driver Class Initialized
INFO - 2019-12-04 22:35:27 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:27 --> Template Class Initialized
INFO - 2019-12-04 22:35:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:35:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:35:27 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:35:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:35:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:35:27 --> Encryption Class Initialized
INFO - 2019-12-04 22:35:27 --> Controller Class Initialized
DEBUG - 2019-12-04 22:35:27 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:35:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:35:27 --> Model Class Initialized
INFO - 2019-12-04 22:35:32 --> Config Class Initialized
INFO - 2019-12-04 22:35:32 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:35:32 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:35:32 --> Utf8 Class Initialized
INFO - 2019-12-04 22:35:32 --> URI Class Initialized
INFO - 2019-12-04 22:35:32 --> Router Class Initialized
INFO - 2019-12-04 22:35:32 --> Output Class Initialized
INFO - 2019-12-04 22:35:32 --> Security Class Initialized
DEBUG - 2019-12-04 22:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:35:32 --> CSRF cookie sent
INFO - 2019-12-04 22:35:32 --> Input Class Initialized
INFO - 2019-12-04 22:35:32 --> Language Class Initialized
INFO - 2019-12-04 22:35:32 --> Language Class Initialized
INFO - 2019-12-04 22:35:32 --> Config Class Initialized
INFO - 2019-12-04 22:35:32 --> Loader Class Initialized
INFO - 2019-12-04 22:35:32 --> Helper loaded: url_helper
INFO - 2019-12-04 22:35:32 --> Helper loaded: common_helper
INFO - 2019-12-04 22:35:32 --> Helper loaded: language_helper
INFO - 2019-12-04 22:35:32 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:35:32 --> Helper loaded: email_helper
INFO - 2019-12-04 22:35:32 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:35:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:35:32 --> Parser Class Initialized
INFO - 2019-12-04 22:35:32 --> User Agent Class Initialized
INFO - 2019-12-04 22:35:32 --> Model Class Initialized
INFO - 2019-12-04 22:35:32 --> Database Driver Class Initialized
INFO - 2019-12-04 22:35:32 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:32 --> Template Class Initialized
INFO - 2019-12-04 22:35:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:35:32 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:35:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:35:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:35:32 --> Encryption Class Initialized
INFO - 2019-12-04 22:35:32 --> Controller Class Initialized
DEBUG - 2019-12-04 22:35:33 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:35:33 --> Model Class Initialized
INFO - 2019-12-04 22:35:33 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:35:33 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:35:33 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:35:33 --> Model Class Initialized
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:35:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:35:33 --> Final output sent to browser
DEBUG - 2019-12-04 22:35:33 --> Total execution time: 0.7930
INFO - 2019-12-04 22:36:04 --> Config Class Initialized
INFO - 2019-12-04 22:36:04 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:36:04 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:36:04 --> Utf8 Class Initialized
INFO - 2019-12-04 22:36:04 --> URI Class Initialized
INFO - 2019-12-04 22:36:04 --> Router Class Initialized
INFO - 2019-12-04 22:36:04 --> Output Class Initialized
INFO - 2019-12-04 22:36:04 --> Security Class Initialized
DEBUG - 2019-12-04 22:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:36:04 --> CSRF cookie sent
INFO - 2019-12-04 22:36:04 --> Input Class Initialized
INFO - 2019-12-04 22:36:04 --> Language Class Initialized
INFO - 2019-12-04 22:36:04 --> Language Class Initialized
INFO - 2019-12-04 22:36:04 --> Config Class Initialized
INFO - 2019-12-04 22:36:04 --> Loader Class Initialized
INFO - 2019-12-04 22:36:04 --> Helper loaded: url_helper
INFO - 2019-12-04 22:36:04 --> Helper loaded: common_helper
INFO - 2019-12-04 22:36:04 --> Helper loaded: language_helper
INFO - 2019-12-04 22:36:04 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:36:04 --> Helper loaded: email_helper
INFO - 2019-12-04 22:36:04 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:36:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:36:04 --> Parser Class Initialized
INFO - 2019-12-04 22:36:04 --> User Agent Class Initialized
INFO - 2019-12-04 22:36:04 --> Model Class Initialized
INFO - 2019-12-04 22:36:04 --> Database Driver Class Initialized
INFO - 2019-12-04 22:36:04 --> Model Class Initialized
DEBUG - 2019-12-04 22:36:05 --> Template Class Initialized
INFO - 2019-12-04 22:36:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:36:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:36:05 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:36:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:36:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:36:05 --> Encryption Class Initialized
INFO - 2019-12-04 22:36:05 --> Controller Class Initialized
DEBUG - 2019-12-04 22:36:05 --> setting MX_Controller Initialized
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-12-04 22:36:05 --> Model Class Initialized
INFO - 2019-12-04 22:36:05 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/payop.php
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:36:05 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:36:05 --> Model Class Initialized
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:36:05 --> Model Class Initialized
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 22:36:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 22:36:05 --> Final output sent to browser
DEBUG - 2019-12-04 22:36:05 --> Total execution time: 0.7788
INFO - 2019-12-04 22:55:34 --> Config Class Initialized
INFO - 2019-12-04 22:55:34 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:55:34 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:55:34 --> Utf8 Class Initialized
INFO - 2019-12-04 22:55:34 --> URI Class Initialized
DEBUG - 2019-12-04 22:55:34 --> No URI present. Default controller set.
INFO - 2019-12-04 22:55:34 --> Router Class Initialized
INFO - 2019-12-04 22:55:34 --> Output Class Initialized
INFO - 2019-12-04 22:55:34 --> Security Class Initialized
DEBUG - 2019-12-04 22:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:55:34 --> CSRF cookie sent
INFO - 2019-12-04 22:55:34 --> Input Class Initialized
INFO - 2019-12-04 22:55:34 --> Language Class Initialized
INFO - 2019-12-04 22:55:34 --> Language Class Initialized
INFO - 2019-12-04 22:55:34 --> Config Class Initialized
INFO - 2019-12-04 22:55:34 --> Loader Class Initialized
INFO - 2019-12-04 22:55:34 --> Helper loaded: url_helper
INFO - 2019-12-04 22:55:34 --> Helper loaded: common_helper
INFO - 2019-12-04 22:55:34 --> Helper loaded: language_helper
INFO - 2019-12-04 22:55:34 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:55:34 --> Helper loaded: email_helper
INFO - 2019-12-04 22:55:34 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:55:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:55:34 --> Parser Class Initialized
INFO - 2019-12-04 22:55:34 --> User Agent Class Initialized
INFO - 2019-12-04 22:55:34 --> Model Class Initialized
INFO - 2019-12-04 22:55:34 --> Database Driver Class Initialized
INFO - 2019-12-04 22:55:34 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:34 --> Template Class Initialized
INFO - 2019-12-04 22:55:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:55:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:55:34 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:55:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:55:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:55:34 --> Encryption Class Initialized
DEBUG - 2019-12-04 22:55:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:55:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-04 22:55:34 --> Controller Class Initialized
DEBUG - 2019-12-04 22:55:34 --> pergo MX_Controller Initialized
DEBUG - 2019-12-04 22:55:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:55:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-04 22:55:34 --> Model Class Initialized
INFO - 2019-12-04 22:55:35 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:55:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-04 22:55:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-04 22:55:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-04 22:55:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-04 22:55:35 --> Final output sent to browser
DEBUG - 2019-12-04 22:55:35 --> Total execution time: 1.0135
INFO - 2019-12-04 22:55:36 --> Config Class Initialized
INFO - 2019-12-04 22:55:36 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:55:36 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:55:36 --> Utf8 Class Initialized
INFO - 2019-12-04 22:55:36 --> URI Class Initialized
INFO - 2019-12-04 22:55:36 --> Router Class Initialized
INFO - 2019-12-04 22:55:36 --> Output Class Initialized
INFO - 2019-12-04 22:55:36 --> Security Class Initialized
DEBUG - 2019-12-04 22:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:55:36 --> CSRF cookie sent
INFO - 2019-12-04 22:55:36 --> Input Class Initialized
INFO - 2019-12-04 22:55:36 --> Language Class Initialized
INFO - 2019-12-04 22:55:36 --> Language Class Initialized
INFO - 2019-12-04 22:55:36 --> Config Class Initialized
INFO - 2019-12-04 22:55:36 --> Loader Class Initialized
INFO - 2019-12-04 22:55:36 --> Helper loaded: url_helper
INFO - 2019-12-04 22:55:36 --> Helper loaded: common_helper
INFO - 2019-12-04 22:55:36 --> Helper loaded: language_helper
INFO - 2019-12-04 22:55:36 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:55:36 --> Helper loaded: email_helper
INFO - 2019-12-04 22:55:37 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:55:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:55:37 --> Parser Class Initialized
INFO - 2019-12-04 22:55:37 --> User Agent Class Initialized
INFO - 2019-12-04 22:55:37 --> Model Class Initialized
INFO - 2019-12-04 22:55:37 --> Database Driver Class Initialized
INFO - 2019-12-04 22:55:37 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:37 --> Template Class Initialized
INFO - 2019-12-04 22:55:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:55:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:55:37 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:55:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:55:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:55:37 --> Encryption Class Initialized
INFO - 2019-12-04 22:55:37 --> Controller Class Initialized
DEBUG - 2019-12-04 22:55:37 --> package MX_Controller Initialized
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-12-04 22:55:37 --> Model Class Initialized
INFO - 2019-12-04 22:55:37 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:55:37 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:55:37 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:55:37 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:55:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:55:37 --> Final output sent to browser
DEBUG - 2019-12-04 22:55:37 --> Total execution time: 1.0294
INFO - 2019-12-04 22:55:40 --> Config Class Initialized
INFO - 2019-12-04 22:55:40 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:55:40 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:55:40 --> Utf8 Class Initialized
INFO - 2019-12-04 22:55:40 --> URI Class Initialized
INFO - 2019-12-04 22:55:40 --> Router Class Initialized
INFO - 2019-12-04 22:55:40 --> Output Class Initialized
INFO - 2019-12-04 22:55:40 --> Security Class Initialized
DEBUG - 2019-12-04 22:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:55:40 --> CSRF cookie sent
INFO - 2019-12-04 22:55:40 --> CSRF token verified
INFO - 2019-12-04 22:55:40 --> Input Class Initialized
INFO - 2019-12-04 22:55:40 --> Language Class Initialized
INFO - 2019-12-04 22:55:40 --> Language Class Initialized
INFO - 2019-12-04 22:55:40 --> Config Class Initialized
INFO - 2019-12-04 22:55:40 --> Loader Class Initialized
INFO - 2019-12-04 22:55:40 --> Helper loaded: url_helper
INFO - 2019-12-04 22:55:40 --> Helper loaded: common_helper
INFO - 2019-12-04 22:55:40 --> Helper loaded: language_helper
INFO - 2019-12-04 22:55:40 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:55:40 --> Helper loaded: email_helper
INFO - 2019-12-04 22:55:40 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:55:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:55:40 --> Parser Class Initialized
INFO - 2019-12-04 22:55:40 --> User Agent Class Initialized
INFO - 2019-12-04 22:55:40 --> Model Class Initialized
INFO - 2019-12-04 22:55:40 --> Database Driver Class Initialized
INFO - 2019-12-04 22:55:40 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:40 --> Template Class Initialized
INFO - 2019-12-04 22:55:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:55:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:55:40 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:55:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:55:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:55:40 --> Encryption Class Initialized
INFO - 2019-12-04 22:55:40 --> Controller Class Initialized
DEBUG - 2019-12-04 22:55:40 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:55:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:55:40 --> Model Class Initialized
INFO - 2019-12-04 22:55:40 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:55:41 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:55:41 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:55:41 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:55:41 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:55:41 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:55:41 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:55:41 --> Final output sent to browser
DEBUG - 2019-12-04 22:55:41 --> Total execution time: 0.9781
INFO - 2019-12-04 22:55:51 --> Config Class Initialized
INFO - 2019-12-04 22:55:51 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:55:51 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:55:51 --> Utf8 Class Initialized
INFO - 2019-12-04 22:55:51 --> URI Class Initialized
INFO - 2019-12-04 22:55:51 --> Router Class Initialized
INFO - 2019-12-04 22:55:51 --> Output Class Initialized
INFO - 2019-12-04 22:55:51 --> Security Class Initialized
DEBUG - 2019-12-04 22:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:55:51 --> CSRF cookie sent
INFO - 2019-12-04 22:55:51 --> CSRF token verified
INFO - 2019-12-04 22:55:51 --> Input Class Initialized
INFO - 2019-12-04 22:55:51 --> Language Class Initialized
INFO - 2019-12-04 22:55:51 --> Language Class Initialized
INFO - 2019-12-04 22:55:51 --> Config Class Initialized
INFO - 2019-12-04 22:55:51 --> Loader Class Initialized
INFO - 2019-12-04 22:55:51 --> Helper loaded: url_helper
INFO - 2019-12-04 22:55:51 --> Helper loaded: common_helper
INFO - 2019-12-04 22:55:51 --> Helper loaded: language_helper
INFO - 2019-12-04 22:55:51 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:55:51 --> Helper loaded: email_helper
INFO - 2019-12-04 22:55:51 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:55:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:55:51 --> Parser Class Initialized
INFO - 2019-12-04 22:55:51 --> User Agent Class Initialized
INFO - 2019-12-04 22:55:51 --> Model Class Initialized
INFO - 2019-12-04 22:55:51 --> Database Driver Class Initialized
INFO - 2019-12-04 22:55:51 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:51 --> Template Class Initialized
INFO - 2019-12-04 22:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:55:52 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:55:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:55:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:55:52 --> Encryption Class Initialized
INFO - 2019-12-04 22:55:52 --> Controller Class Initialized
DEBUG - 2019-12-04 22:55:52 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:55:52 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:55:52 --> Model Class Initialized
DEBUG - 2019-12-04 22:55:52 --> payop MX_Controller Initialized
ERROR - 2019-12-04 22:55:52 --> Severity: Notice --> Undefined variable: secretKey D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 69
ERROR - 2019-12-04 22:55:52 --> Severity: error --> Exception: Call to undefined function send_post_curl() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 97
INFO - 2019-12-04 22:56:20 --> Config Class Initialized
INFO - 2019-12-04 22:56:20 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:56:20 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:56:20 --> Utf8 Class Initialized
INFO - 2019-12-04 22:56:20 --> URI Class Initialized
INFO - 2019-12-04 22:56:20 --> Router Class Initialized
INFO - 2019-12-04 22:56:20 --> Output Class Initialized
INFO - 2019-12-04 22:56:20 --> Security Class Initialized
DEBUG - 2019-12-04 22:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:56:20 --> CSRF cookie sent
INFO - 2019-12-04 22:56:20 --> CSRF token verified
INFO - 2019-12-04 22:56:20 --> Input Class Initialized
INFO - 2019-12-04 22:56:20 --> Language Class Initialized
INFO - 2019-12-04 22:56:20 --> Language Class Initialized
INFO - 2019-12-04 22:56:20 --> Config Class Initialized
INFO - 2019-12-04 22:56:20 --> Loader Class Initialized
INFO - 2019-12-04 22:56:20 --> Helper loaded: url_helper
INFO - 2019-12-04 22:56:20 --> Helper loaded: common_helper
INFO - 2019-12-04 22:56:20 --> Helper loaded: language_helper
INFO - 2019-12-04 22:56:20 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:56:20 --> Helper loaded: email_helper
INFO - 2019-12-04 22:56:20 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:56:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:56:20 --> Parser Class Initialized
INFO - 2019-12-04 22:56:20 --> User Agent Class Initialized
INFO - 2019-12-04 22:56:20 --> Model Class Initialized
INFO - 2019-12-04 22:56:20 --> Database Driver Class Initialized
INFO - 2019-12-04 22:56:20 --> Model Class Initialized
DEBUG - 2019-12-04 22:56:20 --> Template Class Initialized
INFO - 2019-12-04 22:56:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:56:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:56:20 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:56:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:56:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:56:21 --> Encryption Class Initialized
INFO - 2019-12-04 22:56:21 --> Controller Class Initialized
DEBUG - 2019-12-04 22:56:21 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:56:21 --> Model Class Initialized
INFO - 2019-12-04 22:56:21 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:56:21 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:56:21 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:56:21 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:56:21 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:56:21 --> Model Class Initialized
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:56:21 --> Model Class Initialized
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:56:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:56:21 --> Final output sent to browser
DEBUG - 2019-12-04 22:56:21 --> Total execution time: 0.8780
INFO - 2019-12-04 22:56:28 --> Config Class Initialized
INFO - 2019-12-04 22:56:28 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:56:28 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:56:28 --> Utf8 Class Initialized
INFO - 2019-12-04 22:56:28 --> URI Class Initialized
INFO - 2019-12-04 22:56:28 --> Router Class Initialized
INFO - 2019-12-04 22:56:28 --> Output Class Initialized
INFO - 2019-12-04 22:56:28 --> Security Class Initialized
DEBUG - 2019-12-04 22:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:56:28 --> CSRF cookie sent
INFO - 2019-12-04 22:56:28 --> CSRF token verified
INFO - 2019-12-04 22:56:28 --> Input Class Initialized
INFO - 2019-12-04 22:56:28 --> Language Class Initialized
INFO - 2019-12-04 22:56:28 --> Language Class Initialized
INFO - 2019-12-04 22:56:28 --> Config Class Initialized
INFO - 2019-12-04 22:56:28 --> Loader Class Initialized
INFO - 2019-12-04 22:56:28 --> Helper loaded: url_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: common_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: language_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: email_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:56:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:56:29 --> Parser Class Initialized
INFO - 2019-12-04 22:56:29 --> User Agent Class Initialized
INFO - 2019-12-04 22:56:29 --> Model Class Initialized
INFO - 2019-12-04 22:56:29 --> Database Driver Class Initialized
INFO - 2019-12-04 22:56:29 --> Model Class Initialized
DEBUG - 2019-12-04 22:56:29 --> Template Class Initialized
INFO - 2019-12-04 22:56:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:56:29 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:56:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:56:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:56:29 --> Encryption Class Initialized
INFO - 2019-12-04 22:56:29 --> Controller Class Initialized
DEBUG - 2019-12-04 22:56:29 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:56:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:56:29 --> Model Class Initialized
DEBUG - 2019-12-04 22:56:29 --> dotpay MX_Controller Initialized
INFO - 2019-12-04 22:56:29 --> Config Class Initialized
INFO - 2019-12-04 22:56:29 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:56:29 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:56:29 --> Utf8 Class Initialized
INFO - 2019-12-04 22:56:29 --> URI Class Initialized
DEBUG - 2019-12-04 22:56:29 --> No URI present. Default controller set.
INFO - 2019-12-04 22:56:29 --> Router Class Initialized
INFO - 2019-12-04 22:56:29 --> Output Class Initialized
INFO - 2019-12-04 22:56:29 --> Security Class Initialized
DEBUG - 2019-12-04 22:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:56:29 --> CSRF cookie sent
INFO - 2019-12-04 22:56:29 --> Input Class Initialized
INFO - 2019-12-04 22:56:29 --> Language Class Initialized
INFO - 2019-12-04 22:56:29 --> Language Class Initialized
INFO - 2019-12-04 22:56:29 --> Config Class Initialized
INFO - 2019-12-04 22:56:29 --> Loader Class Initialized
INFO - 2019-12-04 22:56:29 --> Helper loaded: url_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: common_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: language_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: email_helper
INFO - 2019-12-04 22:56:29 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:56:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:56:29 --> Parser Class Initialized
INFO - 2019-12-04 22:56:29 --> User Agent Class Initialized
INFO - 2019-12-04 22:56:29 --> Model Class Initialized
INFO - 2019-12-04 22:56:29 --> Database Driver Class Initialized
INFO - 2019-12-04 22:56:29 --> Model Class Initialized
DEBUG - 2019-12-04 22:56:29 --> Template Class Initialized
INFO - 2019-12-04 22:56:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:56:30 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:56:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:56:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:56:30 --> Encryption Class Initialized
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-12-04 22:56:30 --> Controller Class Initialized
DEBUG - 2019-12-04 22:56:30 --> pergo MX_Controller Initialized
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-12-04 22:56:30 --> Model Class Initialized
INFO - 2019-12-04 22:56:30 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-12-04 22:56:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-12-04 22:56:30 --> Final output sent to browser
DEBUG - 2019-12-04 22:56:30 --> Total execution time: 0.8285
INFO - 2019-12-04 22:57:29 --> Config Class Initialized
INFO - 2019-12-04 22:57:29 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:57:29 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:57:29 --> Utf8 Class Initialized
INFO - 2019-12-04 22:57:30 --> URI Class Initialized
INFO - 2019-12-04 22:57:30 --> Router Class Initialized
INFO - 2019-12-04 22:57:30 --> Output Class Initialized
INFO - 2019-12-04 22:57:30 --> Security Class Initialized
DEBUG - 2019-12-04 22:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:57:30 --> CSRF cookie sent
INFO - 2019-12-04 22:57:30 --> CSRF token verified
INFO - 2019-12-04 22:57:30 --> Input Class Initialized
INFO - 2019-12-04 22:57:30 --> Language Class Initialized
INFO - 2019-12-04 22:57:30 --> Language Class Initialized
INFO - 2019-12-04 22:57:30 --> Config Class Initialized
INFO - 2019-12-04 22:57:30 --> Loader Class Initialized
INFO - 2019-12-04 22:57:30 --> Helper loaded: url_helper
INFO - 2019-12-04 22:57:30 --> Helper loaded: common_helper
INFO - 2019-12-04 22:57:30 --> Helper loaded: language_helper
INFO - 2019-12-04 22:57:30 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:57:30 --> Helper loaded: email_helper
INFO - 2019-12-04 22:57:30 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:57:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:57:30 --> Parser Class Initialized
INFO - 2019-12-04 22:57:30 --> User Agent Class Initialized
INFO - 2019-12-04 22:57:30 --> Model Class Initialized
INFO - 2019-12-04 22:57:30 --> Database Driver Class Initialized
INFO - 2019-12-04 22:57:30 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:30 --> Template Class Initialized
INFO - 2019-12-04 22:57:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:57:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:57:30 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:57:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:57:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:57:30 --> Encryption Class Initialized
INFO - 2019-12-04 22:57:30 --> Controller Class Initialized
DEBUG - 2019-12-04 22:57:30 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:57:30 --> Model Class Initialized
INFO - 2019-12-04 22:57:30 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:57:30 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:57:30 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:57:30 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:57:30 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:57:30 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:57:30 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:57:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:57:30 --> Final output sent to browser
DEBUG - 2019-12-04 22:57:31 --> Total execution time: 1.0474
INFO - 2019-12-04 22:57:39 --> Config Class Initialized
INFO - 2019-12-04 22:57:39 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:57:39 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:57:39 --> Utf8 Class Initialized
INFO - 2019-12-04 22:57:39 --> URI Class Initialized
INFO - 2019-12-04 22:57:39 --> Router Class Initialized
INFO - 2019-12-04 22:57:39 --> Output Class Initialized
INFO - 2019-12-04 22:57:39 --> Security Class Initialized
DEBUG - 2019-12-04 22:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:57:39 --> CSRF cookie sent
INFO - 2019-12-04 22:57:39 --> CSRF token verified
INFO - 2019-12-04 22:57:39 --> Input Class Initialized
INFO - 2019-12-04 22:57:39 --> Language Class Initialized
INFO - 2019-12-04 22:57:39 --> Language Class Initialized
INFO - 2019-12-04 22:57:39 --> Config Class Initialized
INFO - 2019-12-04 22:57:39 --> Loader Class Initialized
INFO - 2019-12-04 22:57:39 --> Helper loaded: url_helper
INFO - 2019-12-04 22:57:39 --> Helper loaded: common_helper
INFO - 2019-12-04 22:57:39 --> Helper loaded: language_helper
INFO - 2019-12-04 22:57:39 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:57:39 --> Helper loaded: email_helper
INFO - 2019-12-04 22:57:39 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:57:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:57:39 --> Parser Class Initialized
INFO - 2019-12-04 22:57:39 --> User Agent Class Initialized
INFO - 2019-12-04 22:57:39 --> Model Class Initialized
INFO - 2019-12-04 22:57:39 --> Database Driver Class Initialized
INFO - 2019-12-04 22:57:39 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:39 --> Template Class Initialized
INFO - 2019-12-04 22:57:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:57:39 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:57:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:57:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:57:39 --> Encryption Class Initialized
INFO - 2019-12-04 22:57:39 --> Controller Class Initialized
DEBUG - 2019-12-04 22:57:39 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:57:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:57:39 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:39 --> payop MX_Controller Initialized
INFO - 2019-12-04 22:57:48 --> Config Class Initialized
INFO - 2019-12-04 22:57:48 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:57:48 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:57:48 --> Utf8 Class Initialized
INFO - 2019-12-04 22:57:48 --> URI Class Initialized
INFO - 2019-12-04 22:57:48 --> Router Class Initialized
INFO - 2019-12-04 22:57:48 --> Output Class Initialized
INFO - 2019-12-04 22:57:48 --> Security Class Initialized
DEBUG - 2019-12-04 22:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:57:48 --> CSRF cookie sent
INFO - 2019-12-04 22:57:48 --> CSRF token verified
INFO - 2019-12-04 22:57:48 --> Input Class Initialized
INFO - 2019-12-04 22:57:48 --> Language Class Initialized
INFO - 2019-12-04 22:57:48 --> Language Class Initialized
INFO - 2019-12-04 22:57:48 --> Config Class Initialized
INFO - 2019-12-04 22:57:48 --> Loader Class Initialized
INFO - 2019-12-04 22:57:48 --> Helper loaded: url_helper
INFO - 2019-12-04 22:57:48 --> Helper loaded: common_helper
INFO - 2019-12-04 22:57:48 --> Helper loaded: language_helper
INFO - 2019-12-04 22:57:48 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:57:48 --> Helper loaded: email_helper
INFO - 2019-12-04 22:57:48 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:57:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:57:48 --> Parser Class Initialized
INFO - 2019-12-04 22:57:48 --> User Agent Class Initialized
INFO - 2019-12-04 22:57:48 --> Model Class Initialized
INFO - 2019-12-04 22:57:48 --> Database Driver Class Initialized
INFO - 2019-12-04 22:57:48 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:48 --> Template Class Initialized
INFO - 2019-12-04 22:57:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:57:48 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:57:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:57:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:57:48 --> Encryption Class Initialized
INFO - 2019-12-04 22:57:48 --> Controller Class Initialized
DEBUG - 2019-12-04 22:57:48 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:57:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:57:48 --> Model Class Initialized
INFO - 2019-12-04 22:57:48 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 22:57:49 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 22:57:49 --> Could not find the language line "payop"
ERROR - 2019-12-04 22:57:49 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 22:57:49 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 22:57:49 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 22:57:49 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 22:57:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 22:57:49 --> Final output sent to browser
DEBUG - 2019-12-04 22:57:49 --> Total execution time: 0.8349
INFO - 2019-12-04 22:57:56 --> Config Class Initialized
INFO - 2019-12-04 22:57:56 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:57:56 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:57:56 --> Utf8 Class Initialized
INFO - 2019-12-04 22:57:56 --> URI Class Initialized
INFO - 2019-12-04 22:57:56 --> Router Class Initialized
INFO - 2019-12-04 22:57:56 --> Output Class Initialized
INFO - 2019-12-04 22:57:56 --> Security Class Initialized
DEBUG - 2019-12-04 22:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:57:56 --> CSRF cookie sent
INFO - 2019-12-04 22:57:56 --> CSRF token verified
INFO - 2019-12-04 22:57:56 --> Input Class Initialized
INFO - 2019-12-04 22:57:56 --> Language Class Initialized
INFO - 2019-12-04 22:57:56 --> Language Class Initialized
INFO - 2019-12-04 22:57:56 --> Config Class Initialized
INFO - 2019-12-04 22:57:56 --> Loader Class Initialized
INFO - 2019-12-04 22:57:56 --> Helper loaded: url_helper
INFO - 2019-12-04 22:57:56 --> Helper loaded: common_helper
INFO - 2019-12-04 22:57:56 --> Helper loaded: language_helper
INFO - 2019-12-04 22:57:56 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:57:56 --> Helper loaded: email_helper
INFO - 2019-12-04 22:57:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:57:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:57:56 --> Parser Class Initialized
INFO - 2019-12-04 22:57:56 --> User Agent Class Initialized
INFO - 2019-12-04 22:57:56 --> Model Class Initialized
INFO - 2019-12-04 22:57:56 --> Database Driver Class Initialized
INFO - 2019-12-04 22:57:56 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:56 --> Template Class Initialized
INFO - 2019-12-04 22:57:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:57:56 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:57:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:57:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:57:56 --> Encryption Class Initialized
INFO - 2019-12-04 22:57:57 --> Controller Class Initialized
DEBUG - 2019-12-04 22:57:57 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:57:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:57:57 --> Model Class Initialized
DEBUG - 2019-12-04 22:57:57 --> payop MX_Controller Initialized
ERROR - 2019-12-04 22:57:57 --> Severity: error --> Exception: Call to undefined function send_post_curl() D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\payop.php 96
INFO - 2019-12-04 22:58:34 --> Config Class Initialized
INFO - 2019-12-04 22:58:34 --> Hooks Class Initialized
DEBUG - 2019-12-04 22:58:34 --> UTF-8 Support Enabled
INFO - 2019-12-04 22:58:34 --> Utf8 Class Initialized
INFO - 2019-12-04 22:58:34 --> URI Class Initialized
INFO - 2019-12-04 22:58:34 --> Router Class Initialized
INFO - 2019-12-04 22:58:34 --> Output Class Initialized
INFO - 2019-12-04 22:58:34 --> Security Class Initialized
DEBUG - 2019-12-04 22:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 22:58:34 --> CSRF cookie sent
INFO - 2019-12-04 22:58:34 --> CSRF token verified
INFO - 2019-12-04 22:58:34 --> Input Class Initialized
INFO - 2019-12-04 22:58:34 --> Language Class Initialized
INFO - 2019-12-04 22:58:34 --> Language Class Initialized
INFO - 2019-12-04 22:58:34 --> Config Class Initialized
INFO - 2019-12-04 22:58:34 --> Loader Class Initialized
INFO - 2019-12-04 22:58:34 --> Helper loaded: url_helper
INFO - 2019-12-04 22:58:34 --> Helper loaded: common_helper
INFO - 2019-12-04 22:58:34 --> Helper loaded: language_helper
INFO - 2019-12-04 22:58:34 --> Helper loaded: cookie_helper
INFO - 2019-12-04 22:58:34 --> Helper loaded: email_helper
INFO - 2019-12-04 22:58:34 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 22:58:34 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 22:58:34 --> Parser Class Initialized
INFO - 2019-12-04 22:58:34 --> User Agent Class Initialized
INFO - 2019-12-04 22:58:34 --> Model Class Initialized
INFO - 2019-12-04 22:58:34 --> Database Driver Class Initialized
INFO - 2019-12-04 22:58:34 --> Model Class Initialized
DEBUG - 2019-12-04 22:58:34 --> Template Class Initialized
INFO - 2019-12-04 22:58:34 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 22:58:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 22:58:34 --> Pagination Class Initialized
DEBUG - 2019-12-04 22:58:34 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 22:58:34 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 22:58:34 --> Encryption Class Initialized
INFO - 2019-12-04 22:58:34 --> Controller Class Initialized
DEBUG - 2019-12-04 22:58:34 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 22:58:34 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 22:58:34 --> Model Class Initialized
DEBUG - 2019-12-04 22:58:34 --> payop MX_Controller Initialized
INFO - 2019-12-04 23:00:24 --> Config Class Initialized
INFO - 2019-12-04 23:00:25 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:00:25 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:00:25 --> Utf8 Class Initialized
INFO - 2019-12-04 23:00:25 --> URI Class Initialized
INFO - 2019-12-04 23:00:25 --> Router Class Initialized
INFO - 2019-12-04 23:00:25 --> Output Class Initialized
INFO - 2019-12-04 23:00:25 --> Security Class Initialized
DEBUG - 2019-12-04 23:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:00:25 --> CSRF cookie sent
INFO - 2019-12-04 23:00:25 --> CSRF token verified
INFO - 2019-12-04 23:00:25 --> Input Class Initialized
INFO - 2019-12-04 23:00:25 --> Language Class Initialized
INFO - 2019-12-04 23:00:25 --> Language Class Initialized
INFO - 2019-12-04 23:00:25 --> Config Class Initialized
INFO - 2019-12-04 23:00:25 --> Loader Class Initialized
INFO - 2019-12-04 23:00:25 --> Helper loaded: url_helper
INFO - 2019-12-04 23:00:25 --> Helper loaded: common_helper
INFO - 2019-12-04 23:00:25 --> Helper loaded: language_helper
INFO - 2019-12-04 23:00:25 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:00:25 --> Helper loaded: email_helper
INFO - 2019-12-04 23:00:25 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:00:25 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:00:25 --> Parser Class Initialized
INFO - 2019-12-04 23:00:25 --> User Agent Class Initialized
INFO - 2019-12-04 23:00:25 --> Model Class Initialized
INFO - 2019-12-04 23:00:25 --> Database Driver Class Initialized
INFO - 2019-12-04 23:00:25 --> Model Class Initialized
DEBUG - 2019-12-04 23:00:25 --> Template Class Initialized
INFO - 2019-12-04 23:00:25 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:00:25 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:00:25 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:00:25 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:00:25 --> Encryption Class Initialized
INFO - 2019-12-04 23:00:25 --> Controller Class Initialized
DEBUG - 2019-12-04 23:00:25 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 23:00:25 --> Model Class Initialized
INFO - 2019-12-04 23:00:25 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 23:00:25 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 23:00:25 --> Could not find the language line "payop"
ERROR - 2019-12-04 23:00:25 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 23:00:25 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 23:00:25 --> Model Class Initialized
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 23:00:25 --> Model Class Initialized
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 23:00:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 23:00:25 --> Final output sent to browser
DEBUG - 2019-12-04 23:00:25 --> Total execution time: 0.8615
INFO - 2019-12-04 23:00:37 --> Config Class Initialized
INFO - 2019-12-04 23:00:37 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:00:37 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:00:37 --> Utf8 Class Initialized
INFO - 2019-12-04 23:00:37 --> URI Class Initialized
INFO - 2019-12-04 23:00:37 --> Router Class Initialized
INFO - 2019-12-04 23:00:37 --> Output Class Initialized
INFO - 2019-12-04 23:00:37 --> Security Class Initialized
DEBUG - 2019-12-04 23:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:00:37 --> CSRF cookie sent
INFO - 2019-12-04 23:00:37 --> CSRF token verified
INFO - 2019-12-04 23:00:37 --> Input Class Initialized
INFO - 2019-12-04 23:00:37 --> Language Class Initialized
INFO - 2019-12-04 23:00:38 --> Language Class Initialized
INFO - 2019-12-04 23:00:38 --> Config Class Initialized
INFO - 2019-12-04 23:00:38 --> Loader Class Initialized
INFO - 2019-12-04 23:00:38 --> Helper loaded: url_helper
INFO - 2019-12-04 23:00:38 --> Helper loaded: common_helper
INFO - 2019-12-04 23:00:38 --> Helper loaded: language_helper
INFO - 2019-12-04 23:00:38 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:00:38 --> Helper loaded: email_helper
INFO - 2019-12-04 23:00:38 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:00:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:00:38 --> Parser Class Initialized
INFO - 2019-12-04 23:00:38 --> User Agent Class Initialized
INFO - 2019-12-04 23:00:38 --> Model Class Initialized
INFO - 2019-12-04 23:00:38 --> Database Driver Class Initialized
INFO - 2019-12-04 23:00:38 --> Model Class Initialized
DEBUG - 2019-12-04 23:00:38 --> Template Class Initialized
INFO - 2019-12-04 23:00:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:00:38 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:00:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:00:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:00:38 --> Encryption Class Initialized
INFO - 2019-12-04 23:00:38 --> Controller Class Initialized
DEBUG - 2019-12-04 23:00:38 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 23:00:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 23:00:38 --> Model Class Initialized
DEBUG - 2019-12-04 23:00:38 --> payop MX_Controller Initialized
INFO - 2019-12-04 23:05:56 --> Config Class Initialized
INFO - 2019-12-04 23:05:56 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:05:56 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:05:56 --> Utf8 Class Initialized
INFO - 2019-12-04 23:05:56 --> URI Class Initialized
INFO - 2019-12-04 23:05:56 --> Router Class Initialized
INFO - 2019-12-04 23:05:56 --> Output Class Initialized
INFO - 2019-12-04 23:05:56 --> Security Class Initialized
DEBUG - 2019-12-04 23:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:05:56 --> CSRF cookie sent
INFO - 2019-12-04 23:05:56 --> CSRF token verified
INFO - 2019-12-04 23:05:56 --> Input Class Initialized
INFO - 2019-12-04 23:05:56 --> Language Class Initialized
INFO - 2019-12-04 23:05:56 --> Language Class Initialized
INFO - 2019-12-04 23:05:56 --> Config Class Initialized
INFO - 2019-12-04 23:05:56 --> Loader Class Initialized
INFO - 2019-12-04 23:05:56 --> Helper loaded: url_helper
INFO - 2019-12-04 23:05:56 --> Helper loaded: common_helper
INFO - 2019-12-04 23:05:56 --> Helper loaded: language_helper
INFO - 2019-12-04 23:05:56 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:05:56 --> Helper loaded: email_helper
INFO - 2019-12-04 23:05:56 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:05:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:05:56 --> Parser Class Initialized
INFO - 2019-12-04 23:05:56 --> User Agent Class Initialized
INFO - 2019-12-04 23:05:56 --> Model Class Initialized
INFO - 2019-12-04 23:05:56 --> Database Driver Class Initialized
INFO - 2019-12-04 23:05:56 --> Model Class Initialized
DEBUG - 2019-12-04 23:05:56 --> Template Class Initialized
INFO - 2019-12-04 23:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:05:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:05:56 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:05:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:05:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:05:56 --> Encryption Class Initialized
INFO - 2019-12-04 23:05:56 --> Controller Class Initialized
DEBUG - 2019-12-04 23:05:56 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 23:05:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 23:05:56 --> Model Class Initialized
INFO - 2019-12-04 23:05:56 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 23:05:56 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 23:05:56 --> Could not find the language line "payop"
ERROR - 2019-12-04 23:05:57 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 23:05:57 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 23:05:57 --> Model Class Initialized
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 23:05:57 --> Model Class Initialized
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 23:05:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 23:05:57 --> Final output sent to browser
DEBUG - 2019-12-04 23:05:57 --> Total execution time: 1.0374
INFO - 2019-12-04 23:06:00 --> Config Class Initialized
INFO - 2019-12-04 23:06:00 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:06:00 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:06:00 --> Utf8 Class Initialized
INFO - 2019-12-04 23:06:00 --> URI Class Initialized
INFO - 2019-12-04 23:06:00 --> Router Class Initialized
INFO - 2019-12-04 23:06:00 --> Output Class Initialized
INFO - 2019-12-04 23:06:00 --> Security Class Initialized
DEBUG - 2019-12-04 23:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:06:00 --> CSRF cookie sent
INFO - 2019-12-04 23:06:00 --> Input Class Initialized
INFO - 2019-12-04 23:06:00 --> Language Class Initialized
INFO - 2019-12-04 23:06:00 --> Language Class Initialized
INFO - 2019-12-04 23:06:00 --> Config Class Initialized
INFO - 2019-12-04 23:06:00 --> Loader Class Initialized
INFO - 2019-12-04 23:06:00 --> Helper loaded: url_helper
INFO - 2019-12-04 23:06:00 --> Helper loaded: common_helper
INFO - 2019-12-04 23:06:00 --> Helper loaded: language_helper
INFO - 2019-12-04 23:06:00 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:06:00 --> Helper loaded: email_helper
INFO - 2019-12-04 23:06:00 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:06:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:06:00 --> Parser Class Initialized
INFO - 2019-12-04 23:06:00 --> User Agent Class Initialized
INFO - 2019-12-04 23:06:00 --> Model Class Initialized
INFO - 2019-12-04 23:06:00 --> Database Driver Class Initialized
INFO - 2019-12-04 23:06:00 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:00 --> Template Class Initialized
INFO - 2019-12-04 23:06:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:06:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:06:00 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:06:00 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:06:00 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:06:00 --> Encryption Class Initialized
INFO - 2019-12-04 23:06:00 --> Controller Class Initialized
DEBUG - 2019-12-04 23:06:00 --> transactions MX_Controller Initialized
DEBUG - 2019-12-04 23:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-04 23:06:00 --> Model Class Initialized
ERROR - 2019-12-04 23:06:00 --> Could not find the language line "order_id"
INFO - 2019-12-04 23:06:00 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 23:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-04 23:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 23:06:00 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 23:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 23:06:00 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 23:06:00 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:00 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 23:06:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 23:06:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 23:06:01 --> Final output sent to browser
DEBUG - 2019-12-04 23:06:01 --> Total execution time: 0.9494
INFO - 2019-12-04 23:06:05 --> Config Class Initialized
INFO - 2019-12-04 23:06:05 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:06:05 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:06:05 --> Utf8 Class Initialized
INFO - 2019-12-04 23:06:05 --> URI Class Initialized
INFO - 2019-12-04 23:06:05 --> Router Class Initialized
INFO - 2019-12-04 23:06:05 --> Output Class Initialized
INFO - 2019-12-04 23:06:05 --> Security Class Initialized
DEBUG - 2019-12-04 23:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:06:06 --> CSRF cookie sent
INFO - 2019-12-04 23:06:06 --> CSRF token verified
INFO - 2019-12-04 23:06:06 --> Input Class Initialized
INFO - 2019-12-04 23:06:06 --> Language Class Initialized
INFO - 2019-12-04 23:06:06 --> Language Class Initialized
INFO - 2019-12-04 23:06:06 --> Config Class Initialized
INFO - 2019-12-04 23:06:06 --> Loader Class Initialized
INFO - 2019-12-04 23:06:06 --> Helper loaded: url_helper
INFO - 2019-12-04 23:06:06 --> Helper loaded: common_helper
INFO - 2019-12-04 23:06:06 --> Helper loaded: language_helper
INFO - 2019-12-04 23:06:06 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:06:06 --> Helper loaded: email_helper
INFO - 2019-12-04 23:06:06 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:06:06 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:06:06 --> Parser Class Initialized
INFO - 2019-12-04 23:06:06 --> User Agent Class Initialized
INFO - 2019-12-04 23:06:06 --> Model Class Initialized
INFO - 2019-12-04 23:06:06 --> Database Driver Class Initialized
INFO - 2019-12-04 23:06:06 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:06 --> Template Class Initialized
INFO - 2019-12-04 23:06:06 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:06:06 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:06:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:06:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:06:06 --> Encryption Class Initialized
INFO - 2019-12-04 23:06:06 --> Controller Class Initialized
DEBUG - 2019-12-04 23:06:06 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 23:06:06 --> Model Class Initialized
INFO - 2019-12-04 23:06:06 --> Helper loaded: inflector_helper
ERROR - 2019-12-04 23:06:06 --> Could not find the language line "hesabe"
ERROR - 2019-12-04 23:06:06 --> Could not find the language line "payop"
ERROR - 2019-12-04 23:06:06 --> Could not find the language line "shopier"
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 23:06:06 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 23:06:06 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 23:06:06 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-12-04 23:06:06 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-12-04 23:06:06 --> Final output sent to browser
DEBUG - 2019-12-04 23:06:06 --> Total execution time: 0.9719
INFO - 2019-12-04 23:06:16 --> Config Class Initialized
INFO - 2019-12-04 23:06:16 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:06:16 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:06:16 --> Utf8 Class Initialized
INFO - 2019-12-04 23:06:16 --> URI Class Initialized
INFO - 2019-12-04 23:06:16 --> Router Class Initialized
INFO - 2019-12-04 23:06:16 --> Output Class Initialized
INFO - 2019-12-04 23:06:16 --> Security Class Initialized
DEBUG - 2019-12-04 23:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:06:16 --> CSRF cookie sent
INFO - 2019-12-04 23:06:16 --> CSRF token verified
INFO - 2019-12-04 23:06:16 --> Input Class Initialized
INFO - 2019-12-04 23:06:16 --> Language Class Initialized
INFO - 2019-12-04 23:06:16 --> Language Class Initialized
INFO - 2019-12-04 23:06:16 --> Config Class Initialized
INFO - 2019-12-04 23:06:16 --> Loader Class Initialized
INFO - 2019-12-04 23:06:16 --> Helper loaded: url_helper
INFO - 2019-12-04 23:06:16 --> Helper loaded: common_helper
INFO - 2019-12-04 23:06:16 --> Helper loaded: language_helper
INFO - 2019-12-04 23:06:16 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:06:16 --> Helper loaded: email_helper
INFO - 2019-12-04 23:06:16 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:06:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:06:16 --> Parser Class Initialized
INFO - 2019-12-04 23:06:16 --> User Agent Class Initialized
INFO - 2019-12-04 23:06:16 --> Model Class Initialized
INFO - 2019-12-04 23:06:16 --> Database Driver Class Initialized
INFO - 2019-12-04 23:06:16 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:16 --> Template Class Initialized
INFO - 2019-12-04 23:06:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:06:16 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:06:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:06:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:06:16 --> Encryption Class Initialized
INFO - 2019-12-04 23:06:16 --> Controller Class Initialized
DEBUG - 2019-12-04 23:06:16 --> checkout MX_Controller Initialized
DEBUG - 2019-12-04 23:06:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-12-04 23:06:16 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:16 --> payop MX_Controller Initialized
DEBUG - 2019-12-04 23:06:18 --> orders MX_Controller Initialized
DEBUG - 2019-12-04 23:06:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payop/index.php
INFO - 2019-12-04 23:06:18 --> Final output sent to browser
DEBUG - 2019-12-04 23:06:18 --> Total execution time: 1.9870
INFO - 2019-12-04 23:06:26 --> Config Class Initialized
INFO - 2019-12-04 23:06:26 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:06:26 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:06:26 --> Utf8 Class Initialized
INFO - 2019-12-04 23:06:26 --> URI Class Initialized
INFO - 2019-12-04 23:06:26 --> Router Class Initialized
INFO - 2019-12-04 23:06:26 --> Output Class Initialized
INFO - 2019-12-04 23:06:26 --> Security Class Initialized
DEBUG - 2019-12-04 23:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:06:26 --> CSRF cookie sent
INFO - 2019-12-04 23:06:26 --> Input Class Initialized
INFO - 2019-12-04 23:06:26 --> Language Class Initialized
INFO - 2019-12-04 23:06:26 --> Language Class Initialized
INFO - 2019-12-04 23:06:26 --> Config Class Initialized
INFO - 2019-12-04 23:06:26 --> Loader Class Initialized
INFO - 2019-12-04 23:06:26 --> Helper loaded: url_helper
INFO - 2019-12-04 23:06:26 --> Helper loaded: common_helper
INFO - 2019-12-04 23:06:26 --> Helper loaded: language_helper
INFO - 2019-12-04 23:06:26 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:06:26 --> Helper loaded: email_helper
INFO - 2019-12-04 23:06:26 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:06:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:06:26 --> Parser Class Initialized
INFO - 2019-12-04 23:06:26 --> User Agent Class Initialized
INFO - 2019-12-04 23:06:26 --> Model Class Initialized
INFO - 2019-12-04 23:06:26 --> Database Driver Class Initialized
INFO - 2019-12-04 23:06:26 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:26 --> Template Class Initialized
INFO - 2019-12-04 23:06:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:06:26 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:06:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:06:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:06:26 --> Encryption Class Initialized
INFO - 2019-12-04 23:06:26 --> Controller Class Initialized
DEBUG - 2019-12-04 23:06:26 --> transactions MX_Controller Initialized
DEBUG - 2019-12-04 23:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-12-04 23:06:26 --> Model Class Initialized
ERROR - 2019-12-04 23:06:26 --> Could not find the language line "order_id"
INFO - 2019-12-04 23:06:26 --> Helper loaded: inflector_helper
DEBUG - 2019-12-04 23:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-12-04 23:06:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-12-04 23:06:26 --> blocks MX_Controller Initialized
DEBUG - 2019-12-04 23:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-12-04 23:06:27 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-12-04 23:06:27 --> Model Class Initialized
DEBUG - 2019-12-04 23:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-12-04 23:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-12-04 23:06:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-12-04 23:06:27 --> Final output sent to browser
DEBUG - 2019-12-04 23:06:27 --> Total execution time: 0.8728
INFO - 2019-12-04 23:09:58 --> Config Class Initialized
INFO - 2019-12-04 23:09:58 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:09:58 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:09:58 --> Utf8 Class Initialized
INFO - 2019-12-04 23:09:58 --> URI Class Initialized
INFO - 2019-12-04 23:09:58 --> Router Class Initialized
INFO - 2019-12-04 23:09:58 --> Output Class Initialized
INFO - 2019-12-04 23:09:58 --> Security Class Initialized
DEBUG - 2019-12-04 23:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:09:58 --> CSRF cookie sent
INFO - 2019-12-04 23:09:58 --> Input Class Initialized
INFO - 2019-12-04 23:09:58 --> Language Class Initialized
INFO - 2019-12-04 23:09:58 --> Language Class Initialized
INFO - 2019-12-04 23:09:58 --> Config Class Initialized
INFO - 2019-12-04 23:09:58 --> Loader Class Initialized
INFO - 2019-12-04 23:09:58 --> Helper loaded: url_helper
INFO - 2019-12-04 23:09:58 --> Helper loaded: common_helper
INFO - 2019-12-04 23:09:58 --> Helper loaded: language_helper
INFO - 2019-12-04 23:09:58 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:09:58 --> Helper loaded: email_helper
INFO - 2019-12-04 23:09:58 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:09:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:09:58 --> Parser Class Initialized
INFO - 2019-12-04 23:09:58 --> User Agent Class Initialized
DEBUG - 2019-12-04 23:09:58 --> Template Class Initialized
INFO - 2019-12-04 23:09:58 --> Database Driver Class Initialized
INFO - 2019-12-04 23:09:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:09:58 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:09:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:09:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:09:58 --> Encryption Class Initialized
INFO - 2019-12-04 23:09:58 --> Controller Class Initialized
DEBUG - 2019-12-04 23:09:58 --> payop MX_Controller Initialized
INFO - 2019-12-04 23:09:58 --> Model Class Initialized
INFO - 2019-12-04 23:09:58 --> Model Class Initialized
INFO - 2019-12-04 23:09:58 --> Model Class Initialized
ERROR - 2019-12-04 23:10:00 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-04 23:10:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-04 23:11:33 --> Config Class Initialized
INFO - 2019-12-04 23:11:33 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:11:33 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:11:33 --> Utf8 Class Initialized
INFO - 2019-12-04 23:11:33 --> URI Class Initialized
INFO - 2019-12-04 23:11:33 --> Router Class Initialized
INFO - 2019-12-04 23:11:33 --> Output Class Initialized
INFO - 2019-12-04 23:11:33 --> Security Class Initialized
DEBUG - 2019-12-04 23:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:11:33 --> CSRF cookie sent
INFO - 2019-12-04 23:11:33 --> Input Class Initialized
INFO - 2019-12-04 23:11:33 --> Language Class Initialized
INFO - 2019-12-04 23:11:33 --> Language Class Initialized
INFO - 2019-12-04 23:11:33 --> Config Class Initialized
INFO - 2019-12-04 23:11:33 --> Loader Class Initialized
INFO - 2019-12-04 23:11:33 --> Helper loaded: url_helper
INFO - 2019-12-04 23:11:33 --> Helper loaded: common_helper
INFO - 2019-12-04 23:11:33 --> Helper loaded: language_helper
INFO - 2019-12-04 23:11:33 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:11:33 --> Helper loaded: email_helper
INFO - 2019-12-04 23:11:33 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:11:33 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:11:33 --> Parser Class Initialized
INFO - 2019-12-04 23:11:33 --> User Agent Class Initialized
DEBUG - 2019-12-04 23:11:33 --> Template Class Initialized
INFO - 2019-12-04 23:11:33 --> Database Driver Class Initialized
INFO - 2019-12-04 23:11:33 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:11:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:11:33 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:11:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:11:33 --> Encryption Class Initialized
INFO - 2019-12-04 23:11:33 --> Controller Class Initialized
DEBUG - 2019-12-04 23:11:33 --> payop MX_Controller Initialized
INFO - 2019-12-04 23:11:34 --> Model Class Initialized
INFO - 2019-12-04 23:11:34 --> Model Class Initialized
INFO - 2019-12-04 23:11:34 --> Model Class Initialized
ERROR - 2019-12-04 23:11:35 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-04 23:11:35 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-12-04 23:12:01 --> Config Class Initialized
INFO - 2019-12-04 23:12:01 --> Hooks Class Initialized
DEBUG - 2019-12-04 23:12:01 --> UTF-8 Support Enabled
INFO - 2019-12-04 23:12:01 --> Utf8 Class Initialized
INFO - 2019-12-04 23:12:01 --> URI Class Initialized
INFO - 2019-12-04 23:12:01 --> Router Class Initialized
INFO - 2019-12-04 23:12:01 --> Output Class Initialized
INFO - 2019-12-04 23:12:01 --> Security Class Initialized
DEBUG - 2019-12-04 23:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-12-04 23:12:01 --> CSRF cookie sent
INFO - 2019-12-04 23:12:01 --> Input Class Initialized
INFO - 2019-12-04 23:12:01 --> Language Class Initialized
INFO - 2019-12-04 23:12:01 --> Language Class Initialized
INFO - 2019-12-04 23:12:01 --> Config Class Initialized
INFO - 2019-12-04 23:12:01 --> Loader Class Initialized
INFO - 2019-12-04 23:12:02 --> Helper loaded: url_helper
INFO - 2019-12-04 23:12:02 --> Helper loaded: common_helper
INFO - 2019-12-04 23:12:02 --> Helper loaded: language_helper
INFO - 2019-12-04 23:12:02 --> Helper loaded: cookie_helper
INFO - 2019-12-04 23:12:02 --> Helper loaded: email_helper
INFO - 2019-12-04 23:12:02 --> Helper loaded: file_manager_helper
INFO - 2019-12-04 23:12:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-12-04 23:12:02 --> Parser Class Initialized
INFO - 2019-12-04 23:12:02 --> User Agent Class Initialized
DEBUG - 2019-12-04 23:12:02 --> Template Class Initialized
INFO - 2019-12-04 23:12:02 --> Database Driver Class Initialized
INFO - 2019-12-04 23:12:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-12-04 23:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-12-04 23:12:02 --> Pagination Class Initialized
DEBUG - 2019-12-04 23:12:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-12-04 23:12:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-12-04 23:12:02 --> Encryption Class Initialized
INFO - 2019-12-04 23:12:02 --> Controller Class Initialized
DEBUG - 2019-12-04 23:12:02 --> payop MX_Controller Initialized
INFO - 2019-12-04 23:12:02 --> Model Class Initialized
INFO - 2019-12-04 23:12:02 --> Model Class Initialized
INFO - 2019-12-04 23:12:02 --> Model Class Initialized
ERROR - 2019-12-04 23:12:03 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-12-04 23:12:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
