<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-20 09:59:21 --> Config Class Initialized
INFO - 2020-04-20 09:59:21 --> Hooks Class Initialized
DEBUG - 2020-04-20 09:59:21 --> UTF-8 Support Enabled
INFO - 2020-04-20 09:59:21 --> Utf8 Class Initialized
INFO - 2020-04-20 09:59:21 --> URI Class Initialized
DEBUG - 2020-04-20 09:59:21 --> No URI present. Default controller set.
INFO - 2020-04-20 09:59:21 --> Router Class Initialized
INFO - 2020-04-20 09:59:21 --> Output Class Initialized
INFO - 2020-04-20 09:59:21 --> Security Class Initialized
DEBUG - 2020-04-20 09:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 09:59:21 --> CSRF cookie sent
INFO - 2020-04-20 09:59:21 --> Input Class Initialized
INFO - 2020-04-20 09:59:21 --> Language Class Initialized
INFO - 2020-04-20 09:59:21 --> Language Class Initialized
INFO - 2020-04-20 09:59:21 --> Config Class Initialized
INFO - 2020-04-20 09:59:21 --> Loader Class Initialized
INFO - 2020-04-20 09:59:21 --> Helper loaded: url_helper
INFO - 2020-04-20 09:59:21 --> Helper loaded: file_helper
INFO - 2020-04-20 09:59:21 --> Helper loaded: cookie_helper
INFO - 2020-04-20 09:59:21 --> Helper loaded: common_helper
INFO - 2020-04-20 09:59:21 --> Helper loaded: language_helper
INFO - 2020-04-20 09:59:21 --> Helper loaded: email_helper
INFO - 2020-04-20 09:59:21 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 09:59:21 --> Database Driver Class Initialized
INFO - 2020-04-20 09:59:21 --> Parser Class Initialized
INFO - 2020-04-20 09:59:21 --> User Agent Class Initialized
INFO - 2020-04-20 09:59:21 --> Model Class Initialized
INFO - 2020-04-20 09:59:21 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:21 --> Template Class Initialized
INFO - 2020-04-20 09:59:21 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 09:59:21 --> Email Class Initialized
INFO - 2020-04-20 09:59:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 09:59:21 --> Pagination Class Initialized
DEBUG - 2020-04-20 09:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 09:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 09:59:22 --> Encryption Class Initialized
INFO - 2020-04-20 09:59:22 --> Controller Class Initialized
DEBUG - 2020-04-20 09:59:22 --> home MX_Controller Initialized
INFO - 2020-04-20 09:59:22 --> Helper loaded: inflector_helper
DEBUG - 2020-04-20 09:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/home/views/index.php
DEBUG - 2020-04-20 09:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/landing_page.php
INFO - 2020-04-20 09:59:22 --> Final output sent to browser
DEBUG - 2020-04-20 09:59:22 --> Total execution time: 1.2495
INFO - 2020-04-20 09:59:23 --> Config Class Initialized
INFO - 2020-04-20 09:59:23 --> Hooks Class Initialized
DEBUG - 2020-04-20 09:59:23 --> UTF-8 Support Enabled
INFO - 2020-04-20 09:59:23 --> Utf8 Class Initialized
INFO - 2020-04-20 09:59:23 --> URI Class Initialized
INFO - 2020-04-20 09:59:23 --> Router Class Initialized
INFO - 2020-04-20 09:59:23 --> Output Class Initialized
INFO - 2020-04-20 09:59:23 --> Security Class Initialized
DEBUG - 2020-04-20 09:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 09:59:23 --> CSRF cookie sent
INFO - 2020-04-20 09:59:23 --> Input Class Initialized
INFO - 2020-04-20 09:59:23 --> Language Class Initialized
ERROR - 2020-04-20 09:59:23 --> 404 Page Not Found: /index
INFO - 2020-04-20 09:59:26 --> Config Class Initialized
INFO - 2020-04-20 09:59:26 --> Hooks Class Initialized
DEBUG - 2020-04-20 09:59:26 --> UTF-8 Support Enabled
INFO - 2020-04-20 09:59:26 --> Utf8 Class Initialized
INFO - 2020-04-20 09:59:26 --> URI Class Initialized
INFO - 2020-04-20 09:59:26 --> Router Class Initialized
INFO - 2020-04-20 09:59:26 --> Output Class Initialized
INFO - 2020-04-20 09:59:26 --> Security Class Initialized
DEBUG - 2020-04-20 09:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 09:59:26 --> CSRF cookie sent
INFO - 2020-04-20 09:59:26 --> Input Class Initialized
INFO - 2020-04-20 09:59:26 --> Language Class Initialized
INFO - 2020-04-20 09:59:26 --> Language Class Initialized
INFO - 2020-04-20 09:59:26 --> Config Class Initialized
INFO - 2020-04-20 09:59:26 --> Loader Class Initialized
INFO - 2020-04-20 09:59:26 --> Helper loaded: url_helper
INFO - 2020-04-20 09:59:26 --> Helper loaded: file_helper
INFO - 2020-04-20 09:59:26 --> Helper loaded: cookie_helper
INFO - 2020-04-20 09:59:26 --> Helper loaded: common_helper
INFO - 2020-04-20 09:59:26 --> Helper loaded: language_helper
INFO - 2020-04-20 09:59:26 --> Helper loaded: email_helper
INFO - 2020-04-20 09:59:26 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 09:59:26 --> Database Driver Class Initialized
INFO - 2020-04-20 09:59:26 --> Parser Class Initialized
INFO - 2020-04-20 09:59:26 --> User Agent Class Initialized
INFO - 2020-04-20 09:59:26 --> Model Class Initialized
INFO - 2020-04-20 09:59:26 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:26 --> Template Class Initialized
INFO - 2020-04-20 09:59:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 09:59:26 --> Email Class Initialized
INFO - 2020-04-20 09:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 09:59:26 --> Pagination Class Initialized
DEBUG - 2020-04-20 09:59:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 09:59:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 09:59:26 --> Encryption Class Initialized
INFO - 2020-04-20 09:59:26 --> Controller Class Initialized
DEBUG - 2020-04-20 09:59:26 --> auth MX_Controller Initialized
INFO - 2020-04-20 09:59:26 --> Helper loaded: inflector_helper
DEBUG - 2020-04-20 09:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/auth/views/login.php
DEBUG - 2020-04-20 09:59:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/oauth.php
INFO - 2020-04-20 09:59:26 --> Final output sent to browser
DEBUG - 2020-04-20 09:59:26 --> Total execution time: 0.7187
INFO - 2020-04-20 09:59:40 --> Config Class Initialized
INFO - 2020-04-20 09:59:40 --> Hooks Class Initialized
DEBUG - 2020-04-20 09:59:40 --> UTF-8 Support Enabled
INFO - 2020-04-20 09:59:40 --> Utf8 Class Initialized
INFO - 2020-04-20 09:59:40 --> URI Class Initialized
INFO - 2020-04-20 09:59:40 --> Router Class Initialized
INFO - 2020-04-20 09:59:40 --> Output Class Initialized
INFO - 2020-04-20 09:59:40 --> Security Class Initialized
DEBUG - 2020-04-20 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 09:59:40 --> CSRF cookie sent
INFO - 2020-04-20 09:59:40 --> CSRF token verified
INFO - 2020-04-20 09:59:40 --> Input Class Initialized
INFO - 2020-04-20 09:59:40 --> Language Class Initialized
INFO - 2020-04-20 09:59:40 --> Language Class Initialized
INFO - 2020-04-20 09:59:40 --> Config Class Initialized
INFO - 2020-04-20 09:59:40 --> Loader Class Initialized
INFO - 2020-04-20 09:59:40 --> Helper loaded: url_helper
INFO - 2020-04-20 09:59:40 --> Helper loaded: file_helper
INFO - 2020-04-20 09:59:40 --> Helper loaded: cookie_helper
INFO - 2020-04-20 09:59:40 --> Helper loaded: common_helper
INFO - 2020-04-20 09:59:40 --> Helper loaded: language_helper
INFO - 2020-04-20 09:59:40 --> Helper loaded: email_helper
INFO - 2020-04-20 09:59:40 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 09:59:40 --> Database Driver Class Initialized
INFO - 2020-04-20 09:59:40 --> Parser Class Initialized
INFO - 2020-04-20 09:59:40 --> User Agent Class Initialized
INFO - 2020-04-20 09:59:40 --> Model Class Initialized
INFO - 2020-04-20 09:59:40 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:40 --> Template Class Initialized
INFO - 2020-04-20 09:59:40 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 09:59:40 --> Email Class Initialized
INFO - 2020-04-20 09:59:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 09:59:40 --> Pagination Class Initialized
DEBUG - 2020-04-20 09:59:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 09:59:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 09:59:40 --> Encryption Class Initialized
INFO - 2020-04-20 09:59:40 --> Controller Class Initialized
DEBUG - 2020-04-20 09:59:40 --> auth MX_Controller Initialized
INFO - 2020-04-20 09:59:42 --> Config Class Initialized
INFO - 2020-04-20 09:59:42 --> Hooks Class Initialized
DEBUG - 2020-04-20 09:59:42 --> UTF-8 Support Enabled
INFO - 2020-04-20 09:59:42 --> Utf8 Class Initialized
INFO - 2020-04-20 09:59:42 --> URI Class Initialized
INFO - 2020-04-20 09:59:42 --> Router Class Initialized
INFO - 2020-04-20 09:59:42 --> Output Class Initialized
INFO - 2020-04-20 09:59:42 --> Security Class Initialized
DEBUG - 2020-04-20 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 09:59:42 --> CSRF cookie sent
INFO - 2020-04-20 09:59:42 --> Input Class Initialized
INFO - 2020-04-20 09:59:42 --> Language Class Initialized
INFO - 2020-04-20 09:59:42 --> Language Class Initialized
INFO - 2020-04-20 09:59:42 --> Config Class Initialized
INFO - 2020-04-20 09:59:42 --> Loader Class Initialized
INFO - 2020-04-20 09:59:42 --> Helper loaded: url_helper
INFO - 2020-04-20 09:59:42 --> Helper loaded: file_helper
INFO - 2020-04-20 09:59:42 --> Helper loaded: cookie_helper
INFO - 2020-04-20 09:59:43 --> Helper loaded: common_helper
INFO - 2020-04-20 09:59:43 --> Helper loaded: language_helper
INFO - 2020-04-20 09:59:43 --> Helper loaded: email_helper
INFO - 2020-04-20 09:59:43 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 09:59:43 --> Database Driver Class Initialized
INFO - 2020-04-20 09:59:43 --> Parser Class Initialized
INFO - 2020-04-20 09:59:43 --> User Agent Class Initialized
INFO - 2020-04-20 09:59:43 --> Model Class Initialized
INFO - 2020-04-20 09:59:43 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:43 --> Template Class Initialized
INFO - 2020-04-20 09:59:43 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 09:59:43 --> Email Class Initialized
INFO - 2020-04-20 09:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 09:59:43 --> Pagination Class Initialized
DEBUG - 2020-04-20 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 09:59:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 09:59:43 --> Encryption Class Initialized
INFO - 2020-04-20 09:59:43 --> Controller Class Initialized
DEBUG - 2020-04-20 09:59:43 --> dashboard MX_Controller Initialized
INFO - 2020-04-20 09:59:43 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/dashboard/models/dashboard_model.php
INFO - 2020-04-20 09:59:43 --> Model Class Initialized
INFO - 2020-04-20 09:59:43 --> Helper loaded: inflector_helper
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/dashboard/views/content.php
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/dashboard/views/index.php
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-20 09:59:43 --> blocks MX_Controller Initialized
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-20 09:59:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-20 09:59:43 --> Final output sent to browser
DEBUG - 2020-04-20 09:59:43 --> Total execution time: 0.6280
INFO - 2020-04-20 09:59:46 --> Config Class Initialized
INFO - 2020-04-20 09:59:46 --> Hooks Class Initialized
DEBUG - 2020-04-20 09:59:46 --> UTF-8 Support Enabled
INFO - 2020-04-20 09:59:46 --> Utf8 Class Initialized
INFO - 2020-04-20 09:59:46 --> URI Class Initialized
INFO - 2020-04-20 09:59:46 --> Router Class Initialized
INFO - 2020-04-20 09:59:46 --> Output Class Initialized
INFO - 2020-04-20 09:59:46 --> Security Class Initialized
DEBUG - 2020-04-20 09:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 09:59:46 --> CSRF cookie sent
INFO - 2020-04-20 09:59:46 --> Input Class Initialized
INFO - 2020-04-20 09:59:46 --> Language Class Initialized
INFO - 2020-04-20 09:59:46 --> Language Class Initialized
INFO - 2020-04-20 09:59:46 --> Config Class Initialized
INFO - 2020-04-20 09:59:46 --> Loader Class Initialized
INFO - 2020-04-20 09:59:46 --> Helper loaded: url_helper
INFO - 2020-04-20 09:59:46 --> Helper loaded: file_helper
INFO - 2020-04-20 09:59:46 --> Helper loaded: cookie_helper
INFO - 2020-04-20 09:59:46 --> Helper loaded: common_helper
INFO - 2020-04-20 09:59:46 --> Helper loaded: language_helper
INFO - 2020-04-20 09:59:46 --> Helper loaded: email_helper
INFO - 2020-04-20 09:59:46 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 09:59:46 --> Database Driver Class Initialized
INFO - 2020-04-20 09:59:46 --> Parser Class Initialized
INFO - 2020-04-20 09:59:46 --> User Agent Class Initialized
INFO - 2020-04-20 09:59:46 --> Model Class Initialized
INFO - 2020-04-20 09:59:46 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:46 --> Template Class Initialized
INFO - 2020-04-20 09:59:46 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 09:59:46 --> Email Class Initialized
INFO - 2020-04-20 09:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 09:59:46 --> Pagination Class Initialized
DEBUG - 2020-04-20 09:59:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 09:59:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 09:59:46 --> Encryption Class Initialized
INFO - 2020-04-20 09:59:46 --> Controller Class Initialized
DEBUG - 2020-04-20 09:59:46 --> follow MX_Controller Initialized
INFO - 2020-04-20 09:59:46 --> Model Class Initialized
DEBUG - 2020-04-20 09:59:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/follow/models/follow_model.php
INFO - 2020-04-20 09:59:46 --> Model Class Initialized
INFO - 2020-04-20 09:59:46 --> Helper loaded: inflector_helper
DEBUG - 2020-04-20 09:59:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/follow/views/index.php
DEBUG - 2020-04-20 09:59:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-20 09:59:46 --> blocks MX_Controller Initialized
DEBUG - 2020-04-20 09:59:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-20 09:59:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-20 09:59:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-20 09:59:47 --> Final output sent to browser
DEBUG - 2020-04-20 09:59:47 --> Total execution time: 0.4592
INFO - 2020-04-20 10:18:22 --> Config Class Initialized
INFO - 2020-04-20 10:18:22 --> Config Class Initialized
INFO - 2020-04-20 10:18:22 --> Hooks Class Initialized
INFO - 2020-04-20 10:18:22 --> Hooks Class Initialized
DEBUG - 2020-04-20 10:18:22 --> UTF-8 Support Enabled
DEBUG - 2020-04-20 10:18:22 --> UTF-8 Support Enabled
INFO - 2020-04-20 10:18:22 --> Utf8 Class Initialized
INFO - 2020-04-20 10:18:22 --> Utf8 Class Initialized
INFO - 2020-04-20 10:18:22 --> URI Class Initialized
INFO - 2020-04-20 10:18:22 --> URI Class Initialized
INFO - 2020-04-20 10:18:22 --> Router Class Initialized
INFO - 2020-04-20 10:18:22 --> Router Class Initialized
INFO - 2020-04-20 10:18:22 --> Output Class Initialized
INFO - 2020-04-20 10:18:22 --> Output Class Initialized
INFO - 2020-04-20 10:18:22 --> Security Class Initialized
INFO - 2020-04-20 10:18:22 --> Security Class Initialized
DEBUG - 2020-04-20 10:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-04-20 10:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 10:18:22 --> CSRF cookie sent
INFO - 2020-04-20 10:18:22 --> CSRF cookie sent
INFO - 2020-04-20 10:18:22 --> Input Class Initialized
INFO - 2020-04-20 10:18:22 --> Input Class Initialized
INFO - 2020-04-20 10:18:22 --> Language Class Initialized
INFO - 2020-04-20 10:18:22 --> Language Class Initialized
ERROR - 2020-04-20 10:18:22 --> 404 Page Not Found: /index
ERROR - 2020-04-20 10:18:22 --> 404 Page Not Found: /index
INFO - 2020-04-20 10:29:44 --> Config Class Initialized
INFO - 2020-04-20 10:29:44 --> Hooks Class Initialized
DEBUG - 2020-04-20 10:29:44 --> UTF-8 Support Enabled
INFO - 2020-04-20 10:29:44 --> Utf8 Class Initialized
INFO - 2020-04-20 10:29:44 --> URI Class Initialized
INFO - 2020-04-20 10:29:44 --> Router Class Initialized
INFO - 2020-04-20 10:29:44 --> Output Class Initialized
INFO - 2020-04-20 10:29:44 --> Security Class Initialized
DEBUG - 2020-04-20 10:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 10:29:44 --> CSRF cookie sent
INFO - 2020-04-20 10:29:44 --> Input Class Initialized
INFO - 2020-04-20 10:29:44 --> Language Class Initialized
INFO - 2020-04-20 10:29:44 --> Language Class Initialized
INFO - 2020-04-20 10:29:44 --> Config Class Initialized
INFO - 2020-04-20 10:29:44 --> Loader Class Initialized
INFO - 2020-04-20 10:29:44 --> Helper loaded: url_helper
INFO - 2020-04-20 10:29:44 --> Helper loaded: file_helper
INFO - 2020-04-20 10:29:44 --> Helper loaded: cookie_helper
INFO - 2020-04-20 10:29:44 --> Helper loaded: common_helper
INFO - 2020-04-20 10:29:44 --> Helper loaded: language_helper
INFO - 2020-04-20 10:29:44 --> Helper loaded: email_helper
INFO - 2020-04-20 10:29:44 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 10:29:44 --> Database Driver Class Initialized
INFO - 2020-04-20 10:29:44 --> Parser Class Initialized
INFO - 2020-04-20 10:29:44 --> User Agent Class Initialized
INFO - 2020-04-20 10:29:44 --> Model Class Initialized
INFO - 2020-04-20 10:29:44 --> Model Class Initialized
DEBUG - 2020-04-20 10:29:44 --> Template Class Initialized
INFO - 2020-04-20 10:29:44 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 10:29:44 --> Email Class Initialized
INFO - 2020-04-20 10:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 10:29:44 --> Pagination Class Initialized
DEBUG - 2020-04-20 10:29:44 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 10:29:44 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 10:29:44 --> Encryption Class Initialized
INFO - 2020-04-20 10:29:44 --> Controller Class Initialized
DEBUG - 2020-04-20 10:29:44 --> search MX_Controller Initialized
INFO - 2020-04-20 10:29:44 --> Model Class Initialized
INFO - 2020-04-20 10:29:44 --> Helper loaded: inflector_helper
DEBUG - 2020-04-20 10:29:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/search/views/index.php
DEBUG - 2020-04-20 10:29:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2020-04-20 10:29:44 --> blocks MX_Controller Initialized
DEBUG - 2020-04-20 10:29:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/header.php
DEBUG - 2020-04-20 10:29:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\modules/blocks/views/sidebar.php
DEBUG - 2020-04-20 10:29:44 --> File loaded: D:\xampp\htdocs\projects\tuyen\twitter\demo\verify\app\views/layouts/template.php
INFO - 2020-04-20 10:29:44 --> Final output sent to browser
DEBUG - 2020-04-20 10:29:44 --> Total execution time: 0.4970
INFO - 2020-04-20 10:29:45 --> Config Class Initialized
INFO - 2020-04-20 10:29:45 --> Hooks Class Initialized
DEBUG - 2020-04-20 10:29:45 --> UTF-8 Support Enabled
INFO - 2020-04-20 10:29:45 --> Utf8 Class Initialized
INFO - 2020-04-20 10:29:45 --> URI Class Initialized
INFO - 2020-04-20 10:29:45 --> Router Class Initialized
INFO - 2020-04-20 10:29:45 --> Output Class Initialized
INFO - 2020-04-20 10:29:45 --> Security Class Initialized
DEBUG - 2020-04-20 10:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 10:29:45 --> CSRF cookie sent
INFO - 2020-04-20 10:29:45 --> Input Class Initialized
INFO - 2020-04-20 10:29:45 --> Config Class Initialized
INFO - 2020-04-20 10:29:45 --> Hooks Class Initialized
INFO - 2020-04-20 10:29:45 --> Language Class Initialized
ERROR - 2020-04-20 10:29:45 --> 404 Page Not Found: /index
DEBUG - 2020-04-20 10:29:45 --> UTF-8 Support Enabled
INFO - 2020-04-20 10:29:45 --> Utf8 Class Initialized
INFO - 2020-04-20 10:29:45 --> URI Class Initialized
INFO - 2020-04-20 10:29:45 --> Router Class Initialized
INFO - 2020-04-20 10:29:45 --> Output Class Initialized
INFO - 2020-04-20 10:29:45 --> Security Class Initialized
DEBUG - 2020-04-20 10:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 10:29:45 --> CSRF cookie sent
INFO - 2020-04-20 10:29:45 --> Input Class Initialized
INFO - 2020-04-20 10:29:45 --> Language Class Initialized
ERROR - 2020-04-20 10:29:45 --> 404 Page Not Found: /index
INFO - 2020-04-20 10:29:45 --> Config Class Initialized
INFO - 2020-04-20 10:29:45 --> Hooks Class Initialized
DEBUG - 2020-04-20 10:29:45 --> UTF-8 Support Enabled
INFO - 2020-04-20 10:29:45 --> Utf8 Class Initialized
INFO - 2020-04-20 10:29:45 --> URI Class Initialized
INFO - 2020-04-20 10:29:45 --> Router Class Initialized
INFO - 2020-04-20 10:29:45 --> Output Class Initialized
INFO - 2020-04-20 10:29:45 --> Security Class Initialized
DEBUG - 2020-04-20 10:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 10:29:45 --> CSRF cookie sent
INFO - 2020-04-20 10:29:46 --> Input Class Initialized
INFO - 2020-04-20 10:29:46 --> Language Class Initialized
ERROR - 2020-04-20 10:29:46 --> 404 Page Not Found: /index
INFO - 2020-04-20 10:30:25 --> Config Class Initialized
INFO - 2020-04-20 10:30:25 --> Hooks Class Initialized
DEBUG - 2020-04-20 10:30:25 --> UTF-8 Support Enabled
INFO - 2020-04-20 10:30:25 --> Utf8 Class Initialized
INFO - 2020-04-20 10:30:25 --> URI Class Initialized
INFO - 2020-04-20 10:30:25 --> Router Class Initialized
INFO - 2020-04-20 10:30:25 --> Output Class Initialized
INFO - 2020-04-20 10:30:25 --> Security Class Initialized
DEBUG - 2020-04-20 10:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-20 10:30:25 --> CSRF cookie sent
INFO - 2020-04-20 10:30:25 --> CSRF token verified
INFO - 2020-04-20 10:30:25 --> Input Class Initialized
INFO - 2020-04-20 10:30:25 --> Language Class Initialized
INFO - 2020-04-20 10:30:25 --> Language Class Initialized
INFO - 2020-04-20 10:30:25 --> Config Class Initialized
INFO - 2020-04-20 10:30:25 --> Loader Class Initialized
INFO - 2020-04-20 10:30:25 --> Helper loaded: url_helper
INFO - 2020-04-20 10:30:25 --> Helper loaded: file_helper
INFO - 2020-04-20 10:30:25 --> Helper loaded: cookie_helper
INFO - 2020-04-20 10:30:25 --> Helper loaded: common_helper
INFO - 2020-04-20 10:30:25 --> Helper loaded: language_helper
INFO - 2020-04-20 10:30:25 --> Helper loaded: email_helper
INFO - 2020-04-20 10:30:25 --> Language file loaded: language/english/common_lang.php
INFO - 2020-04-20 10:30:25 --> Database Driver Class Initialized
INFO - 2020-04-20 10:30:25 --> Parser Class Initialized
INFO - 2020-04-20 10:30:26 --> User Agent Class Initialized
INFO - 2020-04-20 10:30:26 --> Model Class Initialized
INFO - 2020-04-20 10:30:26 --> Model Class Initialized
DEBUG - 2020-04-20 10:30:26 --> Template Class Initialized
INFO - 2020-04-20 10:30:26 --> Session: Class initialized using 'database' driver.
INFO - 2020-04-20 10:30:26 --> Email Class Initialized
INFO - 2020-04-20 10:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2020-04-20 10:30:26 --> Pagination Class Initialized
DEBUG - 2020-04-20 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2020-04-20 10:30:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2020-04-20 10:30:26 --> Encryption Class Initialized
INFO - 2020-04-20 10:30:26 --> Controller Class Initialized
DEBUG - 2020-04-20 10:30:26 --> search MX_Controller Initialized
INFO - 2020-04-20 10:30:26 --> Model Class Initialized
