<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-20 12:01:10 --> Config Class Initialized
INFO - 2019-11-20 12:01:10 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:01:10 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:01:10 --> Utf8 Class Initialized
INFO - 2019-11-20 12:01:10 --> URI Class Initialized
DEBUG - 2019-11-20 12:01:10 --> No URI present. Default controller set.
INFO - 2019-11-20 12:01:10 --> Router Class Initialized
INFO - 2019-11-20 12:01:10 --> Output Class Initialized
INFO - 2019-11-20 12:01:10 --> Security Class Initialized
DEBUG - 2019-11-20 12:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:01:10 --> CSRF cookie sent
INFO - 2019-11-20 12:01:10 --> Input Class Initialized
INFO - 2019-11-20 12:01:10 --> Language Class Initialized
INFO - 2019-11-20 12:01:10 --> Language Class Initialized
INFO - 2019-11-20 12:01:10 --> Config Class Initialized
INFO - 2019-11-20 12:01:10 --> Loader Class Initialized
INFO - 2019-11-20 12:01:10 --> Helper loaded: url_helper
INFO - 2019-11-20 12:01:10 --> Helper loaded: common_helper
INFO - 2019-11-20 12:01:10 --> Helper loaded: language_helper
INFO - 2019-11-20 12:01:10 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:01:10 --> Helper loaded: email_helper
INFO - 2019-11-20 12:01:10 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:01:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:01:10 --> Parser Class Initialized
INFO - 2019-11-20 12:01:10 --> User Agent Class Initialized
INFO - 2019-11-20 12:01:10 --> Model Class Initialized
INFO - 2019-11-20 12:01:11 --> Database Driver Class Initialized
INFO - 2019-11-20 12:01:11 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:11 --> Template Class Initialized
INFO - 2019-11-20 12:01:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:01:11 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:01:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:01:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:01:11 --> Encryption Class Initialized
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-20 12:01:11 --> Controller Class Initialized
DEBUG - 2019-11-20 12:01:11 --> pergo MX_Controller Initialized
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-20 12:01:11 --> Model Class Initialized
INFO - 2019-11-20 12:01:11 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-20 12:01:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-20 12:01:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-20 12:01:12 --> Final output sent to browser
DEBUG - 2019-11-20 12:01:12 --> Total execution time: 1.7503
INFO - 2019-11-20 12:01:15 --> Config Class Initialized
INFO - 2019-11-20 12:01:15 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:01:15 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:01:15 --> Utf8 Class Initialized
INFO - 2019-11-20 12:01:15 --> URI Class Initialized
INFO - 2019-11-20 12:01:15 --> Router Class Initialized
INFO - 2019-11-20 12:01:15 --> Output Class Initialized
INFO - 2019-11-20 12:01:15 --> Security Class Initialized
DEBUG - 2019-11-20 12:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:01:15 --> CSRF cookie sent
INFO - 2019-11-20 12:01:15 --> Input Class Initialized
INFO - 2019-11-20 12:01:15 --> Language Class Initialized
INFO - 2019-11-20 12:01:16 --> Language Class Initialized
INFO - 2019-11-20 12:01:16 --> Config Class Initialized
INFO - 2019-11-20 12:01:16 --> Loader Class Initialized
INFO - 2019-11-20 12:01:16 --> Helper loaded: url_helper
INFO - 2019-11-20 12:01:16 --> Helper loaded: common_helper
INFO - 2019-11-20 12:01:16 --> Helper loaded: language_helper
INFO - 2019-11-20 12:01:16 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:01:16 --> Helper loaded: email_helper
INFO - 2019-11-20 12:01:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:01:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:01:16 --> Parser Class Initialized
INFO - 2019-11-20 12:01:16 --> User Agent Class Initialized
INFO - 2019-11-20 12:01:16 --> Model Class Initialized
INFO - 2019-11-20 12:01:16 --> Database Driver Class Initialized
INFO - 2019-11-20 12:01:16 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:16 --> Template Class Initialized
INFO - 2019-11-20 12:01:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:01:16 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:01:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:01:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:01:16 --> Encryption Class Initialized
INFO - 2019-11-20 12:01:16 --> Controller Class Initialized
DEBUG - 2019-11-20 12:01:16 --> auth MX_Controller Initialized
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-20 12:01:16 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../language/english/../../../themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-20 12:01:16 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../../themes/pergo/controllers/pergo.php
DEBUG - 2019-11-20 12:01:16 --> pergo MX_Controller Initialized
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/../views/../../themes/pergo/views/sign_in.php
DEBUG - 2019-11-20 12:01:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-20 12:01:16 --> Final output sent to browser
DEBUG - 2019-11-20 12:01:16 --> Total execution time: 0.7773
INFO - 2019-11-20 12:01:18 --> Config Class Initialized
INFO - 2019-11-20 12:01:18 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:01:18 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:01:18 --> Utf8 Class Initialized
INFO - 2019-11-20 12:01:18 --> URI Class Initialized
INFO - 2019-11-20 12:01:18 --> Router Class Initialized
INFO - 2019-11-20 12:01:18 --> Output Class Initialized
INFO - 2019-11-20 12:01:18 --> Security Class Initialized
DEBUG - 2019-11-20 12:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:01:18 --> CSRF cookie sent
INFO - 2019-11-20 12:01:18 --> CSRF token verified
INFO - 2019-11-20 12:01:18 --> Input Class Initialized
INFO - 2019-11-20 12:01:18 --> Language Class Initialized
INFO - 2019-11-20 12:01:18 --> Language Class Initialized
INFO - 2019-11-20 12:01:18 --> Config Class Initialized
INFO - 2019-11-20 12:01:18 --> Loader Class Initialized
INFO - 2019-11-20 12:01:18 --> Helper loaded: url_helper
INFO - 2019-11-20 12:01:18 --> Helper loaded: common_helper
INFO - 2019-11-20 12:01:18 --> Helper loaded: language_helper
INFO - 2019-11-20 12:01:18 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:01:18 --> Helper loaded: email_helper
INFO - 2019-11-20 12:01:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:01:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:01:18 --> Parser Class Initialized
INFO - 2019-11-20 12:01:18 --> User Agent Class Initialized
INFO - 2019-11-20 12:01:18 --> Model Class Initialized
INFO - 2019-11-20 12:01:18 --> Database Driver Class Initialized
INFO - 2019-11-20 12:01:18 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:18 --> Template Class Initialized
INFO - 2019-11-20 12:01:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:01:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:01:18 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:01:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:01:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:01:18 --> Encryption Class Initialized
INFO - 2019-11-20 12:01:18 --> Controller Class Initialized
DEBUG - 2019-11-20 12:01:18 --> auth MX_Controller Initialized
DEBUG - 2019-11-20 12:01:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-20 12:01:18 --> Model Class Initialized
INFO - 2019-11-20 12:01:24 --> Config Class Initialized
INFO - 2019-11-20 12:01:24 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:01:24 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:01:24 --> Utf8 Class Initialized
INFO - 2019-11-20 12:01:24 --> URI Class Initialized
INFO - 2019-11-20 12:01:24 --> Router Class Initialized
INFO - 2019-11-20 12:01:24 --> Output Class Initialized
INFO - 2019-11-20 12:01:24 --> Security Class Initialized
DEBUG - 2019-11-20 12:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:01:24 --> CSRF cookie sent
INFO - 2019-11-20 12:01:24 --> Input Class Initialized
INFO - 2019-11-20 12:01:24 --> Language Class Initialized
INFO - 2019-11-20 12:01:24 --> Language Class Initialized
INFO - 2019-11-20 12:01:24 --> Config Class Initialized
INFO - 2019-11-20 12:01:24 --> Loader Class Initialized
INFO - 2019-11-20 12:01:24 --> Helper loaded: url_helper
INFO - 2019-11-20 12:01:24 --> Helper loaded: common_helper
INFO - 2019-11-20 12:01:24 --> Helper loaded: language_helper
INFO - 2019-11-20 12:01:24 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:01:24 --> Helper loaded: email_helper
INFO - 2019-11-20 12:01:24 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:01:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:01:24 --> Parser Class Initialized
INFO - 2019-11-20 12:01:24 --> User Agent Class Initialized
INFO - 2019-11-20 12:01:24 --> Model Class Initialized
INFO - 2019-11-20 12:01:24 --> Database Driver Class Initialized
INFO - 2019-11-20 12:01:24 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:24 --> Template Class Initialized
INFO - 2019-11-20 12:01:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:01:24 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:01:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:01:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:01:24 --> Encryption Class Initialized
INFO - 2019-11-20 12:01:24 --> Controller Class Initialized
DEBUG - 2019-11-20 12:01:24 --> statistics MX_Controller Initialized
DEBUG - 2019-11-20 12:01:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-20 12:01:24 --> Model Class Initialized
ERROR - 2019-11-20 12:01:24 --> Could not find the language line "Pending"
ERROR - 2019-11-20 12:01:24 --> Could not find the language line "Pending"
INFO - 2019-11-20 12:01:24 --> Helper loaded: inflector_helper
ERROR - 2019-11-20 12:01:25 --> Could not find the language line "total_orders"
ERROR - 2019-11-20 12:01:25 --> Could not find the language line "total_orders"
ERROR - 2019-11-20 12:01:25 --> Could not find the language line "Pending"
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 12:01:25 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 12:01:25 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 12:01:25 --> Model Class Initialized
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 12:01:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 12:01:25 --> Final output sent to browser
DEBUG - 2019-11-20 12:01:25 --> Total execution time: 1.2177
INFO - 2019-11-20 12:02:08 --> Config Class Initialized
INFO - 2019-11-20 12:02:08 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:02:08 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:02:08 --> Utf8 Class Initialized
INFO - 2019-11-20 12:02:08 --> URI Class Initialized
INFO - 2019-11-20 12:02:08 --> Router Class Initialized
INFO - 2019-11-20 12:02:08 --> Output Class Initialized
INFO - 2019-11-20 12:02:08 --> Security Class Initialized
DEBUG - 2019-11-20 12:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:02:08 --> CSRF cookie sent
INFO - 2019-11-20 12:02:08 --> Input Class Initialized
INFO - 2019-11-20 12:02:08 --> Language Class Initialized
INFO - 2019-11-20 12:02:08 --> Language Class Initialized
INFO - 2019-11-20 12:02:08 --> Config Class Initialized
INFO - 2019-11-20 12:02:08 --> Loader Class Initialized
INFO - 2019-11-20 12:02:08 --> Helper loaded: url_helper
INFO - 2019-11-20 12:02:08 --> Helper loaded: common_helper
INFO - 2019-11-20 12:02:08 --> Helper loaded: language_helper
INFO - 2019-11-20 12:02:08 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:02:08 --> Helper loaded: email_helper
INFO - 2019-11-20 12:02:08 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:02:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:02:08 --> Parser Class Initialized
INFO - 2019-11-20 12:02:08 --> User Agent Class Initialized
INFO - 2019-11-20 12:02:08 --> Model Class Initialized
INFO - 2019-11-20 12:02:08 --> Database Driver Class Initialized
INFO - 2019-11-20 12:02:08 --> Model Class Initialized
DEBUG - 2019-11-20 12:02:08 --> Template Class Initialized
INFO - 2019-11-20 12:02:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:02:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:02:08 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:02:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:02:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:02:09 --> Encryption Class Initialized
INFO - 2019-11-20 12:02:09 --> Controller Class Initialized
DEBUG - 2019-11-20 12:02:09 --> provider MX_Controller Initialized
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-11-20 12:02:09 --> Model Class Initialized
ERROR - 2019-11-20 12:02:09 --> Could not find the language line "Balance"
INFO - 2019-11-20 12:02:09 --> Helper loaded: inflector_helper
ERROR - 2019-11-20 12:02:09 --> Could not find the language line "api_providers"
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/views/index.php
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 12:02:09 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 12:02:09 --> Model Class Initialized
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 12:02:09 --> Model Class Initialized
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 12:02:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 12:02:09 --> Final output sent to browser
DEBUG - 2019-11-20 12:02:09 --> Total execution time: 0.9262
INFO - 2019-11-20 12:02:11 --> Config Class Initialized
INFO - 2019-11-20 12:02:11 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:02:11 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:02:11 --> Utf8 Class Initialized
INFO - 2019-11-20 12:02:11 --> URI Class Initialized
INFO - 2019-11-20 12:02:11 --> Router Class Initialized
INFO - 2019-11-20 12:02:11 --> Output Class Initialized
INFO - 2019-11-20 12:02:11 --> Security Class Initialized
DEBUG - 2019-11-20 12:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:02:11 --> CSRF cookie sent
INFO - 2019-11-20 12:02:11 --> Input Class Initialized
INFO - 2019-11-20 12:02:11 --> Language Class Initialized
INFO - 2019-11-20 12:02:11 --> Language Class Initialized
INFO - 2019-11-20 12:02:11 --> Config Class Initialized
INFO - 2019-11-20 12:02:11 --> Loader Class Initialized
INFO - 2019-11-20 12:02:11 --> Helper loaded: url_helper
INFO - 2019-11-20 12:02:11 --> Helper loaded: common_helper
INFO - 2019-11-20 12:02:11 --> Helper loaded: language_helper
INFO - 2019-11-20 12:02:11 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:02:11 --> Helper loaded: email_helper
INFO - 2019-11-20 12:02:11 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:02:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:02:11 --> Parser Class Initialized
INFO - 2019-11-20 12:02:12 --> User Agent Class Initialized
INFO - 2019-11-20 12:02:12 --> Model Class Initialized
INFO - 2019-11-20 12:02:12 --> Database Driver Class Initialized
INFO - 2019-11-20 12:02:12 --> Model Class Initialized
DEBUG - 2019-11-20 12:02:12 --> Template Class Initialized
INFO - 2019-11-20 12:02:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:02:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:02:12 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:02:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:02:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:02:12 --> Encryption Class Initialized
INFO - 2019-11-20 12:02:12 --> Controller Class Initialized
DEBUG - 2019-11-20 12:02:12 --> provider MX_Controller Initialized
DEBUG - 2019-11-20 12:02:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-11-20 12:02:12 --> Model Class Initialized
ERROR - 2019-11-20 12:02:12 --> Could not find the language line "Balance"
DEBUG - 2019-11-20 12:02:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/views/update.php
INFO - 2019-11-20 12:02:12 --> Final output sent to browser
DEBUG - 2019-11-20 12:02:12 --> Total execution time: 0.4070
INFO - 2019-11-20 12:02:40 --> Config Class Initialized
INFO - 2019-11-20 12:02:40 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:02:40 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:02:40 --> Utf8 Class Initialized
INFO - 2019-11-20 12:02:40 --> URI Class Initialized
INFO - 2019-11-20 12:02:40 --> Router Class Initialized
INFO - 2019-11-20 12:02:40 --> Output Class Initialized
INFO - 2019-11-20 12:02:40 --> Security Class Initialized
DEBUG - 2019-11-20 12:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:02:40 --> CSRF cookie sent
INFO - 2019-11-20 12:02:40 --> CSRF token verified
INFO - 2019-11-20 12:02:40 --> Input Class Initialized
INFO - 2019-11-20 12:02:40 --> Language Class Initialized
INFO - 2019-11-20 12:02:40 --> Language Class Initialized
INFO - 2019-11-20 12:02:40 --> Config Class Initialized
INFO - 2019-11-20 12:02:40 --> Loader Class Initialized
INFO - 2019-11-20 12:02:40 --> Helper loaded: url_helper
INFO - 2019-11-20 12:02:40 --> Helper loaded: common_helper
INFO - 2019-11-20 12:02:40 --> Helper loaded: language_helper
INFO - 2019-11-20 12:02:40 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:02:40 --> Helper loaded: email_helper
INFO - 2019-11-20 12:02:40 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:02:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:02:40 --> Parser Class Initialized
INFO - 2019-11-20 12:02:40 --> User Agent Class Initialized
INFO - 2019-11-20 12:02:40 --> Model Class Initialized
INFO - 2019-11-20 12:02:40 --> Database Driver Class Initialized
INFO - 2019-11-20 12:02:40 --> Model Class Initialized
DEBUG - 2019-11-20 12:02:40 --> Template Class Initialized
INFO - 2019-11-20 12:02:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:02:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:02:40 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:02:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:02:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:02:40 --> Encryption Class Initialized
INFO - 2019-11-20 12:02:40 --> Controller Class Initialized
DEBUG - 2019-11-20 12:02:40 --> provider MX_Controller Initialized
DEBUG - 2019-11-20 12:02:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-11-20 12:02:40 --> Model Class Initialized
ERROR - 2019-11-20 12:02:40 --> Could not find the language line "Balance"
INFO - 2019-11-20 12:03:57 --> Config Class Initialized
INFO - 2019-11-20 12:03:57 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:03:57 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:03:57 --> Utf8 Class Initialized
INFO - 2019-11-20 12:03:57 --> URI Class Initialized
INFO - 2019-11-20 12:03:57 --> Router Class Initialized
INFO - 2019-11-20 12:03:57 --> Output Class Initialized
INFO - 2019-11-20 12:03:57 --> Security Class Initialized
DEBUG - 2019-11-20 12:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:03:57 --> CSRF cookie sent
INFO - 2019-11-20 12:03:57 --> CSRF token verified
INFO - 2019-11-20 12:03:57 --> Input Class Initialized
INFO - 2019-11-20 12:03:57 --> Language Class Initialized
INFO - 2019-11-20 12:03:57 --> Language Class Initialized
INFO - 2019-11-20 12:03:57 --> Config Class Initialized
INFO - 2019-11-20 12:03:57 --> Loader Class Initialized
INFO - 2019-11-20 12:03:57 --> Helper loaded: url_helper
INFO - 2019-11-20 12:03:57 --> Helper loaded: common_helper
INFO - 2019-11-20 12:03:57 --> Helper loaded: language_helper
INFO - 2019-11-20 12:03:57 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:03:57 --> Helper loaded: email_helper
INFO - 2019-11-20 12:03:57 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:03:57 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:03:57 --> Parser Class Initialized
INFO - 2019-11-20 12:03:57 --> User Agent Class Initialized
INFO - 2019-11-20 12:03:57 --> Model Class Initialized
INFO - 2019-11-20 12:03:57 --> Database Driver Class Initialized
INFO - 2019-11-20 12:03:57 --> Model Class Initialized
DEBUG - 2019-11-20 12:03:57 --> Template Class Initialized
INFO - 2019-11-20 12:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:03:57 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:03:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:03:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:03:57 --> Encryption Class Initialized
INFO - 2019-11-20 12:03:57 --> Controller Class Initialized
DEBUG - 2019-11-20 12:03:57 --> provider MX_Controller Initialized
DEBUG - 2019-11-20 12:03:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-11-20 12:03:57 --> Model Class Initialized
ERROR - 2019-11-20 12:03:57 --> Could not find the language line "Balance"
INFO - 2019-11-20 12:04:03 --> Config Class Initialized
INFO - 2019-11-20 12:04:03 --> Hooks Class Initialized
DEBUG - 2019-11-20 12:04:03 --> UTF-8 Support Enabled
INFO - 2019-11-20 12:04:03 --> Utf8 Class Initialized
INFO - 2019-11-20 12:04:03 --> URI Class Initialized
INFO - 2019-11-20 12:04:03 --> Router Class Initialized
INFO - 2019-11-20 12:04:03 --> Output Class Initialized
INFO - 2019-11-20 12:04:03 --> Security Class Initialized
DEBUG - 2019-11-20 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 12:04:03 --> CSRF cookie sent
INFO - 2019-11-20 12:04:03 --> Input Class Initialized
INFO - 2019-11-20 12:04:03 --> Language Class Initialized
INFO - 2019-11-20 12:04:03 --> Language Class Initialized
INFO - 2019-11-20 12:04:03 --> Config Class Initialized
INFO - 2019-11-20 12:04:03 --> Loader Class Initialized
INFO - 2019-11-20 12:04:03 --> Helper loaded: url_helper
INFO - 2019-11-20 12:04:03 --> Helper loaded: common_helper
INFO - 2019-11-20 12:04:03 --> Helper loaded: language_helper
INFO - 2019-11-20 12:04:03 --> Helper loaded: cookie_helper
INFO - 2019-11-20 12:04:03 --> Helper loaded: email_helper
INFO - 2019-11-20 12:04:03 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 12:04:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 12:04:03 --> Parser Class Initialized
INFO - 2019-11-20 12:04:03 --> User Agent Class Initialized
INFO - 2019-11-20 12:04:03 --> Model Class Initialized
INFO - 2019-11-20 12:04:03 --> Database Driver Class Initialized
INFO - 2019-11-20 12:04:03 --> Model Class Initialized
DEBUG - 2019-11-20 12:04:03 --> Template Class Initialized
INFO - 2019-11-20 12:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 12:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 12:04:03 --> Pagination Class Initialized
DEBUG - 2019-11-20 12:04:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 12:04:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 12:04:03 --> Encryption Class Initialized
INFO - 2019-11-20 12:04:03 --> Controller Class Initialized
DEBUG - 2019-11-20 12:04:03 --> provider MX_Controller Initialized
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/models/provider_model.php
INFO - 2019-11-20 12:04:03 --> Model Class Initialized
ERROR - 2019-11-20 12:04:03 --> Could not find the language line "Balance"
INFO - 2019-11-20 12:04:03 --> Helper loaded: inflector_helper
ERROR - 2019-11-20 12:04:03 --> Could not find the language line "api_providers"
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/provider/views/index.php
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 12:04:03 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 12:04:03 --> Model Class Initialized
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 12:04:03 --> Model Class Initialized
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 12:04:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 12:04:03 --> Final output sent to browser
DEBUG - 2019-11-20 12:04:04 --> Total execution time: 0.9210
INFO - 2019-11-20 15:06:37 --> Config Class Initialized
INFO - 2019-11-20 15:06:37 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:06:37 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:06:37 --> Utf8 Class Initialized
INFO - 2019-11-20 15:06:37 --> URI Class Initialized
DEBUG - 2019-11-20 15:06:37 --> No URI present. Default controller set.
INFO - 2019-11-20 15:06:37 --> Router Class Initialized
INFO - 2019-11-20 15:06:37 --> Output Class Initialized
INFO - 2019-11-20 15:06:37 --> Security Class Initialized
DEBUG - 2019-11-20 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:06:37 --> CSRF cookie sent
INFO - 2019-11-20 15:06:37 --> Input Class Initialized
INFO - 2019-11-20 15:06:37 --> Language Class Initialized
INFO - 2019-11-20 15:06:37 --> Language Class Initialized
INFO - 2019-11-20 15:06:37 --> Config Class Initialized
INFO - 2019-11-20 15:06:37 --> Loader Class Initialized
INFO - 2019-11-20 15:06:37 --> Helper loaded: url_helper
INFO - 2019-11-20 15:06:37 --> Helper loaded: common_helper
INFO - 2019-11-20 15:06:37 --> Helper loaded: language_helper
INFO - 2019-11-20 15:06:37 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:06:37 --> Helper loaded: email_helper
INFO - 2019-11-20 15:06:37 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:06:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:06:38 --> Parser Class Initialized
INFO - 2019-11-20 15:06:38 --> User Agent Class Initialized
INFO - 2019-11-20 15:06:38 --> Model Class Initialized
INFO - 2019-11-20 15:06:38 --> Database Driver Class Initialized
INFO - 2019-11-20 15:06:38 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:38 --> Template Class Initialized
INFO - 2019-11-20 15:06:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:06:38 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:06:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:06:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:06:38 --> Encryption Class Initialized
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-20 15:06:38 --> Controller Class Initialized
DEBUG - 2019-11-20 15:06:38 --> pergo MX_Controller Initialized
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-20 15:06:38 --> Model Class Initialized
INFO - 2019-11-20 15:06:38 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-20 15:06:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-20 15:06:38 --> Final output sent to browser
DEBUG - 2019-11-20 15:06:38 --> Total execution time: 1.3429
INFO - 2019-11-20 15:06:41 --> Config Class Initialized
INFO - 2019-11-20 15:06:41 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:06:41 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:06:41 --> Utf8 Class Initialized
INFO - 2019-11-20 15:06:41 --> URI Class Initialized
INFO - 2019-11-20 15:06:41 --> Router Class Initialized
INFO - 2019-11-20 15:06:41 --> Output Class Initialized
INFO - 2019-11-20 15:06:41 --> Security Class Initialized
DEBUG - 2019-11-20 15:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:06:41 --> CSRF cookie sent
INFO - 2019-11-20 15:06:41 --> Input Class Initialized
INFO - 2019-11-20 15:06:41 --> Language Class Initialized
INFO - 2019-11-20 15:06:41 --> Language Class Initialized
INFO - 2019-11-20 15:06:41 --> Config Class Initialized
INFO - 2019-11-20 15:06:41 --> Loader Class Initialized
INFO - 2019-11-20 15:06:42 --> Helper loaded: url_helper
INFO - 2019-11-20 15:06:42 --> Helper loaded: common_helper
INFO - 2019-11-20 15:06:42 --> Helper loaded: language_helper
INFO - 2019-11-20 15:06:42 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:06:42 --> Helper loaded: email_helper
INFO - 2019-11-20 15:06:42 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:06:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:06:42 --> Parser Class Initialized
INFO - 2019-11-20 15:06:42 --> User Agent Class Initialized
INFO - 2019-11-20 15:06:42 --> Model Class Initialized
INFO - 2019-11-20 15:06:42 --> Database Driver Class Initialized
INFO - 2019-11-20 15:06:42 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:42 --> Template Class Initialized
INFO - 2019-11-20 15:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:06:42 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:06:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:06:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:06:42 --> Encryption Class Initialized
INFO - 2019-11-20 15:06:42 --> Controller Class Initialized
DEBUG - 2019-11-20 15:06:42 --> package MX_Controller Initialized
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-11-20 15:06:42 --> Model Class Initialized
INFO - 2019-11-20 15:06:42 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 15:06:42 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 15:06:42 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 15:06:42 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-20 15:06:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-20 15:06:42 --> Final output sent to browser
DEBUG - 2019-11-20 15:06:42 --> Total execution time: 1.1850
INFO - 2019-11-20 15:06:45 --> Config Class Initialized
INFO - 2019-11-20 15:06:45 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:06:45 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:06:45 --> Utf8 Class Initialized
INFO - 2019-11-20 15:06:45 --> URI Class Initialized
INFO - 2019-11-20 15:06:45 --> Router Class Initialized
INFO - 2019-11-20 15:06:45 --> Output Class Initialized
INFO - 2019-11-20 15:06:45 --> Security Class Initialized
DEBUG - 2019-11-20 15:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:06:46 --> CSRF cookie sent
INFO - 2019-11-20 15:06:46 --> CSRF token verified
INFO - 2019-11-20 15:06:46 --> Input Class Initialized
INFO - 2019-11-20 15:06:46 --> Language Class Initialized
INFO - 2019-11-20 15:06:46 --> Language Class Initialized
INFO - 2019-11-20 15:06:46 --> Config Class Initialized
INFO - 2019-11-20 15:06:46 --> Loader Class Initialized
INFO - 2019-11-20 15:06:46 --> Helper loaded: url_helper
INFO - 2019-11-20 15:06:46 --> Helper loaded: common_helper
INFO - 2019-11-20 15:06:46 --> Helper loaded: language_helper
INFO - 2019-11-20 15:06:46 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:06:46 --> Helper loaded: email_helper
INFO - 2019-11-20 15:06:46 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:06:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:06:46 --> Parser Class Initialized
INFO - 2019-11-20 15:06:46 --> User Agent Class Initialized
INFO - 2019-11-20 15:06:46 --> Model Class Initialized
INFO - 2019-11-20 15:06:46 --> Database Driver Class Initialized
INFO - 2019-11-20 15:06:46 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:46 --> Template Class Initialized
INFO - 2019-11-20 15:06:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:06:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:06:46 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:06:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:06:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:06:46 --> Encryption Class Initialized
INFO - 2019-11-20 15:06:46 --> Controller Class Initialized
DEBUG - 2019-11-20 15:06:46 --> checkout MX_Controller Initialized
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-20 15:06:46 --> Model Class Initialized
INFO - 2019-11-20 15:06:46 --> Helper loaded: inflector_helper
ERROR - 2019-11-20 15:06:46 --> Could not find the language line "shopier"
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 15:06:46 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 15:06:46 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 15:06:46 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-20 15:06:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-20 15:06:46 --> Final output sent to browser
DEBUG - 2019-11-20 15:06:46 --> Total execution time: 0.7185
INFO - 2019-11-20 15:06:53 --> Config Class Initialized
INFO - 2019-11-20 15:06:53 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:06:53 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:06:53 --> Utf8 Class Initialized
INFO - 2019-11-20 15:06:53 --> URI Class Initialized
INFO - 2019-11-20 15:06:53 --> Router Class Initialized
INFO - 2019-11-20 15:06:53 --> Output Class Initialized
INFO - 2019-11-20 15:06:53 --> Security Class Initialized
DEBUG - 2019-11-20 15:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:06:53 --> CSRF cookie sent
INFO - 2019-11-20 15:06:53 --> CSRF token verified
INFO - 2019-11-20 15:06:53 --> Input Class Initialized
INFO - 2019-11-20 15:06:53 --> Language Class Initialized
INFO - 2019-11-20 15:06:53 --> Language Class Initialized
INFO - 2019-11-20 15:06:53 --> Config Class Initialized
INFO - 2019-11-20 15:06:53 --> Loader Class Initialized
INFO - 2019-11-20 15:06:53 --> Helper loaded: url_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: common_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: language_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: email_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:06:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:06:53 --> Parser Class Initialized
INFO - 2019-11-20 15:06:53 --> User Agent Class Initialized
INFO - 2019-11-20 15:06:53 --> Model Class Initialized
INFO - 2019-11-20 15:06:53 --> Database Driver Class Initialized
INFO - 2019-11-20 15:06:53 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:53 --> Template Class Initialized
INFO - 2019-11-20 15:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:06:53 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:06:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:06:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:06:53 --> Encryption Class Initialized
INFO - 2019-11-20 15:06:53 --> Controller Class Initialized
DEBUG - 2019-11-20 15:06:53 --> checkout MX_Controller Initialized
DEBUG - 2019-11-20 15:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-20 15:06:53 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:53 --> freekassa MX_Controller Initialized
INFO - 2019-11-20 15:06:53 --> Config Class Initialized
INFO - 2019-11-20 15:06:53 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:06:53 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:06:53 --> Utf8 Class Initialized
INFO - 2019-11-20 15:06:53 --> URI Class Initialized
DEBUG - 2019-11-20 15:06:53 --> No URI present. Default controller set.
INFO - 2019-11-20 15:06:53 --> Router Class Initialized
INFO - 2019-11-20 15:06:53 --> Output Class Initialized
INFO - 2019-11-20 15:06:53 --> Security Class Initialized
DEBUG - 2019-11-20 15:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:06:53 --> CSRF cookie sent
INFO - 2019-11-20 15:06:53 --> Input Class Initialized
INFO - 2019-11-20 15:06:53 --> Language Class Initialized
INFO - 2019-11-20 15:06:53 --> Language Class Initialized
INFO - 2019-11-20 15:06:53 --> Config Class Initialized
INFO - 2019-11-20 15:06:53 --> Loader Class Initialized
INFO - 2019-11-20 15:06:53 --> Helper loaded: url_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: common_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: language_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: email_helper
INFO - 2019-11-20 15:06:53 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:06:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:06:53 --> Parser Class Initialized
INFO - 2019-11-20 15:06:53 --> User Agent Class Initialized
INFO - 2019-11-20 15:06:53 --> Model Class Initialized
INFO - 2019-11-20 15:06:53 --> Database Driver Class Initialized
INFO - 2019-11-20 15:06:53 --> Model Class Initialized
DEBUG - 2019-11-20 15:06:53 --> Template Class Initialized
INFO - 2019-11-20 15:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:06:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:06:53 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:06:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:06:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:06:53 --> Encryption Class Initialized
DEBUG - 2019-11-20 15:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 15:06:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-20 15:06:53 --> Controller Class Initialized
DEBUG - 2019-11-20 15:06:53 --> pergo MX_Controller Initialized
DEBUG - 2019-11-20 15:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 15:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-20 15:06:54 --> Model Class Initialized
INFO - 2019-11-20 15:06:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 15:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-20 15:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-20 15:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-20 15:06:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-20 15:06:54 --> Final output sent to browser
DEBUG - 2019-11-20 15:06:54 --> Total execution time: 0.6088
INFO - 2019-11-20 15:11:20 --> Config Class Initialized
INFO - 2019-11-20 15:11:20 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:11:20 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:11:20 --> Utf8 Class Initialized
INFO - 2019-11-20 15:11:20 --> URI Class Initialized
INFO - 2019-11-20 15:11:20 --> Router Class Initialized
INFO - 2019-11-20 15:11:21 --> Output Class Initialized
INFO - 2019-11-20 15:11:21 --> Security Class Initialized
DEBUG - 2019-11-20 15:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:11:21 --> CSRF cookie sent
INFO - 2019-11-20 15:11:21 --> CSRF token verified
INFO - 2019-11-20 15:11:21 --> Input Class Initialized
INFO - 2019-11-20 15:11:21 --> Language Class Initialized
INFO - 2019-11-20 15:11:21 --> Language Class Initialized
INFO - 2019-11-20 15:11:21 --> Config Class Initialized
INFO - 2019-11-20 15:11:21 --> Loader Class Initialized
INFO - 2019-11-20 15:11:21 --> Helper loaded: url_helper
INFO - 2019-11-20 15:11:21 --> Helper loaded: common_helper
INFO - 2019-11-20 15:11:21 --> Helper loaded: language_helper
INFO - 2019-11-20 15:11:21 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:11:21 --> Helper loaded: email_helper
INFO - 2019-11-20 15:11:21 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:11:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:11:21 --> Parser Class Initialized
INFO - 2019-11-20 15:11:21 --> User Agent Class Initialized
INFO - 2019-11-20 15:11:21 --> Model Class Initialized
INFO - 2019-11-20 15:11:21 --> Database Driver Class Initialized
INFO - 2019-11-20 15:11:21 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:21 --> Template Class Initialized
INFO - 2019-11-20 15:11:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:11:21 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:11:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:11:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:11:21 --> Encryption Class Initialized
INFO - 2019-11-20 15:11:21 --> Controller Class Initialized
DEBUG - 2019-11-20 15:11:21 --> checkout MX_Controller Initialized
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-20 15:11:21 --> Model Class Initialized
INFO - 2019-11-20 15:11:21 --> Helper loaded: inflector_helper
ERROR - 2019-11-20 15:11:21 --> Could not find the language line "shopier"
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 15:11:21 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 15:11:21 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 15:11:21 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-11-20 15:11:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-11-20 15:11:21 --> Final output sent to browser
DEBUG - 2019-11-20 15:11:21 --> Total execution time: 0.7604
INFO - 2019-11-20 15:11:29 --> Config Class Initialized
INFO - 2019-11-20 15:11:29 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:11:29 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:11:29 --> Utf8 Class Initialized
INFO - 2019-11-20 15:11:29 --> URI Class Initialized
INFO - 2019-11-20 15:11:29 --> Router Class Initialized
INFO - 2019-11-20 15:11:29 --> Output Class Initialized
INFO - 2019-11-20 15:11:29 --> Security Class Initialized
DEBUG - 2019-11-20 15:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:11:29 --> CSRF cookie sent
INFO - 2019-11-20 15:11:29 --> CSRF token verified
INFO - 2019-11-20 15:11:29 --> Input Class Initialized
INFO - 2019-11-20 15:11:29 --> Language Class Initialized
INFO - 2019-11-20 15:11:29 --> Language Class Initialized
INFO - 2019-11-20 15:11:29 --> Config Class Initialized
INFO - 2019-11-20 15:11:30 --> Loader Class Initialized
INFO - 2019-11-20 15:11:30 --> Helper loaded: url_helper
INFO - 2019-11-20 15:11:30 --> Helper loaded: common_helper
INFO - 2019-11-20 15:11:30 --> Helper loaded: language_helper
INFO - 2019-11-20 15:11:30 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:11:30 --> Helper loaded: email_helper
INFO - 2019-11-20 15:11:30 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:11:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:11:30 --> Parser Class Initialized
INFO - 2019-11-20 15:11:30 --> User Agent Class Initialized
INFO - 2019-11-20 15:11:30 --> Model Class Initialized
INFO - 2019-11-20 15:11:30 --> Database Driver Class Initialized
INFO - 2019-11-20 15:11:30 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:30 --> Template Class Initialized
INFO - 2019-11-20 15:11:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:11:30 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:11:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:11:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:11:30 --> Encryption Class Initialized
INFO - 2019-11-20 15:11:30 --> Controller Class Initialized
DEBUG - 2019-11-20 15:11:30 --> checkout MX_Controller Initialized
DEBUG - 2019-11-20 15:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-11-20 15:11:30 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:30 --> freekassa MX_Controller Initialized
ERROR - 2019-11-20 15:11:30 --> Could not find the language line "choose_payment_method"
DEBUG - 2019-11-20 15:11:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/freekassa/index.php
INFO - 2019-11-20 15:11:30 --> Final output sent to browser
DEBUG - 2019-11-20 15:11:30 --> Total execution time: 0.4906
INFO - 2019-11-20 15:11:34 --> Config Class Initialized
INFO - 2019-11-20 15:11:34 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:11:34 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:11:34 --> Utf8 Class Initialized
INFO - 2019-11-20 15:11:34 --> URI Class Initialized
INFO - 2019-11-20 15:11:34 --> Router Class Initialized
INFO - 2019-11-20 15:11:34 --> Output Class Initialized
INFO - 2019-11-20 15:11:34 --> Security Class Initialized
DEBUG - 2019-11-20 15:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:11:34 --> Input Class Initialized
INFO - 2019-11-20 15:11:34 --> Language Class Initialized
INFO - 2019-11-20 15:11:35 --> Language Class Initialized
INFO - 2019-11-20 15:11:35 --> Config Class Initialized
INFO - 2019-11-20 15:11:35 --> Loader Class Initialized
INFO - 2019-11-20 15:11:35 --> Helper loaded: url_helper
INFO - 2019-11-20 15:11:35 --> Helper loaded: common_helper
INFO - 2019-11-20 15:11:35 --> Helper loaded: language_helper
INFO - 2019-11-20 15:11:35 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:11:35 --> Helper loaded: email_helper
INFO - 2019-11-20 15:11:35 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:11:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:11:35 --> Parser Class Initialized
INFO - 2019-11-20 15:11:35 --> User Agent Class Initialized
INFO - 2019-11-20 15:11:35 --> Model Class Initialized
INFO - 2019-11-20 15:11:35 --> Database Driver Class Initialized
INFO - 2019-11-20 15:11:35 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:35 --> Template Class Initialized
INFO - 2019-11-20 15:11:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:11:35 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:11:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:11:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:11:35 --> Encryption Class Initialized
INFO - 2019-11-20 15:11:35 --> Controller Class Initialized
DEBUG - 2019-11-20 15:11:35 --> freekassa MX_Controller Initialized
INFO - 2019-11-20 15:11:35 --> Model Class Initialized
DEBUG - 2019-11-20 15:11:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/freekassa/freekassa_form.php
INFO - 2019-11-20 15:11:35 --> Final output sent to browser
DEBUG - 2019-11-20 15:11:35 --> Total execution time: 0.4869
INFO - 2019-11-20 15:55:15 --> Config Class Initialized
INFO - 2019-11-20 15:55:15 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:55:15 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:55:15 --> Utf8 Class Initialized
INFO - 2019-11-20 15:55:15 --> URI Class Initialized
INFO - 2019-11-20 15:55:15 --> Router Class Initialized
INFO - 2019-11-20 15:55:15 --> Output Class Initialized
INFO - 2019-11-20 15:55:15 --> Security Class Initialized
DEBUG - 2019-11-20 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:55:15 --> CSRF cookie sent
INFO - 2019-11-20 15:55:15 --> Input Class Initialized
INFO - 2019-11-20 15:55:15 --> Language Class Initialized
INFO - 2019-11-20 15:55:16 --> Language Class Initialized
INFO - 2019-11-20 15:55:16 --> Config Class Initialized
INFO - 2019-11-20 15:55:16 --> Loader Class Initialized
INFO - 2019-11-20 15:55:16 --> Helper loaded: url_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: common_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: language_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: email_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:55:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:55:16 --> Parser Class Initialized
INFO - 2019-11-20 15:55:16 --> User Agent Class Initialized
INFO - 2019-11-20 15:55:16 --> Model Class Initialized
INFO - 2019-11-20 15:55:16 --> Database Driver Class Initialized
INFO - 2019-11-20 15:55:16 --> Model Class Initialized
DEBUG - 2019-11-20 15:55:16 --> Template Class Initialized
INFO - 2019-11-20 15:55:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:55:16 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:55:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:55:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:55:16 --> Encryption Class Initialized
INFO - 2019-11-20 15:55:16 --> Controller Class Initialized
DEBUG - 2019-11-20 15:55:16 --> auth MX_Controller Initialized
DEBUG - 2019-11-20 15:55:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-20 15:55:16 --> Model Class Initialized
INFO - 2019-11-20 15:55:16 --> Config Class Initialized
INFO - 2019-11-20 15:55:16 --> Hooks Class Initialized
DEBUG - 2019-11-20 15:55:16 --> UTF-8 Support Enabled
INFO - 2019-11-20 15:55:16 --> Utf8 Class Initialized
INFO - 2019-11-20 15:55:16 --> URI Class Initialized
INFO - 2019-11-20 15:55:16 --> Router Class Initialized
INFO - 2019-11-20 15:55:16 --> Output Class Initialized
INFO - 2019-11-20 15:55:16 --> Security Class Initialized
DEBUG - 2019-11-20 15:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 15:55:16 --> CSRF cookie sent
INFO - 2019-11-20 15:55:16 --> Input Class Initialized
INFO - 2019-11-20 15:55:16 --> Language Class Initialized
INFO - 2019-11-20 15:55:16 --> Language Class Initialized
INFO - 2019-11-20 15:55:16 --> Config Class Initialized
INFO - 2019-11-20 15:55:16 --> Loader Class Initialized
INFO - 2019-11-20 15:55:16 --> Helper loaded: url_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: common_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: language_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: cookie_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: email_helper
INFO - 2019-11-20 15:55:16 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 15:55:16 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 15:55:16 --> Parser Class Initialized
INFO - 2019-11-20 15:55:16 --> User Agent Class Initialized
INFO - 2019-11-20 15:55:16 --> Model Class Initialized
INFO - 2019-11-20 15:55:16 --> Database Driver Class Initialized
INFO - 2019-11-20 15:55:16 --> Model Class Initialized
DEBUG - 2019-11-20 15:55:16 --> Template Class Initialized
INFO - 2019-11-20 15:55:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 15:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 15:55:16 --> Pagination Class Initialized
DEBUG - 2019-11-20 15:55:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 15:55:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 15:55:16 --> Encryption Class Initialized
INFO - 2019-11-20 15:55:16 --> Controller Class Initialized
DEBUG - 2019-11-20 15:55:16 --> statistics MX_Controller Initialized
DEBUG - 2019-11-20 15:55:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-20 15:55:16 --> Model Class Initialized
ERROR - 2019-11-20 15:55:16 --> Could not find the language line "Pending"
ERROR - 2019-11-20 15:55:16 --> Could not find the language line "Pending"
INFO - 2019-11-20 15:55:16 --> Helper loaded: inflector_helper
ERROR - 2019-11-20 15:55:17 --> Could not find the language line "total_orders"
ERROR - 2019-11-20 15:55:17 --> Could not find the language line "total_orders"
ERROR - 2019-11-20 15:55:17 --> Could not find the language line "Pending"
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 15:55:17 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 15:55:17 --> Model Class Initialized
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 15:55:17 --> Model Class Initialized
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 15:55:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 15:55:17 --> Final output sent to browser
DEBUG - 2019-11-20 15:55:17 --> Total execution time: 1.1118
INFO - 2019-11-20 16:11:39 --> Config Class Initialized
INFO - 2019-11-20 16:11:39 --> Hooks Class Initialized
DEBUG - 2019-11-20 16:11:39 --> UTF-8 Support Enabled
INFO - 2019-11-20 16:11:39 --> Utf8 Class Initialized
INFO - 2019-11-20 16:11:39 --> URI Class Initialized
DEBUG - 2019-11-20 16:11:39 --> No URI present. Default controller set.
INFO - 2019-11-20 16:11:39 --> Router Class Initialized
INFO - 2019-11-20 16:11:39 --> Output Class Initialized
INFO - 2019-11-20 16:11:39 --> Security Class Initialized
DEBUG - 2019-11-20 16:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 16:11:39 --> CSRF cookie sent
INFO - 2019-11-20 16:11:39 --> Input Class Initialized
INFO - 2019-11-20 16:11:39 --> Language Class Initialized
INFO - 2019-11-20 16:11:39 --> Language Class Initialized
INFO - 2019-11-20 16:11:39 --> Config Class Initialized
INFO - 2019-11-20 16:11:39 --> Loader Class Initialized
INFO - 2019-11-20 16:11:39 --> Helper loaded: url_helper
INFO - 2019-11-20 16:11:39 --> Helper loaded: common_helper
INFO - 2019-11-20 16:11:39 --> Helper loaded: language_helper
INFO - 2019-11-20 16:11:39 --> Helper loaded: cookie_helper
INFO - 2019-11-20 16:11:39 --> Helper loaded: email_helper
INFO - 2019-11-20 16:11:39 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 16:11:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 16:11:39 --> Parser Class Initialized
INFO - 2019-11-20 16:11:39 --> User Agent Class Initialized
INFO - 2019-11-20 16:11:39 --> Model Class Initialized
INFO - 2019-11-20 16:11:39 --> Database Driver Class Initialized
INFO - 2019-11-20 16:11:39 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:39 --> Template Class Initialized
INFO - 2019-11-20 16:11:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 16:11:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 16:11:40 --> Pagination Class Initialized
DEBUG - 2019-11-20 16:11:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 16:11:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 16:11:40 --> Encryption Class Initialized
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/language/english/pergo_lang.php
INFO - 2019-11-20 16:11:40 --> Controller Class Initialized
DEBUG - 2019-11-20 16:11:40 --> pergo MX_Controller Initialized
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/config/autoload.php
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/models/pergo_model.php
INFO - 2019-11-20 16:11:40 --> Model Class Initialized
INFO - 2019-11-20 16:11:40 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/header.php
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/blocks/footer.php
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/pergo/views/index.php
DEBUG - 2019-11-20 16:11:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-20 16:11:40 --> Final output sent to browser
DEBUG - 2019-11-20 16:11:40 --> Total execution time: 0.6121
INFO - 2019-11-20 16:11:49 --> Config Class Initialized
INFO - 2019-11-20 16:11:49 --> Hooks Class Initialized
DEBUG - 2019-11-20 16:11:49 --> UTF-8 Support Enabled
INFO - 2019-11-20 16:11:49 --> Utf8 Class Initialized
INFO - 2019-11-20 16:11:49 --> URI Class Initialized
INFO - 2019-11-20 16:11:49 --> Router Class Initialized
INFO - 2019-11-20 16:11:49 --> Output Class Initialized
INFO - 2019-11-20 16:11:49 --> Security Class Initialized
DEBUG - 2019-11-20 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 16:11:49 --> CSRF cookie sent
INFO - 2019-11-20 16:11:49 --> Input Class Initialized
INFO - 2019-11-20 16:11:49 --> Language Class Initialized
INFO - 2019-11-20 16:11:49 --> Language Class Initialized
INFO - 2019-11-20 16:11:49 --> Config Class Initialized
INFO - 2019-11-20 16:11:49 --> Loader Class Initialized
INFO - 2019-11-20 16:11:49 --> Helper loaded: url_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: common_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: language_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: cookie_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: email_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 16:11:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 16:11:49 --> Parser Class Initialized
INFO - 2019-11-20 16:11:49 --> User Agent Class Initialized
INFO - 2019-11-20 16:11:49 --> Model Class Initialized
INFO - 2019-11-20 16:11:49 --> Database Driver Class Initialized
INFO - 2019-11-20 16:11:49 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:49 --> Template Class Initialized
INFO - 2019-11-20 16:11:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 16:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 16:11:49 --> Pagination Class Initialized
DEBUG - 2019-11-20 16:11:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 16:11:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 16:11:49 --> Encryption Class Initialized
INFO - 2019-11-20 16:11:49 --> Controller Class Initialized
DEBUG - 2019-11-20 16:11:49 --> auth MX_Controller Initialized
DEBUG - 2019-11-20 16:11:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-20 16:11:49 --> Model Class Initialized
INFO - 2019-11-20 16:11:49 --> Config Class Initialized
INFO - 2019-11-20 16:11:49 --> Hooks Class Initialized
DEBUG - 2019-11-20 16:11:49 --> UTF-8 Support Enabled
INFO - 2019-11-20 16:11:49 --> Utf8 Class Initialized
INFO - 2019-11-20 16:11:49 --> URI Class Initialized
INFO - 2019-11-20 16:11:49 --> Router Class Initialized
INFO - 2019-11-20 16:11:49 --> Output Class Initialized
INFO - 2019-11-20 16:11:49 --> Security Class Initialized
DEBUG - 2019-11-20 16:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 16:11:49 --> CSRF cookie sent
INFO - 2019-11-20 16:11:49 --> Input Class Initialized
INFO - 2019-11-20 16:11:49 --> Language Class Initialized
INFO - 2019-11-20 16:11:49 --> Language Class Initialized
INFO - 2019-11-20 16:11:49 --> Config Class Initialized
INFO - 2019-11-20 16:11:49 --> Loader Class Initialized
INFO - 2019-11-20 16:11:49 --> Helper loaded: url_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: common_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: language_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: cookie_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: email_helper
INFO - 2019-11-20 16:11:49 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 16:11:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 16:11:49 --> Parser Class Initialized
INFO - 2019-11-20 16:11:49 --> User Agent Class Initialized
INFO - 2019-11-20 16:11:49 --> Model Class Initialized
INFO - 2019-11-20 16:11:49 --> Database Driver Class Initialized
INFO - 2019-11-20 16:11:49 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:49 --> Template Class Initialized
INFO - 2019-11-20 16:11:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 16:11:50 --> Config Class Initialized
INFO - 2019-11-20 16:11:50 --> Hooks Class Initialized
INFO - 2019-11-20 16:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 16:11:50 --> Pagination Class Initialized
DEBUG - 2019-11-20 16:11:50 --> UTF-8 Support Enabled
INFO - 2019-11-20 16:11:50 --> Utf8 Class Initialized
DEBUG - 2019-11-20 16:11:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 16:11:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 16:11:50 --> URI Class Initialized
INFO - 2019-11-20 16:11:50 --> Encryption Class Initialized
INFO - 2019-11-20 16:11:50 --> Router Class Initialized
INFO - 2019-11-20 16:11:50 --> Controller Class Initialized
INFO - 2019-11-20 16:11:50 --> Output Class Initialized
DEBUG - 2019-11-20 16:11:50 --> statistics MX_Controller Initialized
INFO - 2019-11-20 16:11:50 --> Security Class Initialized
DEBUG - 2019-11-20 16:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-11-20 16:11:50 --> CSRF cookie sent
INFO - 2019-11-20 16:11:50 --> Model Class Initialized
INFO - 2019-11-20 16:11:50 --> Input Class Initialized
ERROR - 2019-11-20 16:11:50 --> Could not find the language line "Pending"
INFO - 2019-11-20 16:11:50 --> Language Class Initialized
ERROR - 2019-11-20 16:11:50 --> Could not find the language line "Pending"
INFO - 2019-11-20 16:11:50 --> Language Class Initialized
INFO - 2019-11-20 16:11:50 --> Helper loaded: inflector_helper
INFO - 2019-11-20 16:11:50 --> Config Class Initialized
ERROR - 2019-11-20 16:11:50 --> Could not find the language line "total_orders"
INFO - 2019-11-20 16:11:50 --> Loader Class Initialized
ERROR - 2019-11-20 16:11:50 --> Could not find the language line "total_orders"
INFO - 2019-11-20 16:11:50 --> Helper loaded: url_helper
ERROR - 2019-11-20 16:11:50 --> Could not find the language line "Pending"
INFO - 2019-11-20 16:11:50 --> Helper loaded: common_helper
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
INFO - 2019-11-20 16:11:50 --> Helper loaded: language_helper
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 16:11:50 --> blocks MX_Controller Initialized
INFO - 2019-11-20 16:11:50 --> Helper loaded: cookie_helper
INFO - 2019-11-20 16:11:50 --> Helper loaded: email_helper
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 16:11:50 --> Model Class Initialized
INFO - 2019-11-20 16:11:50 --> Helper loaded: file_manager_helper
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 16:11:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 16:11:50 --> Model Class Initialized
INFO - 2019-11-20 16:11:50 --> Parser Class Initialized
INFO - 2019-11-20 16:11:50 --> User Agent Class Initialized
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2019-11-20 16:11:50 --> Model Class Initialized
INFO - 2019-11-20 16:11:50 --> Database Driver Class Initialized
INFO - 2019-11-20 16:11:50 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:50 --> Template Class Initialized
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 16:11:50 --> Final output sent to browser
DEBUG - 2019-11-20 16:11:50 --> Total execution time: 0.8176
INFO - 2019-11-20 16:11:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 16:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 16:11:50 --> Pagination Class Initialized
DEBUG - 2019-11-20 16:11:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 16:11:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 16:11:50 --> Encryption Class Initialized
INFO - 2019-11-20 16:11:50 --> Controller Class Initialized
DEBUG - 2019-11-20 16:11:50 --> auth MX_Controller Initialized
DEBUG - 2019-11-20 16:11:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-11-20 16:11:50 --> Model Class Initialized
INFO - 2019-11-20 16:11:54 --> Config Class Initialized
INFO - 2019-11-20 16:11:54 --> Hooks Class Initialized
DEBUG - 2019-11-20 16:11:54 --> UTF-8 Support Enabled
INFO - 2019-11-20 16:11:54 --> Utf8 Class Initialized
INFO - 2019-11-20 16:11:54 --> URI Class Initialized
INFO - 2019-11-20 16:11:54 --> Router Class Initialized
INFO - 2019-11-20 16:11:54 --> Output Class Initialized
INFO - 2019-11-20 16:11:54 --> Security Class Initialized
DEBUG - 2019-11-20 16:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 16:11:54 --> CSRF cookie sent
INFO - 2019-11-20 16:11:54 --> Input Class Initialized
INFO - 2019-11-20 16:11:54 --> Language Class Initialized
INFO - 2019-11-20 16:11:54 --> Language Class Initialized
INFO - 2019-11-20 16:11:54 --> Config Class Initialized
INFO - 2019-11-20 16:11:54 --> Loader Class Initialized
INFO - 2019-11-20 16:11:54 --> Helper loaded: url_helper
INFO - 2019-11-20 16:11:54 --> Helper loaded: common_helper
INFO - 2019-11-20 16:11:54 --> Helper loaded: language_helper
INFO - 2019-11-20 16:11:54 --> Helper loaded: cookie_helper
INFO - 2019-11-20 16:11:54 --> Helper loaded: email_helper
INFO - 2019-11-20 16:11:54 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 16:11:54 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 16:11:54 --> Parser Class Initialized
INFO - 2019-11-20 16:11:54 --> User Agent Class Initialized
INFO - 2019-11-20 16:11:54 --> Model Class Initialized
INFO - 2019-11-20 16:11:54 --> Database Driver Class Initialized
INFO - 2019-11-20 16:11:54 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:54 --> Template Class Initialized
INFO - 2019-11-20 16:11:54 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 16:11:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 16:11:54 --> Pagination Class Initialized
DEBUG - 2019-11-20 16:11:54 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 16:11:54 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 16:11:54 --> Encryption Class Initialized
INFO - 2019-11-20 16:11:54 --> Controller Class Initialized
DEBUG - 2019-11-20 16:11:54 --> setting MX_Controller Initialized
DEBUG - 2019-11-20 16:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-20 16:11:54 --> Model Class Initialized
INFO - 2019-11-20 16:11:54 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 16:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-20 16:11:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 16:11:55 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 16:11:55 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 16:11:55 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 16:11:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 16:11:55 --> Final output sent to browser
DEBUG - 2019-11-20 16:11:55 --> Total execution time: 1.0848
INFO - 2019-11-20 16:11:58 --> Config Class Initialized
INFO - 2019-11-20 16:11:58 --> Hooks Class Initialized
DEBUG - 2019-11-20 16:11:58 --> UTF-8 Support Enabled
INFO - 2019-11-20 16:11:58 --> Utf8 Class Initialized
INFO - 2019-11-20 16:11:58 --> URI Class Initialized
INFO - 2019-11-20 16:11:58 --> Router Class Initialized
INFO - 2019-11-20 16:11:58 --> Output Class Initialized
INFO - 2019-11-20 16:11:58 --> Security Class Initialized
DEBUG - 2019-11-20 16:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-20 16:11:58 --> CSRF cookie sent
INFO - 2019-11-20 16:11:58 --> Input Class Initialized
INFO - 2019-11-20 16:11:58 --> Language Class Initialized
INFO - 2019-11-20 16:11:58 --> Language Class Initialized
INFO - 2019-11-20 16:11:58 --> Config Class Initialized
INFO - 2019-11-20 16:11:58 --> Loader Class Initialized
INFO - 2019-11-20 16:11:58 --> Helper loaded: url_helper
INFO - 2019-11-20 16:11:58 --> Helper loaded: common_helper
INFO - 2019-11-20 16:11:58 --> Helper loaded: language_helper
INFO - 2019-11-20 16:11:58 --> Helper loaded: cookie_helper
INFO - 2019-11-20 16:11:58 --> Helper loaded: email_helper
INFO - 2019-11-20 16:11:58 --> Helper loaded: file_manager_helper
INFO - 2019-11-20 16:11:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-20 16:11:58 --> Parser Class Initialized
INFO - 2019-11-20 16:11:58 --> User Agent Class Initialized
INFO - 2019-11-20 16:11:58 --> Model Class Initialized
INFO - 2019-11-20 16:11:58 --> Database Driver Class Initialized
INFO - 2019-11-20 16:11:58 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:58 --> Template Class Initialized
INFO - 2019-11-20 16:11:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-20 16:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-20 16:11:58 --> Pagination Class Initialized
DEBUG - 2019-11-20 16:11:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-20 16:11:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-20 16:11:58 --> Encryption Class Initialized
INFO - 2019-11-20 16:11:58 --> Controller Class Initialized
DEBUG - 2019-11-20 16:11:58 --> setting MX_Controller Initialized
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-11-20 16:11:58 --> Model Class Initialized
INFO - 2019-11-20 16:11:58 --> Helper loaded: inflector_helper
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/freekassa.php
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-11-20 16:11:58 --> blocks MX_Controller Initialized
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-11-20 16:11:58 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-11-20 16:11:58 --> Model Class Initialized
DEBUG - 2019-11-20 16:11:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-11-20 16:11:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-11-20 16:11:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-11-20 16:11:59 --> Final output sent to browser
DEBUG - 2019-11-20 16:11:59 --> Total execution time: 0.8425
