<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'test');
define('TIMEZONE', 'Africa/Abidjan');
define('ENCRYPTION_KEY', '411e229b97081738eb36b9ec78a0b742');