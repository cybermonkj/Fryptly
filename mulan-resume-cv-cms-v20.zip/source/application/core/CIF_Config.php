<?php

class CIF_Config extends CI_Config {
    protected $instance;


    public function __construct(){
        parent::__construct();

    }
}
