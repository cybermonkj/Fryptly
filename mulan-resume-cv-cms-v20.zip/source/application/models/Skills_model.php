<?php

class Skills_model extends CIF_model
{
    public $_table = 'skills';
    public $_primary_keys = array('skill_id');


}
