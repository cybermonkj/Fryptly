<?php

class Blog_categories_model extends CIF_model
{
    public $_table = 'blog_categories';
    public $_primary_keys = array('blog_category_id');


}
