<?php

class Clients_model extends CIF_model
{
    public $_table = 'clients';
    public $_primary_keys = array('client_id');


}
