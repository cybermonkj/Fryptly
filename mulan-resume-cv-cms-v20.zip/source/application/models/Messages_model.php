<?php

class Messages_model extends CIF_model
{
    public $_table = 'messages';
    public $_primary_keys = array('message_id');


}
